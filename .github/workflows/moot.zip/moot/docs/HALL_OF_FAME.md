# Security Hall of Fame

People who found and responsibly reported security issues in Moot. Thank you.

How to get listed: see [SECURITY.md](../SECURITY.md).

| Date | Researcher | Badge | Advisory | Issue |
|---|---|---|---|---|
| | *Be the first.* | | | |

## Found internally

Bugs caught by our own testing before release, listed for transparency.

| Date | Found by | Severity | Issue |
|---|---|---|---|
| 2026-11-24 | Fuzzing (`community_ops`) | High | Two devices that received the same events in a different order could disagree about who is a member or banned. Fixed by deriving community state from one canonical event order and checking each event against the history it was written on. |
| 2026-11-24 | Review | High | Invite codes contained the host's IP addresses, and "Hide my IP" had no effect. Fixed: relay-only by default, IPs stripped from every code and never dialled. |
| 2026-11-24 | Review | High | Account keys and messages were stored unencrypted on disk. Fixed: encrypted at rest, key held by the OS keychain, old databases migrated and scrubbed. |
| 2026-11-24 | `cargo audit` | Medium | Social-recovery secret sharing used a library with biased coefficients (RUSTSEC-2024-0398). Replaced with the fixed fork `blahaj`. |
| 2026-11-24 | `cargo audit` | Medium | Bundled SQLite had CVE-2026-119375 (RUSTSEC-2026-0459). Upgraded. |
| 2026-11-24 | Review | Medium | The app's network key changed on every start, breaking invite codes after a restart. Fixed: the key is kept, sealed, in the encrypted store. |
