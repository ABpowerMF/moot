# How Moot works (as built in v0.1.0)

This describes what the code does today. The Phase 2 architecture & threat-model doc covers the full design, including the parts not built yet.

## Identity

- Your **account is an Ed25519 key** derived from a 12-word BIP-39 phrase (`blake3::derive_key("moot identity key v1", seed)`). Same words → same account on any device.
- Each **device has its own key**, certified by the identity key (`DeviceCert`, signing domain `moot/device-cert/v1`). Events are signed by device keys, so a lost laptop can be revoked without changing who you are.
- **Social recovery**: the identity secret can be split into Shamir shares (e.g. any 3 of 5 friends).
- A **fingerprint** (`XXXX XXXX XXXX XXXX`) is what people compare to verify each other.

## Communities are signed event logs

Every action is an `Event { id, body, sig }`:

- `body` = community id, author's `DeviceCert`, parent event ids (`prev`), Lamport clock, timestamp, and the `EventKind`.
- `id` = BLAKE3 of the postcard-encoded body. `sig` = device signature over `moot/event/v1:` + id.
- The community id **is** the id of its `Genesis` event, so a community can't be impersonated.

Event kinds: Genesis, ChannelCreate, Invite, Join, Leave, RoleGrant, Message, Edit, Delete, Ban, Unban, NodeCertify, NodeRevoke, SetBackupOwner, OwnershipTransfer.

Every device computes the same state from the same events, whatever order they arrive in:

- **Admission**: an event enters the log only if it's valid *and allowed in the history it was written on* (its ancestors, fixed by their hashes) — so every device admits the same events.
- **Effect**: state is the result of applying all admitted events in one canonical order, `(lamport, id)`. An event that loses a race (a message from someone banned at the same moment) stays in the log without effect, identically everywhere.

The rules checked for each event:

- valid id, signature and device certificate; parents already known; Lamport clock above its parents
- roles: **Owner > Admin > Moderator > Member**; you can only act on people below you
- joining Public communities is open; Invite-only/Private need an `Invite` from a moderator; banned keys can't rejoin
- only authors edit their own messages; moderators can delete; announcements channels are moderator-only
- a backup owner can take over if the owner disappears

## Storage

SQLite, with every account key, event and peer address sealed by XChaCha20-Poly1305 under a vault key that never touches the database (OS keychain on desktop, key file or `MOOT_VAULT_KEY` on nodes). Each value's associated data binds it to its row (events to their id). A check value detects a wrong key. Unencrypted v0.1 databases are migrated, then vacuumed with `secure_delete` so no plaintext remains.

## Network privacy

`NetMode::Private` (default) builds the Iroh endpoint with **no IP transports**, relay only, no port mapping, and an address-lookup filter that publishes only the relay. Peers never learn your IP; the relay forwards end-to-end-encrypted QUIC between public keys. Addresses handed out or dialled always have IPs stripped. `NetMode::Direct` is opt-in. The app's network key is persistent (sealed in the store) so invite codes survive restarts.

## Sync (`moot/sync/1`)

Peers dial each other **by public key** over Iroh (QUIC). Iroh hole-punches when it can and falls back to a relay when it can't, so nobody needs port forwarding, and the relay only sees encrypted traffic.

One bidirectional stream per sync:

1. dialler → host: `Hello { community, have: [ids] }`
2. host → dialler: `Offer { events the dialler lacks, have: [ids] }`
3. dialler → host: `Push { events the host lacks }`

Both sides run everything through `sync::import`, which re-applies the rules above. A peer can withhold events (detectable by comparing with other peers — `detect_withholding`) but can't make anyone accept a forged one. Frames are capped at 16 MiB.

## Invite codes

`moot1` + base64url(postcard(`Invite { genesis, host }`)): the signed genesis event plus the host's network address. The genesis is verified when the code is decoded. Joining = create local state from the genesis → sync → sign a `Join` → sync again so the host learns about you.

## The desktop app

- `src-tauri` holds all keys and does all signing, verification, storage and networking; the React interface only calls commands and receives public data.
- Communities live in a shared `Library` that the network peer serves directly. A background task syncs with known peers every 4 s (and immediately after you post), then writes new events to SQLite.
- On start-up every stored event is re-verified while the communities are rebuilt.

## Nodes

`moot-node` is the same core without a window. It stores and serves communities, verifies everything it receives, and can join a community from an invite to help keep it online.

## Not built yet

MLS (end-to-end encrypted channels), two-hop relays / Tor mode, voice/video via a LiveKit SFU, push-based sync, node discovery, Discord OAuth import, the Ludus-side API.
