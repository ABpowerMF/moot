//! Tauri shell: exposes moot-core and moot-net to the interface as commands.
//!
//! Everything security-relevant (keys, signing, verification, storage, networking) happens
//! here in Rust. The web interface only ever sees public data and results.
//!
//! Communities live in a shared [`Library`]. The network peer serves that same library to
//! other members, a background task pulls from known peers every few seconds, and anything
//! new — whether we wrote it or a peer pushed it — is persisted to SQLite.

mod vault;

use moot_core::{Badge, ChannelKind, CommunityState, Device, EventId, EventKind, Identity, RecoveryPhrase, Store, Visibility, WRONG_VAULT_KEY};
use moot_net::{strip_ips, EndpointAddr, Invite, Library, NetMode, Peer, PathCounts};
use vault::KeySource;
use serde::Serialize;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tauri::{AppHandle, Manager};

struct Account {
    identity: Identity,
    device: Device,
    name: String,
}

struct AppState {
    store: Store,
    account: Option<Account>,
    library: Library,
    /// Peers known to host each community (from invite codes).
    remotes: HashMap<EventId, Vec<EndpointAddr>>,
    /// How many events of each community are already on disk.
    saved: HashMap<EventId, usize>,
}

type Shared = Mutex<AppState>;

#[derive(Default)]
struct NetState {
    peer: Mutex<Option<Arc<Peer>>>,
    last_error: Mutex<Option<String>>,
    synced: Mutex<usize>,
    /// Serialises peer restarts (e.g. when "Hide my IP" is switched).
    restarting: tokio::sync::Mutex<()>,
}

/// Facts about local security the privacy check screen shows.
struct Security {
    key_source: KeySource,
    /// A database that couldn't be unlocked was moved aside at start-up.
    locked_db_moved: Option<String>,
}

fn mode_for(hide_ip: bool) -> NetMode {
    if hide_ip { NetMode::Private } else { NetMode::Direct }
}

fn hide_ip_setting(store: &Store) -> bool {
    store.setting("hide_ip").ok().flatten().map(|v| v != "false").unwrap_or(true)
}

#[derive(Serialize)]
struct AccountInfo {
    display_name: String,
    fingerprint: String,
    identity: String,
    device_name: String,
}

#[derive(Serialize)]
struct CreatedAccount {
    account: AccountInfo,
    recovery_words: Vec<String>,
}

#[derive(Serialize)]
struct ChannelInfo {
    id: String,
    name: String,
    kind: String,
    private: bool,
}

#[derive(Serialize)]
struct CommunityInfo {
    id: String,
    name: String,
    description: String,
    visibility: String,
    members: usize,
    events: usize,
    nodes: usize,
    channels: Vec<ChannelInfo>,
    owner_fingerprint: String,
}

#[derive(Serialize)]
struct MessageInfo {
    id: String,
    channel: String,
    author_fingerprint: String,
    author_device: String,
    text: String,
    timestamp_ms: u64,
    edited: bool,
    mine: bool,
}

#[derive(Serialize)]
struct NetworkStatus {
    online: bool,
    node_id: String,
    mode: String,
    hide_ip: bool,
    synced_communities: usize,
    last_error: Option<String>,
}

#[derive(Serialize)]
struct PrivacyReport {
    /// Peers can't see our IP (relay-only mode is active).
    hide_ip: bool,
    online: bool,
    /// IP sockets open right now. 0 in private mode.
    ip_sockets: usize,
    /// Relay we're reachable through — it sees our IP, not our messages.
    relay: Option<String>,
    /// Our invite codes contain no IP address.
    invites_ip_free: bool,
    /// How connections so far were carried.
    paths: PathCounts,
    /// Where the vault key lives.
    key_storage: String,
    key_in_keychain: bool,
    /// Local database is encrypted at rest.
    database_encrypted: bool,
    locked_db_moved: Option<String>,
}

#[derive(Serialize)]
struct SyncReport {
    applied: usize,
    already_had: usize,
    rejected: usize,
}

fn info(a: &Account) -> AccountInfo {
    AccountInfo {
        display_name: a.name.clone(),
        fingerprint: a.identity.public().fingerprint(),
        identity: a.identity.public().to_hex(),
        device_name: a.device.cert.device_name.clone(),
    }
}

fn community_info(c: &CommunityState) -> CommunityInfo {
    let rank = |k: &ChannelKind| match k {
        ChannelKind::Text => 0,
        ChannelKind::Announcement => 1,
        ChannelKind::Voice => 2,
    };
    let mut channels: Vec<_> = c.channels.values().collect();
    channels.sort_by_key(|ch| (rank(&ch.kind), ch.id != "general", ch.name.clone()));
    CommunityInfo {
        id: c.id.to_hex(),
        name: c.name.clone(),
        description: c.description.clone(),
        visibility: format!("{:?}", c.visibility),
        members: c.members.len(),
        events: c.len(),
        nodes: c.nodes.len(),
        channels: channels
            .into_iter()
            .map(|ch| ChannelInfo { id: ch.id.clone(), name: ch.name.clone(), kind: format!("{:?}", ch.kind), private: ch.private })
            .collect(),
        owner_fingerprint: c.owner.fingerprint(),
    }
}

fn err(e: impl std::fmt::Display) -> String {
    e.to_string()
}

fn device_name() -> String {
    let os = match std::env::consts::OS {
        "windows" => "Windows",
        "macos" => "macOS",
        "linux" => "Linux",
        other => other,
    };
    format!("Desktop — {os}")
}

/// Write any events not yet on disk. Cheap when nothing changed.
fn persist(s: &mut AppState) -> Result<(), String> {
    for id in s.library.ids() {
        let Some((len, evs)) = s.library.with(&id, |c| (c.len(), c.events_in_order().cloned().collect::<Vec<_>>())) else { continue };
        if s.saved.get(&id) != Some(&len) {
            s.store.save_events(&id, &evs).map_err(err)?;
            s.saved.insert(id, len);
        }
    }
    Ok(())
}

fn peer_of(net: &NetState) -> Result<Arc<Peer>, String> {
    net.peer.lock().unwrap().clone().ok_or_else(|| "Still connecting to the network — try again in a moment".to_string())
}

// ---------- account ----------

#[tauri::command]
fn get_account(state: tauri::State<Shared>) -> Option<AccountInfo> {
    state.lock().unwrap().account.as_ref().map(info)
}

#[tauri::command]
fn create_account(state: tauri::State<Shared>, display_name: String) -> Result<CreatedAccount, String> {
    let name = display_name.trim();
    if name.is_empty() || name.chars().count() > 40 {
        return Err("Display name must be 1–40 characters".into());
    }
    let mut s = state.lock().unwrap();
    let (identity, phrase) = Identity::create();
    let device = Device::new(&identity, &device_name());
    s.store.save_account(&identity, &device, name).map_err(err)?;
    let words = phrase.words().iter().map(|w| w.to_string()).collect();
    s.account = Some(Account { identity, device, name: name.to_string() });
    Ok(CreatedAccount { account: info(s.account.as_ref().unwrap()), recovery_words: words })
}

#[tauri::command]
fn restore_account(state: tauri::State<Shared>, phrase: String, display_name: String) -> Result<AccountInfo, String> {
    let identity = Identity::from_phrase(&RecoveryPhrase(phrase)).map_err(err)?;
    let device = Device::new(&identity, &device_name());
    let name = if display_name.trim().is_empty() { "Me".to_string() } else { display_name.trim().to_string() };
    let mut s = state.lock().unwrap();
    s.store.save_account(&identity, &device, &name).map_err(err)?;
    s.account = Some(Account { identity, device, name });
    Ok(info(s.account.as_ref().unwrap()))
}

#[tauri::command]
fn set_display_name(state: tauri::State<Shared>, display_name: String) -> Result<(), String> {
    let mut s = state.lock().unwrap();
    s.store.set_display_name(display_name.trim()).map_err(err)?;
    if let Some(a) = s.account.as_mut() {
        a.name = display_name.trim().to_string();
    }
    Ok(())
}

// ---------- communities and messages ----------

#[tauri::command]
fn list_communities(state: tauri::State<Shared>) -> Vec<CommunityInfo> {
    let s = state.lock().unwrap();
    let mut v: Vec<_> = s.library.ids().iter().filter_map(|id| s.library.with(id, |c| community_info(c))).collect();
    v.sort_by(|a, b| a.name.cmp(&b.name));
    v
}

#[tauri::command]
fn create_community(state: tauri::State<Shared>, name: String, description: String, visibility: String) -> Result<CommunityInfo, String> {
    let name = name.trim();
    if name.is_empty() || name.chars().count() > 60 {
        return Err("Name must be 1–60 characters".into());
    }
    let mut s = state.lock().unwrap();
    let vis = match visibility.as_str() {
        "Public" => Visibility::Public,
        "Private" => Visibility::Private,
        _ => Visibility::InviteOnly,
    };
    let acc = s.account.as_ref().ok_or("Create an account first")?;
    let (mut c, mut evs) = CommunityState::create(&acc.device, name, description.trim(), vis).map_err(err)?;
    for (id, nm, kind) in [("announcements", "announcements", ChannelKind::Announcement), ("lounge", "Lounge", ChannelKind::Voice)] {
        evs.push(c.author(&acc.device, EventKind::ChannelCreate { channel: id.into(), name: nm.into(), kind, private: false }).map_err(err)?);
    }
    s.store.save_events(&c.id, &evs).map_err(err)?;
    let out = community_info(&c);
    s.saved.insert(c.id, c.len());
    s.library.insert(c);
    Ok(out)
}

#[tauri::command]
fn post_message(app: AppHandle, state: tauri::State<Shared>, community: String, channel: String, text: String) -> Result<MessageInfo, String> {
    let text = text.trim().to_string();
    if text.is_empty() || text.len() > 4000 {
        return Err("Messages must be 1–4000 characters".into());
    }
    let id = EventId::from_hex(&community).map_err(err)?;
    let mut s = state.lock().unwrap();
    let acc = s.account.as_ref().ok_or("Create an account first")?;
    let device = acc.device.clone();
    let fingerprint = acc.identity.public().fingerprint();
    let ev = s
        .library
        .with(&id, |c| c.author(&device, EventKind::Message { channel: channel.clone(), text: text.clone(), reply_to: None }))
        .ok_or("Unknown community")?
        .map_err(err)?;
    s.store.save_event(&id, &ev).map_err(err)?;
    if let Some(n) = s.saved.get_mut(&id) {
        *n += 1;
    }
    // Push it to the peers we know straight away instead of waiting for the next round.
    if s.remotes.contains_key(&id) {
        let app = app.clone();
        tauri::async_runtime::spawn(async move { sync_round(&app, Some(id)).await });
    }
    Ok(MessageInfo {
        id: ev.id.to_hex(),
        channel,
        author_fingerprint: fingerprint,
        author_device: device.cert.device_name.clone(),
        text,
        timestamp_ms: ev.body.timestamp_ms,
        edited: false,
        mine: true,
    })
}

#[tauri::command]
fn list_messages(state: tauri::State<Shared>, community: String, channel: String) -> Result<Vec<MessageInfo>, String> {
    let s = state.lock().unwrap();
    let id = EventId::from_hex(&community).map_err(err)?;
    let me = s.account.as_ref().map(|a| a.identity.public());
    s.library
        .with(&id, |c| {
            c.messages(&channel)
                .into_iter()
                .map(|m| MessageInfo {
                    id: m.id.to_hex(),
                    channel: m.channel.clone(),
                    author_fingerprint: m.author.fingerprint(),
                    author_device: m.author_device.clone(),
                    text: m.text.clone(),
                    timestamp_ms: m.timestamp_ms,
                    edited: m.edited,
                    mine: Some(m.author) == me,
                })
                .collect()
        })
        .ok_or_else(|| "Unknown community".to_string())
}

#[derive(Serialize)]
struct VerifyReport {
    communities: usize,
    events_verified: usize,
}

/// Re-load every community from disk, re-checking every id, signature and permission.
#[tauri::command]
fn verify_all(state: tauri::State<Shared>) -> Result<VerifyReport, String> {
    let mut s = state.lock().unwrap();
    persist(&mut s)?;
    let mut events = 0;
    let list = s.store.list_communities().map_err(err)?;
    for (id, _) in &list {
        events += s.store.load_community(id).map_err(err)?.len();
    }
    Ok(VerifyReport { communities: list.len(), events_verified: events })
}

// ---------- security badges ----------

#[derive(Serialize)]
struct BadgeInfo {
    tier: String,
    title: String,
    advisory: String,
    issued_ms: u64,
}

fn my_badges(s: &AppState) -> Vec<Badge> {
    let Some(me) = s.account.as_ref().map(|a| a.identity.public()) else { return vec![] };
    let codes: Vec<String> = s.store.setting("badges").ok().flatten().and_then(|j| serde_json::from_str(&j).ok()).unwrap_or_default();
    codes
        .iter()
        .filter_map(|c| Badge::decode(c).ok())
        .filter(|b| b.body.holder == me && b.verify().is_ok())
        .collect()
}

fn badge_info(b: &Badge) -> BadgeInfo {
    BadgeInfo { tier: format!("{:?}", b.body.tier), title: b.body.title.clone(), advisory: b.body.advisory.clone(), issued_ms: b.body.issued_ms }
}

#[tauri::command]
fn list_badges(state: tauri::State<Shared>) -> Vec<BadgeInfo> {
    my_badges(&state.lock().unwrap()).iter().map(badge_info).collect()
}

/// Add a badge code from the security team. It must be signed by a Moot security key and
/// name this account — so a badge can't be faked or borrowed.
#[tauri::command]
fn add_badge(state: tauri::State<Shared>, code: String) -> Result<BadgeInfo, String> {
    let s = state.lock().unwrap();
    let me = s.account.as_ref().ok_or("Create an account first")?.identity.public();
    let badge = Badge::decode(&code).map_err(err)?;
    if badge.body.holder != me {
        return Err("This badge was issued to someone else".into());
    }
    badge.verify().map_err(err)?;
    let mut codes: Vec<String> = s.store.setting("badges").ok().flatten().and_then(|j| serde_json::from_str(&j).ok()).unwrap_or_default();
    let enc = badge.encode();
    if !codes.contains(&enc) {
        codes.push(enc);
    }
    s.store.set_setting("badges", &serde_json::to_string(&codes).map_err(err)?).map_err(err)?;
    Ok(badge_info(&badge))
}

// ---------- network ----------

#[tauri::command]
fn network_status(state: tauri::State<Shared>, net: tauri::State<NetState>) -> NetworkStatus {
    let peer = net.peer.lock().unwrap().clone();
    let s = state.lock().unwrap();
    NetworkStatus {
        online: peer.is_some(),
        node_id: peer.as_ref().map(|p| p.id()).unwrap_or_default(),
        mode: peer.as_ref().map(|p| p.mode().label().to_string()).unwrap_or_else(|| "connecting".into()),
        hide_ip: hide_ip_setting(&s.store),
        synced_communities: s.remotes.len().max(*net.synced.lock().unwrap()),
        last_error: net.last_error.lock().unwrap().clone(),
    }
}

#[tauri::command]
fn privacy_report(state: tauri::State<Shared>, net: tauri::State<NetState>, sec: tauri::State<Security>) -> PrivacyReport {
    let peer = net.peer.lock().unwrap().clone();
    let hide = hide_ip_setting(&state.lock().unwrap().store);
    PrivacyReport {
        hide_ip: peer.as_ref().map(|p| p.mode().hides_ip()).unwrap_or(hide),
        online: peer.is_some(),
        ip_sockets: peer.as_ref().map(|p| p.ip_sockets()).unwrap_or(0),
        relay: peer.as_ref().and_then(|p| p.relay_url()),
        invites_ip_free: peer.as_ref().map(|p| p.addr().ip_addrs().count() == 0).unwrap_or(true),
        paths: peer.as_ref().map(|p| p.path_counts()).unwrap_or_default(),
        key_storage: sec.key_source.label().to_string(),
        key_in_keychain: sec.key_source == KeySource::Keychain,
        database_encrypted: true,
        locked_db_moved: sec.locked_db_moved.clone(),
    }
}

/// Switch "Hide my IP". Restarts the network peer in the new mode (same network key, so
/// invite codes keep working).
#[tauri::command]
async fn set_hide_ip(app: AppHandle, hide: bool) -> Result<bool, String> {
    {
        let s = app.state::<Shared>();
        let s = s.lock().unwrap();
        s.store.set_setting("hide_ip", if hide { "true" } else { "false" }).map_err(err)?;
    }
    restart_peer(&app).await?;
    Ok(hide)
}

/// (Re)start the network peer with the mode from settings.
async fn restart_peer(app: &AppHandle) -> Result<(), String> {
    let net = app.state::<NetState>();
    let _guard = net.restarting.lock().await;
    let (mode, library, key) = {
        let s = app.state::<Shared>();
        let s = s.lock().unwrap();
        let key = s.store.persistent_secret("network_key").map_err(err)?;
        (mode_for(hide_ip_setting(&s.store)), s.library.clone(), key)
    };
    // Stop the old peer first, so we never have two endpoints with the same key.
    let old = net.peer.lock().unwrap().take();
    if let Some(old) = old {
        let _ = old.shutdown().await;
    }
    match Peer::spawn_keyed(mode, library, key).await {
        Ok(peer) => {
            *net.peer.lock().unwrap() = Some(Arc::new(peer));
            *net.last_error.lock().unwrap() = None;
            Ok(())
        }
        Err(e) => {
            let msg = format!("couldn’t start networking: {e}");
            *net.last_error.lock().unwrap() = Some(msg.clone());
            Err(msg)
        }
    }
}

#[tauri::command]
async fn invite_code(state: tauri::State<'_, Shared>, net: tauri::State<'_, NetState>, community: String) -> Result<String, String> {
    let id = EventId::from_hex(&community).map_err(err)?;
    let public = state.lock().unwrap().library.with(&id, |c| c.visibility == Visibility::Public).ok_or("Unknown community")?;
    if !public {
        return Err("Invite codes work for public communities in this prototype".into());
    }
    let peer = peer_of(&net)?;
    // Give the peer a moment to reach its relay so the code carries a reachable address.
    let _ = tokio::time::timeout(Duration::from_secs(6), peer.online()).await;
    Ok(peer.invite(&id).map_err(err)?.encode())
}

#[tauri::command]
async fn join_with_code(state: tauri::State<'_, Shared>, net: tauri::State<'_, NetState>, code: String) -> Result<CommunityInfo, String> {
    let invite = Invite::decode(&code).map_err(err)?;
    let device = state.lock().unwrap().account.as_ref().map(|a| a.device.clone()).ok_or("Create an account first")?;
    let peer = peer_of(&net)?;
    let joined = tokio::time::timeout(Duration::from_secs(30), peer.join(&invite, &device))
        .await
        .map_err(|_| "Couldn’t reach the person or node that made this code. Ask them to keep Moot open and try again.".to_string())?
        .map_err(err)?;
    let mut s = state.lock().unwrap();
    let host = strip_ips(invite.host.clone());
    let addr = serde_json::to_string(&host).map_err(err)?;
    s.store.save_remote(&joined.community, &addr).map_err(err)?;
    let list = s.remotes.entry(joined.community).or_default();
    if !list.contains(&host) {
        list.push(host);
    }
    persist(&mut s)?;
    s.library.with(&joined.community, |c| community_info(c)).ok_or_else(|| "Unknown community".into())
}

#[tauri::command]
async fn sync_now(app: AppHandle, community: String) -> Result<SyncReport, String> {
    let id = EventId::from_hex(&community).map_err(err)?;
    Ok(sync_round(&app, Some(id)).await)
}

/// One pass over known peers (all communities, or just one), then persist what arrived.
async fn sync_round(app: &AppHandle, only: Option<EventId>) -> SyncReport {
    let mut total = SyncReport { applied: 0, already_had: 0, rejected: 0 };
    let net = app.state::<NetState>();
    let Ok(peer) = peer_of(&net) else { return total };
    let targets: Vec<(EventId, Vec<EndpointAddr>)> = {
        let s = app.state::<Shared>();
        let s = s.lock().unwrap();
        s.remotes.iter().filter(|(id, _)| only.map_or(true, |o| o == **id)).map(|(id, a)| (*id, a.clone())).collect()
    };
    let mut ok = 0;
    for (id, addrs) in targets {
        for addr in addrs {
            match tokio::time::timeout(Duration::from_secs(15), peer.sync_with(addr, id)).await {
                Ok(Ok(r)) => {
                    ok += 1;
                    total.applied += r.applied;
                    total.already_had += r.already_had;
                    total.rejected += r.rejected.len();
                }
                Ok(Err(e)) => *net.last_error.lock().unwrap() = Some(e.to_string()),
                Err(_) => *net.last_error.lock().unwrap() = Some("a peer took too long to answer".into()),
            }
        }
    }
    if ok > 0 {
        *net.last_error.lock().unwrap() = None;
        *net.synced.lock().unwrap() = ok;
    }
    let s = app.state::<Shared>();
    let _ = persist(&mut s.lock().unwrap());
    total
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let dir = app.path().app_data_dir()?;
            std::fs::create_dir_all(&dir)?;
            let (vault_key, key_source) = vault::load_or_create(&dir);
            let db_path = dir.join("moot.db");
            let mut locked_db_moved = None;
            let store = match Store::open(&db_path, vault_key.clone()) {
                Ok(s) => s,
                Err(e) if e.to_string().contains(WRONG_VAULT_KEY) => {
                    // The key for this database is gone (e.g. the OS keychain was reset).
                    // Keep the locked file — never delete user data — and start fresh; the
                    // account can be restored from its recovery phrase.
                    let aside = dir.join(format!("moot.db.locked-{}", moot_core::now_ms()));
                    for (from, suffix) in [("moot.db", ""), ("moot.db-wal", "-wal"), ("moot.db-shm", "-shm")] {
                        let mut to = aside.clone().into_os_string();
                        to.push(suffix);
                        let _ = std::fs::rename(dir.join(from), to);
                    }
                    locked_db_moved = Some(aside.display().to_string());
                    Store::open(&db_path, vault_key).map_err(|e| e.to_string())?
                }
                Err(e) => return Err(e.to_string().into()),
            };
            let account = store
                .load_account()
                .map_err(|e| e.to_string())?
                .map(|(identity, device, name)| Account { identity, device, name });
            let library = Library::default();
            let mut saved = HashMap::new();
            for (id, _) in store.list_communities().map_err(|e| e.to_string())? {
                if let Ok(c) = store.load_community(&id) {
                    saved.insert(id, c.len());
                    library.insert(c);
                }
            }
            let mut remotes: HashMap<EventId, Vec<EndpointAddr>> = HashMap::new();
            for (id, a) in store.load_remotes().map_err(|e| e.to_string())? {
                if let Ok(addr) = serde_json::from_str::<EndpointAddr>(&a) {
                    // Older builds remembered IP addresses; never use them.
                    let addr = strip_ips(addr);
                    let list = remotes.entry(id).or_default();
                    if !list.contains(&addr) {
                        list.push(addr);
                    }
                }
            }
            app.manage(Mutex::new(AppState { store, account, library, remotes, saved }));
            app.manage(NetState::default());
            app.manage(Security { key_source, locked_db_moved });

            // Go online in the background so the window opens instantly, even offline.
            let handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                let _ = restart_peer(&handle).await;
                let mut tick = tokio::time::interval(Duration::from_secs(4));
                loop {
                    tick.tick().await;
                    if handle.state::<NetState>().peer.lock().unwrap().is_none() {
                        let _ = restart_peer(&handle).await;
                        continue;
                    }
                    sync_round(&handle, None).await;
                }
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_account,
            create_account,
            restore_account,
            set_display_name,
            list_communities,
            create_community,
            post_message,
            list_messages,
            verify_all,
            network_status,
            privacy_report,
            list_badges,
            add_badge,
            set_hide_ip,
            invite_code,
            join_with_code,
            sync_now
        ])
        .run(tauri::generate_context!())
        .expect("error while running Moot");
}
