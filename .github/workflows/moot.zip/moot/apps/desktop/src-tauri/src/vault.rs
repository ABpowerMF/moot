//! Where the vault key (the key that unlocks the local database) lives.
//!
//! Preferred: the operating system's own secret store — Windows Credential Manager, the
//! macOS Keychain, or Secret Service (GNOME Keyring / KWallet) on Linux. Those are tied to
//! your OS login, so another user or a copied disk image can't read the key.
//!
//! Fallback, only when no OS store is available (e.g. a minimal Linux without a keyring
//! daemon): a key file in the app's data folder, readable only by you. The privacy check
//! screen says plainly when this fallback is in use.

use moot_core::VaultKey;
use std::path::{Path, PathBuf};

const SERVICE: &str = "app.moot.desktop";
const ACCOUNT: &str = "vault-key-v1";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum KeySource {
    /// Windows Credential Manager / macOS Keychain / Secret Service.
    Keychain,
    /// A user-only key file next to the database.
    File,
}

impl KeySource {
    pub fn label(self) -> &'static str {
        match self {
            KeySource::Keychain => match std::env::consts::OS {
                "windows" => "Windows Credential Manager",
                "macos" => "macOS Keychain",
                _ => "system keyring",
            },
            KeySource::File => "key file (no system keyring found)",
        }
    }
}

fn key_file(dir: &Path) -> PathBuf {
    dir.join("vault.key")
}

fn read_file(dir: &Path) -> Option<VaultKey> {
    std::fs::read_to_string(key_file(dir)).ok().and_then(|s| VaultKey::from_hex(&s).ok())
}

fn write_file(dir: &Path, key: &VaultKey) -> std::io::Result<()> {
    let path = key_file(dir);
    #[cfg(unix)]
    {
        use std::io::Write;
        use std::os::unix::fs::OpenOptionsExt;
        let mut f = std::fs::OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(&path)?;
        f.write_all(key.to_hex().as_bytes())?;
        f.sync_all()
    }
    #[cfg(not(unix))]
    {
        // On Windows the app-data folder is already private to the user account.
        std::fs::write(&path, key.to_hex())
    }
}

/// Overwrite then delete the fallback file once the key is safely in the keychain.
fn shred_file(dir: &Path) {
    let path = key_file(dir);
    if let Ok(meta) = std::fs::metadata(&path) {
        let _ = std::fs::write(&path, vec![0u8; meta.len() as usize]);
        let _ = std::fs::remove_file(&path);
    }
}

fn keychain_get() -> Result<Option<VaultKey>, keyring::Error> {
    let entry = keyring::Entry::new(SERVICE, ACCOUNT)?;
    match entry.get_password() {
        Ok(hex) => Ok(VaultKey::from_hex(&hex).ok()),
        Err(keyring::Error::NoEntry) => Ok(None),
        Err(e) => Err(e),
    }
}

fn keychain_set(key: &VaultKey) -> Result<(), keyring::Error> {
    let entry = keyring::Entry::new(SERVICE, ACCOUNT)?;
    entry.set_password(&key.to_hex())?;
    // Read it back: some keyrings accept writes they then can't return.
    match keychain_get()? {
        Some(k) if k.to_hex() == key.to_hex() => Ok(()),
        _ => Err(keyring::Error::NoEntry),
    }
}

/// Get the vault key, creating one on first run.
pub fn load_or_create(dir: &Path) -> (VaultKey, KeySource) {
    if std::env::var_os("MOOT_NO_KEYCHAIN").is_none() {
        match keychain_get() {
            Ok(Some(k)) => {
                shred_file(dir);
                return (k, KeySource::Keychain);
            }
            Ok(None) => {
                // First run, or upgrading from the file fallback: put the key in the keychain.
                let key = read_file(dir).unwrap_or_else(VaultKey::generate);
                if keychain_set(&key).is_ok() {
                    shred_file(dir);
                    return (key, KeySource::Keychain);
                }
            }
            Err(_) => {}
        }
    }
    let key = read_file(dir).unwrap_or_else(|| {
        let k = VaultKey::generate();
        let _ = write_file(dir, &k);
        k
    });
    (key, KeySource::File)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_dir() -> PathBuf {
        let d = std::env::temp_dir().join(format!("moot-vault-{}", VaultKey::generate().to_hex()));
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn file_fallback_is_stable_and_private() {
        std::env::set_var("MOOT_NO_KEYCHAIN", "1");
        let dir = temp_dir();
        let (a, src) = load_or_create(&dir);
        assert_eq!(src, KeySource::File);
        let (b, _) = load_or_create(&dir);
        assert_eq!(a.to_hex(), b.to_hex(), "the key must survive restarts");
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mode = std::fs::metadata(key_file(&dir)).unwrap().permissions().mode() & 0o777;
            assert_eq!(mode, 0o600, "key file must be readable only by its owner");
        }
        shred_file(&dir);
        assert!(!key_file(&dir).exists());
        let _ = std::fs::remove_dir_all(dir);
    }
}
