import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import App from "./App";
import { backend } from "./lib/backend";
import { AppProvider } from "./lib/state";

const mount = () => render(<AppProvider><App /></AppProvider>);
afterEach(cleanup);

describe("Moot interface", () => {
  it("opens on Discover with the featured community", async () => {
    mount();
    expect(await screen.findByRole("heading", { name: "Polaris Observatory" })).toBeTruthy();
    expect(screen.getByText("Popular communities")).toBeTruthy();
  });

  it("filters communities by category", async () => {
    mount();
    await screen.findByText("Popular communities");
    fireEvent.click(screen.getByRole("button", { name: "Music" }));
    expect(screen.getAllByText("Night Shift Radio").length).toBeGreaterThan(0);
    expect(screen.queryByText("Basalt Climbing Co.")).toBeNull();
  });

  it("sends a message in a sample channel", async () => {
    mount();
    await screen.findByText("Popular communities");
    fireEvent.click(screen.getByTitle("Pixel Foundry"));
    fireEvent.click((await screen.findAllByRole("button", { name: /shaders/ }))[0]);
    const box = await screen.findByLabelText("Message #shaders");
    fireEvent.change(box, { target: { value: "hello from the test" } });
    fireEvent.keyDown(box, { key: "Enter" });
    expect(await screen.findByText("hello from the test")).toBeTruthy();
  });

  it("creates a community through the backend and posts in it", async () => {
    mount();
    await screen.findByText("Popular communities");
    fireEvent.click(screen.getByTitle("Create or join a community"));
    fireEvent.change(screen.getByPlaceholderText("e.g. Lisbon Game Makers"), { target: { value: "Test Guild" } });
    fireEvent.click(screen.getByRole("button", { name: "Next" }));
    await act(async () => { fireEvent.click(screen.getByRole("button", { name: "Create community" })); });
    expect(await screen.findByText(/You created Test Guild/)).toBeTruthy();
    const box = screen.getByLabelText("Message #general");
    fireEvent.change(box, { target: { value: "first signed message" } });
    await act(async () => { fireEvent.keyDown(box, { key: "Enter" }); });
    await waitFor(() => expect(screen.getByText("first signed message")).toBeTruthy());
    const list = await backend.listCommunities();
    expect(list.some((c) => c.name === "Test Guild")).toBe(true);
  });

  it("changes the accent colour from settings", async () => {
    mount();
    await screen.findByText("Popular communities");
    fireEvent.click(screen.getByTitle("Settings"));
    fireEvent.click(screen.getByRole("button", { name: /Appearance/ }));
    fireEvent.click(screen.getByLabelText("Accent #3DD68C"));
    expect(document.documentElement.style.getPropertyValue("--acc")).toBe("#3DD68C");
  });

  it("shares a game from Ludus in a DM", async () => {
    mount();
    await screen.findByText("Popular communities");
    fireEvent.click(screen.getByTitle("Direct messages"));
    fireEvent.click(await screen.findByTitle("Share a game from Ludus"));
    fireEvent.click(await screen.findByRole("button", { name: /Saltwind/ }));
    expect((await screen.findAllByText("Saltwind")).length).toBeGreaterThan(0);
  });
});
