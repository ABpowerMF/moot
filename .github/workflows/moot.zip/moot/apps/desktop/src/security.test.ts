// The privacy check screen promises that no outside content loads (so no image, font or
// embed can log your IP). These tests fail the build if that stops being true.
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

const conf = JSON.parse(readFileSync(join(__dirname, "../src-tauri/tauri.conf.json"), "utf8"));
const csp: string = conf.app.security.csp;
const directives = Object.fromEntries(csp.split(";").map((d) => d.trim().split(/\s+/)).map(([k, ...v]) => [k, v]));

function files(dir: string): string[] {
  return readdirSync(dir).flatMap((f) => {
    const p = join(dir, f);
    return statSync(p).isDirectory() ? files(p) : [p];
  });
}

describe("no outside content", () => {
  it("the content security policy allows no other websites", () => {
    for (const [name, sources] of Object.entries(directives)) {
      for (const src of sources as string[]) {
        const external = /^https?:/.test(src) && src !== "http://ipc.localhost";
        expect(external, `${name} allows ${src}`).toBe(false);
        expect(src, `${name} allows everything`).not.toBe("*");
      }
    }
    for (const locked of ["object-src", "frame-src", "base-uri", "form-action"]) {
      expect(directives[locked], locked).toEqual(["'none'"]);
    }
    expect(directives["script-src"]).toEqual(["'self'"]);
  });

  it("the interface source references no remote URLs to load", () => {
    const offenders: string[] = [];
    for (const f of files(join(__dirname))) {
      if (!/\.(tsx?|css|html)$/.test(f) || f.endsWith(".test.ts") || f.endsWith(".test.tsx")) continue;
      const text = readFileSync(f, "utf8");
      // url(...), src=, @import or fetch() pointing at http(s)
      const bad = text.match(/(url\(\s*["']?|src=["'{]\s*["']?|@import\s+(url\()?["']?|fetch\(\s*["'`])https?:\/\//g);
      if (bad) offenders.push(`${f}: ${bad.join(", ")}`);
    }
    expect(offenders).toEqual([]);
  });

  it("the window gets no global Tauri object and a frozen prototype", () => {
    expect(conf.app.withGlobalTauri).toBe(false);
    expect(conf.app.security.freezePrototype).toBe(true);
  });
});
