// Left column inside a community: banner, channels by category, voice occupants, and you.
import { COMMUNITIES, MEMBERS, PEOPLE, PIXEL_CHANNELS, VOICE_USERS, type ChannelDef } from "../data/sample";
import { useState } from "react";
import { backend } from "../lib/backend";
import { useApp } from "../lib/state";
import { Icon } from "./Icon";
import { Avatar } from "./ui";

const iconFor = (k: ChannelDef["kind"]) => (k === "voice" ? "speaker" : k === "announcement" ? "megaphone" : "hash");

export function CommunitySidebar({ id, active }: { id: string; active?: string }) {
  const { go, myCommunities, inVoice, setInVoice, toast } = useApp();
  const [invite, setInvite] = useState<string | null>(null);
  const showInvite = async () => {
    if (!real) { toast("Invite link copied — expires in 7 days"); return; }
    try { setInvite(await backend.inviteCode(id)); } catch (e) { toast(String(e)); }
  };
  const sample = COMMUNITIES[id];
  const real = myCommunities.find((c) => c.id === id);
  const name = sample?.name ?? real?.name ?? "Community";
  const groups: { category: string; channels: ChannelDef[] }[] = sample
    ? PIXEL_CHANNELS
    : [
        { category: "Text", channels: (real?.channels ?? []).filter((c) => c.kind !== "Voice").map((c) => ({ id: c.id, name: c.name, kind: c.kind === "Announcement" ? "announcement" : "text" })) },
        { category: "Voice", channels: (real?.channels ?? []).filter((c) => c.kind === "Voice").map((c) => ({ id: c.id, name: c.name, kind: "voice" })) },
      ];

  const open = (c: ChannelDef) => {
    if (c.kind === "voice") {
      setInVoice(c.id);
      go({ name: "voice", id, channel: c.id });
    } else go({ name: "channel", id, channel: c.id });
  };

  return (
    <aside className="cside">
      <div className="cside-banner">
        {sample ? <img src={sample.banner} alt="" /> : <div style={{ width: "100%", height: "100%", background: "radial-gradient(120% 90% at 20% 10%, #1f2a3a, var(--bg1))" }} />}
        <div className="cside-name">
          <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</span>
          {sample && <span className="badge glass"><Icon name="shield" size={11} /> Verified</span>}
          <button className="ibtn" style={{ width: 28, height: 28 }} title="Invite people" onClick={showInvite}><Icon name="down" size={16} /></button>
        </div>
      </div>
      <div className="cside-list">
        <button className={`ch${!active ? " active" : ""}`} onClick={() => go({ name: "community", id })}><Icon name="home" size={17} /> Home</button>
        {real && <button className="ch" onClick={showInvite}><Icon name="userplus" size={17} /> Invite people</button>}
        {sample && <button className="ch" onClick={() => go({ name: "channel", id, channel: "shaders" })}><Icon name="thread" size={17} /> Threads <span className="n" style={{ background: "var(--bg4)", color: "var(--t1)" }}>3</span></button>}
        {groups.filter((g) => g.channels.length).map((g) => (
          <div key={g.category}>
            <div className="cat"><span className="label">{g.category}</span></div>
            {g.channels.map((c) => (
              <div key={c.id}>
                <button className={`ch${c.unread ? " unread" : ""}${active === c.id ? " active" : ""}`} onClick={() => open(c)}>
                  <Icon name={iconFor(c.kind)} size={17} />
                  <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.name}</span>
                  {c.mentions ? <span className="n">{c.mentions}</span> : null}
                </button>
                {c.kind === "voice" && (VOICE_USERS[c.id] || inVoice === c.id) && (
                  <div className="vusers">
                    {[...(inVoice === c.id ? ["leo"] : []), ...(VOICE_USERS[c.id] ?? [])].map((p) => (
                      <div key={p} className="vuser"><Avatar id={p} size={20} /> {PEOPLE[p].name.split(" ")[0]}{p === "mei" && <Icon name="wave" size={13} color="var(--on)" />}</div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
      </div>
      {inVoice && (
        <div className="voice-bar">
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Icon name="wave" size={16} color="var(--on)" />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: "600 12.5px var(--ui)", color: "var(--on)" }}>Voice connected</div>
              <div style={{ font: "500 11.5px var(--ui)", color: "var(--t3)" }}>{inVoice.replace(/-/g, " ")} · 24 ms</div>
            </div>
            <button className="ibtn" style={{ width: 30, height: 30 }} title="Open call" onClick={() => go({ name: "voice", id: "pixel", channel: inVoice })}><Icon name="video" size={16} /></button>
            <button className="ibtn" style={{ width: 30, height: 30 }} title="Leave call" onClick={() => { setInVoice(null); toast("Left voice"); }}><Icon name="leave" size={16} /></button>
          </div>
        </div>
      )}
      <MeBar />
      {invite && <InviteDialog code={invite} name={name} onClose={() => setInvite(null)} />}
    </aside>
  );
}

function InviteDialog({ code, name, onClose }: { code: string; name: string; onClose: () => void }) {
  const { toast } = useApp();
  const copy = async () => {
    try { await navigator.clipboard.writeText(code); toast("Invite code copied"); } catch { toast("Select the code and copy it"); }
  };
  return (
    <div className="overlay-scrim" onClick={onClose}>
      <div className="dialog" style={{ width: 520, padding: 24 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", alignItems: "center", marginBottom: 10 }}><b style={{ font: "800 22px var(--disp)", flex: 1 }}>Invite people to {name}</b><button className="ibtn" onClick={onClose}><Icon name="x" size={16} /></button></div>
        <div style={{ color: "var(--t2)", lineHeight: 1.55, marginBottom: 14 }}>Send this code to a friend. In Moot they press <b>+</b> → <b>Join with a code</b>. Their app connects straight to yours (or through a relay if it has to) — no server in between.</div>
        <textarea className="textarea mono" readOnly rows={5} value={code} onFocus={(e) => e.currentTarget.select()} style={{ fontSize: 11.5, wordBreak: "break-all" }} />
        <div className="hint">While your app is closed, people can only sync if a community node is hosting it.</div>
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 16 }}><button className="btn secondary" onClick={onClose}>Done</button><button className="btn primary" onClick={copy}><Icon name="copy" size={15} /> Copy code</button></div>
      </div>
    </div>
  );
}

export function MeBar() {
  const { account, go } = useApp();
  return (
    <div className="me-bar">
      <Avatar id="leo" size={34} presence="on" ring="var(--bg0)" />
      <button style={{ flex: 1, minWidth: 0, border: 0, background: "none", padding: 0, textAlign: "left" }} onClick={() => go({ name: "profile" })}>
        <div style={{ font: "600 13px var(--ui)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{account?.display_name ?? "Leo Carvalho"}</div>
        <div className="mono" style={{ fontSize: 10.5, color: "var(--t3)" }}>{account?.fingerprint ?? "7F3A 91C2 4E0D B6A1"}</div>
      </button>
      <button className="ibtn" style={{ width: 30, height: 30 }} title="Settings" onClick={() => go({ name: "settings" })}><Icon name="sliders" size={16} /></button>
    </div>
  );
}

export function MemberList() {
  return (
    <aside className="members">
      {MEMBERS.map((g) => (
        <div key={g.group} style={{ marginBottom: 14 }}>
          <div className="label" style={{ padding: "6px 8px 8px" }}>{g.group}</div>
          {g.people.map((m) => (
            <div key={m.id} className="member" style={{ opacity: m.presence === "off" ? 0.5 : 1 }}>
              <Avatar id={m.id} size={32} presence={m.presence} />
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, font: "600 13px var(--ui)" }}>
                  <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{PEOPLE[m.id].name}</span>
                  {m.role === "owner" && <Icon name="crown" size={13} color="var(--idle)" />}
                  {m.role === "mod" && <Icon name="shield" size={13} color="var(--acc)" />}
                </div>
                {m.activity && <div style={{ font: "500 11.5px var(--ui)", color: "var(--t3)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m.activity}</div>}
              </div>
            </div>
          ))}
        </div>
      ))}
    </aside>
  );
}
