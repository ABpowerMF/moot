// The window frame: community rail, title bar with window controls, and the network status strip.
import { useState } from "react";
import { COMMUNITIES, RAIL_COMMUNITIES } from "../data/sample";
import { windowControl, isTauri } from "../lib/backend";
import { useApp, type Screen } from "../lib/state";
import { Icon } from "./Icon";
import { Avatar, Logo } from "./ui";

const communityOf = (s: Screen): string | null => ("id" in s ? s.id : null);

export function Rail() {
  const { screen, go, openModal, myCommunities, inVoice } = useApp();
  const current = communityOf(screen);
  const item = (active: boolean, extra = "") => `rail-item${active ? " active" : ""}${extra}`;
  return (
    <nav className="rail" aria-label="Communities">
      <div className="rail-group">
        <div className="rail-logo"><Logo size={36} /></div>
        <button className={item(screen.name === "dms", " glyph")} title="Direct messages" onClick={() => go({ name: "dms" })}>
          <Icon name="chat" size={20} /><span className="rail-badge">7</span>
        </button>
        <button className={item(screen.name === "discover", " glyph")} title="Discover" onClick={() => go({ name: "discover" })}>
          <Icon name="compass" size={20} />
        </button>
        <div className="rail-sep" />
        {RAIL_COMMUNITIES.map((r) => {
          const cm = COMMUNITIES[r.id];
          return (
            <button key={r.id} className={item(current === r.id)} title={cm.name} onClick={() => go({ name: "community", id: r.id })}>
              {r.unread && current !== r.id && <span className="rail-unread" />}
              <img src={cm.icon} alt={cm.name} />
              {r.badge && <span className="rail-badge">{r.badge}</span>}
              {r.id === "pixel" && inVoice && <span className="rail-dot" style={{ top: -2, right: -2, width: 10, height: 10 }} />}
            </button>
          );
        })}
        {myCommunities.map((cm) => (
          <button key={cm.id} className={item(current === cm.id, " glyph")} title={cm.name} onClick={() => go({ name: "channel", id: cm.id, channel: "general" })}>
            <span style={{ font: "700 16px var(--disp)" }}>{cm.name.slice(0, 2)}</span>
          </button>
        ))}
        <button className="rail-item add" title="Create or join a community" onClick={() => openModal("create")}><Icon name="plus" size={20} /></button>
      </div>
      <div className="rail-group">
        <button className={`rail-small${screen.name === "network" ? " active" : ""}`} title="Network & nodes" onClick={() => go({ name: "network" })}>
          <Icon name="nodes" size={20} /><span className="rail-dot" />
        </button>
        <button className={`rail-small${screen.name === "settings" ? " active" : ""}`} title="Settings" onClick={() => go({ name: "settings" })}><Icon name="sliders" size={20} /></button>
        <button className={`rail-small${screen.name === "profile" ? " active" : ""}`} title="Your profile" style={{ padding: 0 }} onClick={() => go({ name: "profile" })}>
          <Avatar id="leo" size={34} presence="on" ring="var(--bg0)" />
        </button>
      </div>
    </nav>
  );
}

function crumbs(s: Screen, mine: { id: string; name: string }[]): string[] {
  const name = (id: string) => COMMUNITIES[id]?.name ?? mine.find((m) => m.id === id)?.name ?? "Community";
  switch (s.name) {
    case "discover": return ["Discover"];
    case "community": return [name(s.id), "Home"];
    case "channel": return [name(s.id), `# ${s.channel}`];
    case "voice": return [name(s.id), s.channel.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())];
    case "dms": return ["Direct messages"];
    case "profile": return ["Profile"];
    case "settings": return ["Settings", s.section ?? "Account"];
    case "network": return ["Network & nodes"];
    case "overlay": return ["In-game overlay"];
  }
}

export function TitleBar() {
  const { screen, back, myCommunities, toast } = useApp();
  const [q, setQ] = useState("");
  const parts = crumbs(screen, myCommunities);
  return (
    <header className="titlebar" data-tauri-drag-region>
      <div className="crumb" data-tauri-drag-region>
        <button className="ibtn" style={{ width: 28, height: 28, marginLeft: -8 }} onClick={back} title="Back"><Icon name="left" size={16} /></button>
        {parts.map((p, i) => (
          <span key={i} style={{ display: "contents" }}>
            {i > 0 && <span className="sep">/</span>}
            <span className={i < parts.length - 1 ? "dim" : ""}>{p}</span>
          </span>
        ))}
      </div>
      <form className="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) toast(`Searching your communities for “${q.trim()}” — search is on the roadmap`); }}>
        <Icon name="search" size={15} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search communities, people, messages" aria-label="Search" />
        <span className="kbd">Ctrl K</span>
      </form>
      <div className="titlebar-right">
        <button className="ibtn" title="Inbox" onClick={() => toast("Inbox: 3 mentions, 1 invite")}><Icon name="inbox" size={18} /></button>
        <button className="ibtn" title="Notifications" onClick={() => toast("Quiet hours are on until 08:00")}><Icon name="bell" size={18} /></button>
        <span className="vsep" />
        <button className="ibtn" title="Minimise" onClick={() => windowControl("minimize")} disabled={!isTauri()}><Icon name="min" size={16} /></button>
        <button className="ibtn" title="Maximise" onClick={() => windowControl("maximize")} disabled={!isTauri()}><Icon name="max" size={14} /></button>
        <button className="ibtn" title="Close" onClick={() => windowControl("close")} disabled={!isTauri()}><Icon name="x" size={16} /></button>
      </div>
    </header>
  );
}

export function StatusStrip() {
  const { go, settings } = useApp();
  return (
    <button className="strip" onClick={() => go({ name: "network" })} title="Open network & nodes">
      <span className="ok"><span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--on)" }} /> Online · encrypted</span>
      <span className="slash">/</span>
      <span>14 peers</span>
      <span className="slash">/</span>
      <span>3 community nodes</span>
      <span className="slash">/</span>
      <span style={settings.hideIp ? undefined : { color: "var(--idle)" }}>{settings.hideIp ? "IP hidden · relay only" : "Direct connections · peers can see your IP"}</span>
      <span style={{ marginLeft: "auto" }}>{isTauri() ? "desktop" : "web preview"} · moot 0.2.0</span>
    </button>
  );
}

export function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="toast-wrap" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="toast"><Icon name="check" size={16} color="var(--acc)" /> {t.text}</div>
      ))}
    </div>
  );
}
