// "Who can see your IP" — a plain-language check, built from live facts reported by the core.
import { useEffect, useState } from "react";
import { backend, type PrivacyReport } from "../lib/backend";
import { useApp } from "../lib/state";
import { Icon } from "./Icon";
import { Toggle } from "./ui";

type Level = "good" | "warn" | "bad";
const COLOR: Record<Level, string> = { good: "var(--on)", warn: "var(--idle)", bad: "var(--dnd)" };
const ICON: Record<Level, string> = { good: "check", warn: "alert", bad: "x" };

function host(url: string | null): string {
  if (!url) return "a relay";
  try { return new URL(url).host; } catch { return url; }
}

export function PrivacyCheck({ compact }: { compact?: boolean }) {
  const { settings, set } = useApp();
  const [r, setR] = useState<PrivacyReport | null>(null);

  useEffect(() => {
    let live = true;
    const load = () => backend.privacyReport().then((x) => live && setR(x)).catch(() => {});
    load();
    const t = setInterval(load, 3000);
    return () => { live = false; clearInterval(t); };
  }, [settings.hideIp]);

  if (!r) return <div className="card"><div className="hint">Checking your privacy…</div></div>;

  const rows: { level: Level; title: string; sub: string }[] = [
    r.hide_ip && r.ip_sockets === 0
      ? { level: "good", title: "People you talk to can’t see your IP", sub: "Everything goes through a relay. Moot has no IP connection open to anyone." }
      : { level: "bad", title: "People you connect to can see your IP", sub: "Direct connections are on. Turn on “Hide my IP” to route everything through a relay." },
    { level: "warn", title: `The relay (${host(r.relay)}) can see your IP`, sub: "It can’t read anything you send — it only forwards scrambled data between keys." },
    r.invites_ip_free
      ? { level: "good", title: "Your invite codes contain no IP address", sub: "Only your public key and the relay. IPs in codes from others are ignored." }
      : { level: "bad", title: "Your invite codes would include your IP", sub: "This shouldn’t happen — please report it." },
    r.paths.direct === 0
      ? { level: "good", title: `${r.paths.via_relay} connection${r.paths.via_relay === 1 ? "" : "s"} this session, all through the relay`, sub: "No one has reached you directly." }
      : { level: r.hide_ip ? "bad" : "warn", title: `${r.paths.direct} direct connection${r.paths.direct === 1 ? "" : "s"} this session`, sub: "Those peers saw your IP address." },
    { level: "good", title: "No outside content loads", sub: "Images, link previews and embeds never come from other websites, so they can’t log your IP." },
    r.key_in_keychain
      ? { level: "good", title: `Keys locked in ${r.key_storage}`, sub: "Your local data is encrypted; the key is held by your system’s vault." }
      : { level: "warn", title: `Keys protected by a ${r.key_storage}`, sub: "Your local data is encrypted, but no system vault was available to hold the key." },
  ];
  const shown = compact ? rows.slice(0, 4) : rows;

  return (
    <div className="card">
      <div className="card-head"><Icon name="shield" size={18} /><h3 className="grow">Who can see your IP</h3>
        <span style={{ display: "flex", alignItems: "center", gap: 10, font: "500 13px var(--ui)", color: "var(--t2)" }}>Hide my IP <Toggle on={settings.hideIp} onChange={(v) => set("hideIp", v)} label="Hide my IP" /></span>
      </div>
      {r.locked_db_moved && (
        <div className="row" style={{ background: "rgba(245,181,68,.08)", borderRadius: 8, padding: "10px 12px", marginBottom: 6 }}>
          <Icon name="alert" size={17} color="var(--idle)" />
          <div className="grow"><div className="t">An old database couldn’t be unlocked</div><div className="s">Its key was missing, so it was kept aside (not deleted) and a fresh one started. Restore your account with your recovery phrase.</div></div>
        </div>
      )}
      {shown.map((x) => (
        <div key={x.title} className="row">
          <span style={{ width: 26, height: 26, borderRadius: 8, flex: "none", display: "grid", placeItems: "center", background: "var(--bg3)" }}><Icon name={ICON[x.level]} size={15} color={COLOR[x.level]} /></span>
          <div className="grow"><div className="t">{x.title}</div><div className="s">{x.sub}</div></div>
        </div>
      ))}
    </div>
  );
}
