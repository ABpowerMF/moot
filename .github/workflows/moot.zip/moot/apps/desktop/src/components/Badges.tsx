// Security researcher badges: signed by the Moot security team, shown on your profile.
import { useEffect, useState } from "react";
import { backend, type BadgeInfo } from "../lib/backend";
import { useApp } from "../lib/state";
import { Icon } from "./Icon";

const TIER: Record<BadgeInfo["tier"], { label: string; color: string; note: string }> = {
  Finder: { label: "Finder", color: "#9FC5FF", note: "Reported a low-severity issue" },
  Hunter: { label: "Hunter", color: "#4AA3FF", note: "Reported a serious issue" },
  Legend: { label: "Legend", color: "#F5B544", note: "Reported a critical issue" },
};

export function BadgeChip({ b }: { b: BadgeInfo }) {
  const t = TIER[b.tier];
  return (
    <div className="row" title={`${t.note} · signed by the Moot security team`}>
      <span style={{ width: 34, height: 34, borderRadius: 10, flex: "none", display: "grid", placeItems: "center", background: "var(--bg3)", boxShadow: `inset 0 0 0 1.5px ${t.color}` }}>
        <Icon name="shield" size={17} color={t.color} />
      </span>
      <div className="grow">
        <div className="t" style={{ display: "flex", alignItems: "center", gap: 8 }}>Security {t.label}<span className="badge good"><Icon name="check" size={10} /> Verified</span></div>
        <div className="s">{b.title}{b.advisory ? ` · ${b.advisory}` : ""} · {new Date(b.issued_ms).toLocaleDateString()}</div>
      </div>
    </div>
  );
}

export function useBadges(): [BadgeInfo[], () => void] {
  const [list, setList] = useState<BadgeInfo[]>([]);
  const reload = () => { backend.listBadges().then(setList).catch(() => {}); };
  useEffect(reload, []);
  return [list, reload];
}

export function BadgeSettings() {
  const { account, toast } = useApp();
  const [badges, reload] = useBadges();
  const [code, setCode] = useState("");
  const add = async () => {
    try { const b = await backend.addBadge(code); setCode(""); reload(); toast(`Badge added: Security ${b.tier}`); }
    catch (e) { toast(String(e)); }
  };
  const copyKey = async () => {
    try { await navigator.clipboard.writeText(account?.identity ?? ""); toast("Public key copied"); } catch { toast("Select the key and copy it"); }
  };
  return (
    <div className="card" style={{ marginTop: 16 }}>
      <div className="card-head"><Icon name="spark" size={18} /><h3 className="grow">Security badges</h3></div>
      <div className="s" style={{ color: "var(--t3)", fontSize: 13, lineHeight: 1.5, marginBottom: 10 }}>
        Found a security bug? Report it privately (see SECURITY.md). Once it’s fixed you get a signed badge for your profile — send the team your public key below.
      </div>
      <div className="row">
        <div className="grow"><div className="t">Your public key</div><div className="s mono" style={{ wordBreak: "break-all", fontSize: 11 }}>{account?.identity ?? "—"}</div></div>
        <button className="btn secondary sm" onClick={copyKey}><Icon name="copy" size={14} /> Copy</button>
      </div>
      {badges.map((b) => <BadgeChip key={b.title + b.issued_ms} b={b} />)}
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <input className="input mono" style={{ fontSize: 12 }} value={code} onChange={(e) => setCode(e.target.value)} placeholder="Paste a badge code (mootbadge1…)" aria-label="Badge code" />
        <button className="btn primary" disabled={!code.trim().startsWith("mootbadge1")} onClick={add}>Add</button>
      </div>
    </div>
  );
}
