// Small shared pieces: avatars, the Sidekick mark, toggles, segmented controls, game covers.
import type { CSSProperties, ReactNode } from "react";
import sidekick from "../assets/sidekick.svg";
import { GAMES, PEOPLE, img, type Presence } from "../data/sample";
import { Icon } from "./Icon";

const PRESENCE_COLOR: Record<Presence, string> = { on: "var(--on)", idle: "var(--idle)", dnd: "var(--dnd)", off: "#5b5e66" };

export function Avatar({ id, src, size = 36, presence, ring = "var(--bg1)" }: { id?: string; src?: string; size?: number; presence?: Presence; ring?: string }) {
  const url = src ?? (id ? PEOPLE[id]?.avatar : undefined);
  const dot = Math.max(9, Math.round(size * 0.3));
  return (
    <span className="avatar" style={{ width: size, height: size }}>
      {url ? <img src={url} width={size} height={size} alt="" /> : <span style={{ width: size, height: size, borderRadius: "50%", background: "var(--bg4)", display: "grid", placeItems: "center", font: `700 ${size * 0.4}px var(--disp)` }}>{(id ?? "?")[0].toUpperCase()}</span>}
      {presence && <span className="presence" style={{ width: dot, height: dot, background: PRESENCE_COLOR[presence], boxShadow: `0 0 0 3px ${ring}` }} />}
    </span>
  );
}

export function Logo({ size = 36 }: { size?: number }) {
  return <img src={sidekick} width={size} height={size} alt="Moot" style={{ display: "block", borderRadius: size * 0.28 }} />;
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return <button type="button" role="switch" aria-checked={on} aria-label={label} className={`toggle${on ? " on" : ""}`} onClick={() => onChange(!on)} />;
}

export function Segmented<T extends string>({ value, options, onChange, fill }: { value: T; options: { value: T; label: ReactNode }[]; onChange: (v: T) => void; fill?: boolean }) {
  return (
    <div className={`seg${fill ? " fill" : ""}`} role="tablist">
      {options.map((o) => (
        <button key={o.value} type="button" role="tab" aria-selected={value === o.value} className={value === o.value ? "on" : ""} onClick={() => onChange(o.value)}>{o.label}</button>
      ))}
    </div>
  );
}

export function GameCover({ game, h = 120, style, children }: { game: string; h?: number | string; style?: CSSProperties; children?: ReactNode }) {
  const g = GAMES[game];
  const src = game === "pinehollow" ? img("game_pinehollow") : img(`b_${g?.art ?? "pixel"}`);
  return (
    <div style={{ position: "relative", height: h, borderRadius: 10, overflow: "hidden", background: "var(--bg3)", ...style }}>
      <img className="zoom" src={src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: g?.pos ?? "50% 50%", display: "block" }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, transparent 40%, rgba(5,6,8,.85))" }} />
      {children}
    </div>
  );
}

export function SettingRow({ title, sub, children }: { title: ReactNode; sub?: ReactNode; children?: ReactNode }) {
  return (
    <div className="row">
      <div className="grow"><div className="t">{title}</div>{sub && <div className="s">{sub}</div>}</div>
      {children}
    </div>
  );
}

export function LudusMark({ size = 18 }: { size?: number }) {
  return (
    <span style={{ width: size, height: size, borderRadius: size * 0.3, background: "var(--t1)", color: "var(--bg0)", display: "inline-grid", placeItems: "center", flex: "none" }}>
      <Icon name="play" size={size * 0.6} color="var(--bg0)" stroke={2.4} />
    </span>
  );
}

export function Panel({ children, style }: { children: ReactNode; style?: CSSProperties }) {
  return <div className="card" style={style}>{children}</div>;
}
