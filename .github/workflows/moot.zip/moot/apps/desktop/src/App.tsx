import { useEffect } from "react";
import { Rail, StatusStrip, TitleBar, Toasts } from "./components/Shell";
import { useApp } from "./lib/state";
import { Channel } from "./screens/Channel";
import { CommunityHome } from "./screens/CommunityHome";
import { Discover } from "./screens/Discover";
import { DMs } from "./screens/DMs";
import { CreateCommunity, LudusConnect } from "./screens/Modals";
import { Network } from "./screens/Network";
import { Onboarding } from "./screens/Onboarding";
import { Overlay } from "./screens/Overlay";
import { Profile } from "./screens/Profile";
import { Settings } from "./screens/Settings";
import { Voice } from "./screens/Voice";

function Current() {
  const { screen } = useApp();
  switch (screen.name) {
    case "discover": return <Discover />;
    case "community": return <CommunityHome id={screen.id} />;
    case "channel": return <Channel key={`${screen.id}/${screen.channel}`} id={screen.id} channel={screen.channel} />;
    case "voice": return <Voice key={screen.channel} id={screen.id} channel={screen.channel} />;
    case "dms": return <DMs />;
    case "profile": return <Profile />;
    case "settings": return <Settings section={screen.section} />;
    case "network": return <Network />;
    case "overlay": return null;
  }
}

export default function App() {
  const { screen, go, modal, openModal, account, accountLoaded } = useApp();

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        document.querySelector<HTMLInputElement>(".search input")?.focus();
      }
      if (e.key === "Escape" && modal) openModal(null);
      if (e.shiftKey && (e.key === "`" || e.key === "~") && screen.name !== "overlay") go({ name: "overlay" });
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [modal, openModal, go, screen.name]);

  if (!accountLoaded) return <div className="app" />;
  if (!account) return <div className="app"><Onboarding /><Toasts /></div>;

  return (
    <div className="app">
      <div className="app-row">
        <Rail />
        <main className="app-main">
          <TitleBar />
          <Current />
        </main>
      </div>
      <StatusStrip />
      {screen.name === "overlay" && <Overlay />}
      {modal === "create" && <CreateCommunity />}
      {modal === "ludus" && <LudusConnect />}
      <Toasts />
    </div>
  );
}
