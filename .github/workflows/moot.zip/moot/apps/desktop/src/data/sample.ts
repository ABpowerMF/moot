// Sample data for the prototype. Real communities and messages come from the Rust core
// (see lib/backend.ts); everything here is placeholder content for the approved mockups.

const imgs = import.meta.glob("../assets/img/*.jpg", { eager: true, query: "?url", import: "default" }) as Record<string, string>;
export const img = (name: string): string => imgs[`../assets/img/${name}.jpg`] ?? "";

export type Presence = "on" | "idle" | "dnd" | "off";

export interface Person {
  id: string;
  name: string;
  handle: string;
  avatar: string;
}

const avatarFor = (i: number) => img(`a_${String(i).padStart(2, "0")}`);

export const PEOPLE: Record<string, Person> = {
  leo: { id: "leo", name: "Leo Carvalho", handle: "leoc", avatar: avatarFor(0) },
  mei: { id: "mei", name: "Mei Lin", handle: "meilin", avatar: avatarFor(1) },
  tomas: { id: "tomas", name: "Tomás Reis", handle: "treis", avatar: avatarFor(2) },
  ife: { id: "ife", name: "Ife Adebayo", handle: "ife", avatar: avatarFor(3) },
  jonah: { id: "jonah", name: "Jonah Park", handle: "jpark", avatar: avatarFor(4) },
  kai: { id: "kai", name: "Kai Okafor", handle: "kai.o", avatar: avatarFor(5) },
  sasha: { id: "sasha", name: "Sasha Volkov", handle: "sashav", avatar: avatarFor(6) },
  ravi: { id: "ravi", name: "Ravi Menon", handle: "ravi", avatar: avatarFor(7) },
  elena: { id: "elena", name: "Elena Duarte", handle: "elenad", avatar: avatarFor(8) },
  nadia: { id: "nadia", name: "Nadia Kovač", handle: "nadia", avatar: avatarFor(9) },
  theo: { id: "theo", name: "Theo Brandt", handle: "theob", avatar: avatarFor(10) },
  amara: { id: "amara", name: "Amara Osei", handle: "amara", avatar: avatarFor(11) },
};

export interface Community {
  id: string;
  name: string;
  description: string;
  members: string;
  online: string;
  category: string;
  art: string;
  banner: string;
  icon: string;
  real?: boolean;
}

const c = (id: string, art: string, name: string, description: string, members: string, online: string, category: string): Community => ({
  id, art, name, description, members, online, category, banner: img(`b_${art}`), icon: img(`i_${art}`),
});

export const COMMUNITIES: Record<string, Community> = {
  pixel: c("pixel", "pixel", "Pixel Foundry", "Indie game developers trading devlogs, shader tricks and honest playtest feedback.", "12.4k", "1,284", "Game dev"),
  polaris: c("polaris", "polaris", "Polaris Observatory", "Amateur astronomers sharing night-sky captures, star parties and gear advice.", "18.2k", "2,140", "Science"),
  nightshift: c("nightshift", "nightshift", "Night Shift Radio", "Late-night listening parties, crate digging and producer feedback.", "9.7k", "812", "Music"),
  basalt: c("basalt", "basalt", "Basalt Climbing Co.", "Route beta, trip planning and training logs for climbers of every grade.", "4.3k", "296", "Outdoors"),
  lowlight: c("lowlight", "lowlight", "Lowlight Cinema Club", "Weekly watch parties, director deep-dives and short-film critique.", "6.1k", "433", "Film"),
  fern: c("fern", "fern", "Fernhollow Tabletop", "Looking-for-group, homebrew rules and long-running campaigns.", "7.8k", "655", "Tabletop"),
  tidepool: c("tidepool", "tidepool", "Tidepool Photo", "Photographers posting work, gear talk and monthly critique circles.", "11.0k", "947", "Art"),
  saltflat: c("saltflat", "saltflat", "Saltflat Synths", "Modular patches, synth repair and live-coding sessions.", "3.2k", "188", "Music"),
};

export const RAIL_COMMUNITIES: { id: string; badge?: number; unread?: boolean }[] = [
  { id: "pixel", unread: true },
  { id: "polaris", badge: 2 },
  { id: "nightshift", unread: true },
  { id: "lowlight" },
  { id: "basalt", badge: 1 },
  { id: "fern" },
];

export type ChannelKind = "text" | "voice" | "announcement";
export interface ChannelDef {
  id: string;
  name: string;
  kind: ChannelKind;
  mentions?: number;
  unread?: boolean;
}

export const PIXEL_CHANNELS: { category: string; channels: ChannelDef[] }[] = [
  { category: "Start here", channels: [
    { id: "announcements", name: "announcements", kind: "announcement" },
    { id: "welcome", name: "welcome", kind: "text" },
    { id: "rules", name: "rules", kind: "text" },
  ] },
  { category: "Build", channels: [
    { id: "devlog", name: "devlog", kind: "text", mentions: 4, unread: true },
    { id: "shaders", name: "shaders", kind: "text" },
    { id: "art-critique", name: "art-critique", kind: "text", mentions: 12, unread: true },
    { id: "audio", name: "audio", kind: "text" },
    { id: "playtests", name: "playtests", kind: "text", unread: true },
  ] },
  { category: "Voice", channels: [
    { id: "studio-floor", name: "Studio Floor", kind: "voice" },
    { id: "playtest-room", name: "Playtest Room", kind: "voice" },
    { id: "late-night-jam", name: "Late Night Jam", kind: "voice" },
  ] },
];

export const VOICE_USERS: Record<string, string[]> = {
  "studio-floor": ["sasha", "ravi"],
  "playtest-room": ["mei", "tomas", "kai", "ife", "jonah"],
};

export const MEMBERS: { group: string; people: { id: string; presence: Presence; activity?: string; role?: "owner" | "mod" }[] }[] = [
  { group: "Owner", people: [{ id: "nadia", presence: "on", activity: "Shipping Lanternfall 1.2", role: "owner" }] },
  { group: "Moderators", people: [{ id: "jonah", presence: "on", role: "mod" }, { id: "elena", presence: "idle", role: "mod" }] },
  { group: "Online — 1,284", people: [
    { id: "mei", presence: "on", activity: "In Playtest Room" },
    { id: "tomas", presence: "on", activity: "In Playtest Room" },
    { id: "ife", presence: "dnd", activity: "Focus mode" },
    { id: "kai", presence: "on", activity: "In Playtest Room" },
    { id: "sasha", presence: "on", activity: "Blender · 2h" },
    { id: "ravi", presence: "idle" },
    { id: "amara", presence: "on" },
    { id: "theo", presence: "on", activity: "Playing Neon Ward" },
  ] },
];

export interface Reaction { icon: "flame" | "heart" | "eye" | "check" | "spark"; color: string; count: number; mine?: boolean }
export interface Message {
  id: string;
  author: string;
  time: string;
  text: string;
  replyTo?: { author: string; text: string };
  reactions?: Reaction[];
  attachment?: { kind: "video" | "file" | "image" | "code" | "game"; name?: string; meta?: string; src?: string; code?: string; game?: string };
  thread?: { count: number; last: string; people: string[] };
  edited?: boolean;
  pinned?: boolean;
  system?: string;
}

export const SHADER_MESSAGES: Message[] = [
  { id: "m0", author: "jonah", time: "18:05", text: "", system: "pinned “Shader Jam #7 — rules and theme timing”" },
  { id: "m1", author: "kai", time: "18:09", text: "For anyone following along, this is the core of the shoreline foam:",
    attachment: { kind: "code", code: "// shoreline foam: depth fade, then break the edge up\nfloat depthFade = saturate((sceneDepth - surfaceDepth) / _FadeDistance);\nfloat foam = step(noise(uv * 8.0 + _Time.y * 0.2), 1.0 - depthFade);" },
    reactions: [{ icon: "check", color: "#3DD68C", count: 9 }, { icon: "spark", color: "#F5B544", count: 3 }] },
  { id: "m2", author: "mei", time: "18:12", text: "Finally got the caustics to stop swimming when the camera moves — projecting in world space instead of screen space fixed it.",
    attachment: { kind: "video", name: "caustics_world_space.mp4", meta: "0:12", src: img("att_caustics") },
    reactions: [{ icon: "flame", color: "#4AA3FF", count: 18, mine: true }, { icon: "eye", color: "#9FC5FF", count: 6 }, { icon: "heart", color: "#FF7B9C", count: 4 }] },
  { id: "m3", author: "tomas", time: "18:15", text: "Same trick works for the foam mask. Are you fading on the depth buffer at the shoreline too?",
    replyTo: { author: "mei", text: "Finally got the caustics to stop swimming when the camera moves…" } },
  { id: "m4", author: "ife", time: "18:24", text: "Cleaned-up version with the world-space projection and a foam toggle. MIT licensed — use it in the jam.",
    attachment: { kind: "file", name: "caustics_v3.glsl", meta: "4.2 KB" },
    thread: { count: 4, last: "2 min ago", people: ["mei", "tomas", "leo"] } },
  { id: "m5", author: "sasha", time: "18:40", text: "Does this hold up on Switch-class GPUs? Thinking of dropping it into the handheld build of Lanternfall.", edited: true },
];

export const THREAD: { author: string; time: string; text: string }[] = [
  { author: "mei", time: "18:27", text: "Works great. The foam toggle is a nice touch for the stylised levels." },
  { author: "tomas", time: "18:29", text: "Mind if I port it to Godot 4? I’ll credit you in the header." },
  { author: "ife", time: "18:30", text: "Go for it — send me the link when it’s up and I’ll pin it." },
  { author: "leo", time: "18:44", text: "Ran it on a Steam Deck: about 0.4 ms at 800p with foam on. Very usable." },
];

export interface Game { id: string; name: string; art: string; genre: string; pos: string }
export const GAMES: Record<string, Game> = {
  pinehollow: { id: "pinehollow", name: "Pinehollow", art: "fern", genre: "Co-op survival", pos: "35% 50%" },
  lanternfall: { id: "lanternfall", name: "Lanternfall", art: "lowlight", genre: "Action RPG", pos: "80% 50%" },
  northlight: { id: "northlight", name: "Northlight", art: "polaris", genre: "Exploration", pos: "45% 50%" },
  neonward: { id: "neonward", name: "Neon Ward", art: "nightshift", genre: "Rhythm", pos: "60% 50%" },
  saltwind: { id: "saltwind", name: "Saltwind", art: "saltflat", genre: "Racing", pos: "28% 50%" },
  ridgeline: { id: "ridgeline", name: "Ridgeline", art: "basalt", genre: "Climbing", pos: "68% 50%" },
  bitforge: { id: "bitforge", name: "Bitforge", art: "pixel", genre: "Roguelite", pos: "72% 50%" },
  tidewater: { id: "tidewater", name: "Tidewater", art: "tidepool", genre: "Adventure", pos: "50% 50%" },
};

export interface DM { id: string; person?: string; group?: { name: string; people: [string, string] }; preview: string; time: string; unread?: number; presence?: Presence }
export const DMS: DM[] = [
  { id: "ife", person: "ife", preview: "oh 100%. I’ll bring snacks and bad aim", time: "19:45", presence: "dnd" },
  { id: "mei", person: "mei", preview: "sent a video · caustics_v4.mp4", time: "19:20", unread: 2, presence: "on" },
  { id: "jam", group: { name: "Shader Jam team", people: ["tomas", "kai"] }, preview: "Tomás: theme guesses? I say “tides”", time: "18:57", unread: 5 },
  { id: "kai", person: "kai", preview: "haha fair, the Deck is a beast", time: "Yesterday", presence: "on" },
  { id: "nadia", person: "nadia", preview: "Thanks for running the node this week!", time: "Sun", presence: "on" },
  { id: "theo", person: "theo", preview: "you: link me that playlist", time: "Sat", presence: "on" },
  { id: "amara", person: "amara", preview: "Clear skies tonight, want to stack?", time: "Fri", presence: "on" },
];

export interface DMMessage { id: string; from: string; time: string; lines: string[]; game?: string; day?: string }
export const IFE_CONVERSATION: DMMessage[] = [
  { id: "d1", from: "ife", time: "22:10", lines: ["Still up for co-op testing the weather system on Thursday?"], day: "Yesterday" },
  { id: "d2", from: "leo", time: "22:14", lines: ["Yes! Storm fronts should be in by then", "fair warning: the rain is currently purple"] },
  { id: "d3", from: "ife", time: "19:02", lines: ["Sent you the caustics shader before posting it — tell me if the foam toggle breaks on your end"], day: "Today" },
  { id: "d4", from: "leo", time: "19:31", lines: ["Works on the Deck. Dropping numbers in the thread now"] },
  { id: "d5", from: "ife", time: "19:42", lines: ["perfect — also, Lowlight is doing Paris, Texas on Friday. You in?"] },
  { id: "d6", from: "leo", time: "19:44", lines: ["yes!! and Thursday after the weather test, this?"], game: "pinehollow" },
  { id: "d7", from: "ife", time: "19:45", lines: ["oh 100%. I’ll bring snacks and bad aim"] },
];

export const GAME_SCENE = img("game_pinehollow");
export const CAUSTICS = img("att_caustics");
