// App-wide state: where you are, your account, settings, and the Ludus connection.
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { backend, type AccountInfo, type CommunityInfo } from "./backend";

export type Screen =
  | { name: "discover" }
  | { name: "community"; id: string }
  | { name: "channel"; id: string; channel: string }
  | { name: "voice"; id: string; channel: string }
  | { name: "dms"; dm?: string }
  | { name: "profile" }
  | { name: "settings"; section?: string }
  | { name: "network" }
  | { name: "overlay" };

export type Modal = null | "create" | "ludus";

export interface Settings {
  accent: string;
  theme: "noir" | "graphite" | "midnight";
  reduceMotion: boolean;
  readReceipts: boolean;
  typing: boolean;
  shareActivity: boolean;
  hideIp: boolean;
  contribute: boolean;
  relayForOthers: boolean;
  noiseSuppression: boolean;
  quietHours: boolean;
  desktopNotifications: boolean;
}

const DEFAULT_SETTINGS: Settings = {
  accent: "#4AA3FF", theme: "noir", reduceMotion: false, readReceipts: false, typing: true, shareActivity: true,
  hideIp: true, contribute: true, relayForOthers: false, noiseSuppression: true, quietHours: true, desktopNotifications: true,
};

interface Ctx {
  screen: Screen;
  go: (s: Screen) => void;
  back: () => void;
  modal: Modal;
  openModal: (m: Modal) => void;
  account: AccountInfo | null;
  setAccount: (a: AccountInfo | null) => void;
  accountLoaded: boolean;
  settings: Settings;
  set: <K extends keyof Settings>(k: K, v: Settings[K]) => void;
  ludusConnected: boolean;
  setLudusConnected: (v: boolean) => void;
  myCommunities: CommunityInfo[];
  refreshCommunities: () => Promise<void>;
  toast: (text: string) => void;
  toasts: { id: number; text: string }[];
  inVoice: string | null;
  setInVoice: (id: string | null) => void;
}

const AppCtx = createContext<Ctx | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? { ...fallback, ...JSON.parse(v) } : fallback;
  } catch {
    return fallback;
  }
}

function hexToRgb(h: string): string {
  const n = parseInt(h.replace("#", ""), 16);
  return `${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}`;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [history, setHistory] = useState<Screen[]>([{ name: "discover" }]);
  const [modal, openModal] = useState<Modal>(null);
  const [account, setAccount] = useState<AccountInfo | null>(null);
  const [accountLoaded, setAccountLoaded] = useState(false);
  const [settings, setSettings] = useState<Settings>(() => load("moot.settings", DEFAULT_SETTINGS));
  const [ludusConnected, setLudusConnected] = useState(true);
  const [myCommunities, setMine] = useState<CommunityInfo[]>([]);
  const [toasts, setToasts] = useState<{ id: number; text: string }[]>([]);
  const [inVoice, setInVoice] = useState<string | null>("playtest-room");

  useEffect(() => {
    backend.getAccount().then((a) => { setAccount(a); setAccountLoaded(true); }).catch(() => setAccountLoaded(true));
    backend.listCommunities().then(setMine).catch(() => {});
    // The real "Hide my IP" value comes from the core, not from this browser's storage.
    backend.networkStatus().then((n) => setSettings((s) => ({ ...s, hideIp: n.hide_ip }))).catch(() => {});
  }, []);

  useEffect(() => {
    try { localStorage.setItem("moot.settings", JSON.stringify(settings)); } catch { /* storage can be unavailable */ }
    const r = document.documentElement;
    r.style.setProperty("--acc", settings.accent);
    r.style.setProperty("--acc-soft", `rgba(${hexToRgb(settings.accent)}, 0.12)`);
    r.style.setProperty("--acc-line", `rgba(${hexToRgb(settings.accent)}, 0.55)`);
    r.dataset.theme = settings.theme;
    r.dataset.motion = settings.reduceMotion ? "reduced" : "full";
  }, [settings]);

  const toast = useCallback((text: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const refreshCommunities = useCallback(async () => { setMine(await backend.listCommunities()); }, []);

  const value = useMemo<Ctx>(() => ({
    screen: history[history.length - 1],
    go: (s) => setHistory((h) => [...h.slice(-30), s]),
    back: () => setHistory((h) => (h.length > 1 ? h.slice(0, -1) : h)),
    modal, openModal, account, setAccount, accountLoaded, settings,
    set: (k, v) => {
      setSettings((s) => ({ ...s, [k]: v }));
      // The IP setting lives in the Rust core: switching it restarts the network peer.
      if (k === "hideIp") {
        backend.setHideIp(Boolean(v))
          .then(() => toast(v ? "Your IP is now hidden — everything goes through a relay" : "Direct connections on — people you connect to can see your IP"))
          .catch((e) => toast(`Couldn’t switch: ${e}`));
      }
    },
    ludusConnected, setLudusConnected, myCommunities, refreshCommunities, toast, toasts, inVoice, setInVoice,
  }), [history, modal, account, accountLoaded, settings, ludusConnected, myCommunities, refreshCommunities, toast, toasts, inVoice]);

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp(): Ctx {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp outside AppProvider");
  return c;
}
