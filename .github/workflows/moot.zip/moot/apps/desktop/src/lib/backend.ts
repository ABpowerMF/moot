// Bridge to the Rust core. Inside the Tauri app every call goes to moot-core (real keys,
// real signatures, real SQLite storage). In a plain browser (the web preview) a small
// in-memory stand-in answers instead, so the interface can be tried without installing.

export interface AccountInfo { display_name: string; fingerprint: string; identity: string; device_name: string }
export interface ChannelInfo { id: string; name: string; kind: string; private: boolean }
export interface CommunityInfo { id: string; name: string; description: string; visibility: string; members: number; events: number; nodes: number; channels: ChannelInfo[]; owner_fingerprint: string }
export interface NetworkStatus { online: boolean; node_id: string; mode: string; hide_ip: boolean; synced_communities: number; last_error: string | null }
export interface BadgeInfo { tier: "Finder" | "Hunter" | "Legend"; title: string; advisory: string; issued_ms: number }
export interface PrivacyReport {
  hide_ip: boolean; online: boolean; ip_sockets: number; relay: string | null; invites_ip_free: boolean;
  paths: { via_relay: number; direct: number };
  key_storage: string; key_in_keychain: boolean; database_encrypted: boolean; locked_db_moved: string | null;
}
export interface SyncReport { applied: number; already_had: number; rejected: number }
export interface MessageInfo { id: string; channel: string; author_fingerprint: string; author_device: string; text: string; timestamp_ms: number; edited: boolean; mine: boolean }

declare global {
  interface Window { __TAURI_INTERNALS__?: unknown }
}

export const isTauri = (): boolean => typeof window !== "undefined" && !!window.__TAURI_INTERNALS__;

async function call<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  if (isTauri()) {
    const { invoke } = await import("@tauri-apps/api/core");
    return invoke<T>(cmd, args);
  }
  return preview(cmd, args ?? {}) as T;
}

// ---------- browser stand-in (web preview only) ----------
const WORDS = "anchor harbor lantern meadow orbit pebble quartz river signal timber velvet willow ember falcon glacier hollow island jasper kettle lumen".split(" ");
const hex = (n: number) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => b.toString(16).padStart(2, "0")).join("");
const fp = (h: string) => h.slice(0, 16).toUpperCase().match(/.{4}/g)!.join(" ");
let previewHideIp = true;
const mem: { account: AccountInfo | null; communities: CommunityInfo[]; messages: Record<string, MessageInfo[]> } = {
  account: { display_name: "Leo Carvalho", fingerprint: "7F3A 91C2 4E0D B6A1", identity: hex(32), device_name: "Desktop — web preview" },
  communities: [],
  messages: {},
};

function preview(cmd: string, a: Record<string, unknown>): unknown {
  switch (cmd) {
    case "get_account":
      return mem.account;
    case "create_account": {
      const id = hex(32);
      mem.account = { display_name: String(a.displayName), fingerprint: fp(id), identity: id, device_name: "Desktop — web preview" };
      const words = Array.from({ length: 12 }, () => WORDS[Math.floor(Math.random() * WORDS.length)]);
      return { account: mem.account, recovery_words: words };
    }
    case "set_display_name":
      if (mem.account) mem.account.display_name = String(a.displayName);
      return null;
    case "list_communities":
      return mem.communities;
    case "create_community": {
      const ci: CommunityInfo = {
        id: hex(32), name: String(a.name), description: String(a.description), visibility: String(a.visibility),
        members: 1, events: 4, nodes: 0, owner_fingerprint: mem.account?.fingerprint ?? "",
        channels: [
          { id: "general", name: "general", kind: "Text", private: false },
          { id: "announcements", name: "announcements", kind: "Announcement", private: false },
          { id: "lounge", name: "Lounge", kind: "Voice", private: false },
        ],
      };
      mem.communities.push(ci);
      return ci;
    }
    case "post_message": {
      const m: MessageInfo = { id: hex(32), channel: String(a.channel), author_fingerprint: mem.account?.fingerprint ?? "", author_device: "web preview", text: String(a.text), timestamp_ms: Date.now(), edited: false, mine: true };
      const k = `${a.community}/${a.channel}`;
      (mem.messages[k] ??= []).push(m);
      const ci = mem.communities.find((x) => x.id === a.community);
      if (ci) ci.events += 1;
      return m;
    }
    case "list_messages":
      return mem.messages[`${a.community}/${a.channel}`] ?? [];
    case "network_status":
      return { online: true, node_id: "web-preview-" + (mem.account?.identity.slice(0, 12) ?? ""), mode: "preview", hide_ip: previewHideIp, synced_communities: 0, last_error: null } satisfies NetworkStatus;
    case "privacy_report":
      return {
        hide_ip: previewHideIp, online: true, ip_sockets: previewHideIp ? 0 : 2, relay: "https://relay.moot.example", invites_ip_free: true,
        paths: { via_relay: previewHideIp ? 3 : 0, direct: previewHideIp ? 0 : 3 },
        key_storage: "web preview — nothing is stored", key_in_keychain: false, database_encrypted: true, locked_db_moved: null,
      } satisfies PrivacyReport;
    case "list_badges":
      return [];
    case "add_badge":
      throw new Error("Badges are verified by the desktop app — the web preview can’t check signatures");
    case "set_hide_ip":
      previewHideIp = Boolean(a.hide);
      return previewHideIp;
    case "invite_code": {
      const ci = mem.communities.find((x) => x.id === a.community);
      if (!ci) throw new Error("Unknown community");
      if (ci.visibility !== "Public") throw new Error("Invite codes work for public communities in this prototype");
      return "moot1" + btoa(JSON.stringify({ c: ci.id, preview: true })).replace(/=+$/, "");
    }
    case "join_with_code":
      throw new Error("Joining over the network needs the desktop app — the web preview has no network stack");
    case "sync_now":
      return { applied: 0, already_had: 0, rejected: 0 } satisfies SyncReport;
    case "verify_all":
      return { communities: mem.communities.length, events_verified: mem.communities.reduce((n, x) => n + x.events, 0) };
    default:
      throw new Error(`unknown command ${cmd}`);
  }
}

export const backend = {
  getAccount: () => call<AccountInfo | null>("get_account"),
  createAccount: (displayName: string) => call<{ account: AccountInfo; recovery_words: string[] }>("create_account", { displayName }),
  restoreAccount: (phrase: string, displayName: string) => call<AccountInfo>("restore_account", { phrase, displayName }),
  setDisplayName: (displayName: string) => call<null>("set_display_name", { displayName }),
  listCommunities: () => call<CommunityInfo[]>("list_communities"),
  createCommunity: (name: string, description: string, visibility: "Public" | "InviteOnly" | "Private") => call<CommunityInfo>("create_community", { name, description, visibility }),
  postMessage: (community: string, channel: string, text: string) => call<MessageInfo>("post_message", { community, channel, text }),
  listMessages: (community: string, channel: string) => call<MessageInfo[]>("list_messages", { community, channel }),
  networkStatus: () => call<NetworkStatus>("network_status"),
  listBadges: () => call<BadgeInfo[]>("list_badges"),
  addBadge: (code: string) => call<BadgeInfo>("add_badge", { code }),
  privacyReport: () => call<PrivacyReport>("privacy_report"),
  setHideIp: (hide: boolean) => call<boolean>("set_hide_ip", { hide }),
  inviteCode: (community: string) => call<string>("invite_code", { community }),
  joinWithCode: (code: string) => call<CommunityInfo>("join_with_code", { code }),
  syncNow: (community: string) => call<SyncReport>("sync_now", { community }),
  verifyAll: () => call<{ communities: number; events_verified: number }>("verify_all"),
};

export async function windowControl(action: "minimize" | "maximize" | "close") {
  if (!isTauri()) return;
  const { getCurrentWindow } = await import("@tauri-apps/api/window");
  const w = getCurrentWindow();
  if (action === "minimize") await w.minimize();
  else if (action === "maximize") await w.toggleMaximize();
  else await w.close();
}
