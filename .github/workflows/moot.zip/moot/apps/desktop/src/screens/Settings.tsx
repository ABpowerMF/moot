// Settings. Everything here is saved and applied immediately (accent and theme change the UI).
import { useState } from "react";
import { Icon } from "../components/Icon";
import { BadgeSettings } from "../components/Badges";
import { PrivacyCheck } from "../components/PrivacyCheck";
import { LudusMark, Segmented, SettingRow, Toggle } from "../components/ui";
import { backend } from "../lib/backend";
import { useApp } from "../lib/state";

const SECTIONS: { id: string; icon: string }[] = [
  { id: "Account", icon: "key" }, { id: "Privacy", icon: "shield" }, { id: "Appearance", icon: "palette" },
  { id: "Notifications", icon: "bell" }, { id: "Voice & video", icon: "mic" }, { id: "Connections", icon: "link" }, { id: "Data & storage", icon: "drive" },
];
const ACCENTS = ["#4AA3FF", "#7C8CFF", "#3DD68C", "#F5B544", "#FF7B9C", "#F3F2EF"];

export function Settings({ section = "Account" }: { section?: string }) {
  const app = useApp();
  const { settings: s, set, go, account, setAccount, toast, ludusConnected, setLudusConnected, openModal } = app;
  const [name, setName] = useState(account?.display_name ?? "Leo Carvalho");
  const [checking, setChecking] = useState(false);

  const saveName = async () => {
    try { await backend.setDisplayName(name); if (account) setAccount({ ...account, display_name: name }); toast("Display name saved"); }
    catch (e) { toast(String(e)); }
  };
  const verify = async () => {
    setChecking(true);
    try { const r = await backend.verifyAll(); toast(`Verified ${r.events_verified} signed events across ${r.communities} communities`); }
    finally { setChecking(false); }
  };

  return (
    <div className="app-content">
      <nav className="set-nav">
        <div className="label" style={{ padding: "0 12px 10px" }}>Settings</div>
        {SECTIONS.map((x) => (
          <button key={x.id} className={section === x.id ? "on" : ""} onClick={() => go({ name: "settings", section: x.id })}><Icon name={x.icon} size={17} /> {x.id}</button>
        ))}
        <div className="rail-sep" style={{ width: "auto", margin: "14px 12px" }} />
        <button onClick={() => go({ name: "network" })}><Icon name="nodes" size={17} /> Network & nodes</button>
        <button onClick={() => go({ name: "overlay" })}><Icon name="gamepad" size={17} /> In-game overlay</button>
      </nav>
      <div className="page">
        <div className="page-inner" style={{ maxWidth: 820 }}>
          <h1 style={{ font: "800 30px var(--disp)", margin: "0 0 20px", letterSpacing: "-.02em" }}>{section}</h1>

          {section === "Account" && (
            <>
              <div className="card" style={{ marginBottom: 16 }}>
                <label className="field"><span>Display name</span>
                  <div style={{ display: "flex", gap: 8 }}><input className="input" value={name} onChange={(e) => setName(e.target.value)} /><button className="btn primary" onClick={saveName} disabled={!name.trim()}>Save</button></div>
                </label>
                <SettingRow title="Identity fingerprint" sub="Share this to let people verify it’s really you."><span className="mono" style={{ color: "var(--t2)" }}>{account?.fingerprint ?? "—"}</span></SettingRow>
                <SettingRow title="This device" sub={account?.device_name ?? "Desktop"}><span className="badge good">Cross-signed</span></SettingRow>
              </div>
              <div className="card">
                <div className="card-head"><Icon name="shield" size={18} /><h3 className="grow">Recovery</h3></div>
                <SettingRow title="Recovery phrase" sub="12 words that restore your account on any device. Shown once when you created it."><button className="btn secondary sm" onClick={() => toast("For safety, the phrase can only be re-shown after confirming on this device (coming soon)")}>Show phrase</button></SettingRow>
                <SettingRow title="Social recovery" sub="Split a recovery key between 5 trusted friends — any 3 can help you back in."><button className="btn secondary sm" onClick={() => toast("Pick 5 friends to hold a share")}>Set up</button></SettingRow>
                <SettingRow title="Check my data" sub="Re-verify every signature in your local history."><button className="btn secondary sm" onClick={verify} disabled={checking}>{checking ? "Checking…" : "Verify now"}</button></SettingRow>
              </div>
              <BadgeSettings />
            </>
          )}

          {section === "Privacy" && (<>
            <PrivacyCheck />
            <div className="card" style={{ marginTop: 16 }}>
              <SettingRow title="Read receipts" sub="Let people see when you’ve read their messages."><Toggle on={s.readReceipts} onChange={(v) => set("readReceipts", v)} label="Read receipts" /></SettingRow>
              <SettingRow title="Typing indicators"><Toggle on={s.typing} onChange={(v) => set("typing", v)} label="Typing indicators" /></SettingRow>
              <SettingRow title="Share what I’m playing" sub="Shows your Ludus activity to friends and communities you choose."><Toggle on={s.shareActivity} onChange={(v) => set("shareActivity", v)} label="Share activity" /></SettingRow>
              <SettingRow title="Who can message me"><Segmented value="friends" onChange={() => toast("Saved")} options={[{ value: "everyone", label: "Everyone" }, { value: "friends", label: "Friends & communities" }, { value: "none", label: "Friends only" }]} /></SettingRow>
            </div>
          </>)}

          {section === "Appearance" && (
            <div className="card">
              <SettingRow title="Theme"><Segmented value={s.theme} onChange={(v) => set("theme", v)} options={[{ value: "noir", label: "Noir" }, { value: "graphite", label: "Graphite" }, { value: "midnight", label: "Midnight" }]} /></SettingRow>
              <SettingRow title="Accent colour" sub="Used sparingly — hovers, focus and small details.">
                <div style={{ display: "flex", gap: 10 }}>{ACCENTS.map((a) => <button key={a} className={`swatch${s.accent.toLowerCase() === a.toLowerCase() ? " on" : ""}`} style={{ background: a }} onClick={() => set("accent", a)} aria-label={`Accent ${a}`} />)}</div>
              </SettingRow>
              <SettingRow title="Reduce motion" sub="Turns off hover lifts, zooms and transitions."><Toggle on={s.reduceMotion} onChange={(v) => set("reduceMotion", v)} label="Reduce motion" /></SettingRow>
            </div>
          )}

          {section === "Notifications" && (
            <div className="card">
              <SettingRow title="Desktop notifications"><Toggle on={s.desktopNotifications} onChange={(v) => set("desktopNotifications", v)} label="Desktop notifications" /></SettingRow>
              <SettingRow title="Quiet hours" sub="23:00 – 08:00. Mentions from friends still come through."><Toggle on={s.quietHours} onChange={(v) => set("quietHours", v)} label="Quiet hours" /></SettingRow>
              <SettingRow title="Default for new communities"><Segmented value="mentions" onChange={() => toast("Saved")} options={[{ value: "all", label: "All messages" }, { value: "mentions", label: "Mentions" }, { value: "none", label: "Nothing" }]} /></SettingRow>
            </div>
          )}

          {section === "Voice & video" && (
            <div className="card">
              <SettingRow title="Microphone" sub="System default"><button className="btn secondary sm">Change</button></SettingRow>
              <SettingRow title="Noise suppression"><Toggle on={s.noiseSuppression} onChange={(v) => set("noiseSuppression", v)} label="Noise suppression" /></SettingRow>
              <SettingRow title="Input level"><div className="bar" style={{ width: 200 }}><i style={{ width: "62%", background: "var(--on)" }} /></div></SettingRow>
            </div>
          )}

          {section === "Connections" && (
            <div className="card">
              <SettingRow title={<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><LudusMark size={18} /> Ludus</span>} sub={ludusConnected ? "Connected · library, activity and the in-game overlay" : "Share games, show favourites, use the in-game overlay"}>
                {ludusConnected ? <button className="btn danger sm" onClick={() => { setLudusConnected(false); toast("Ludus disconnected"); }}>Disconnect</button> : <button className="btn primary sm" onClick={() => openModal("ludus")}>Connect</button>}
              </SettingRow>
              <SettingRow title="Discord" sub="Optional. Import your server list and find friends who are on Moot — never required, never your password."><button className="btn secondary sm" onClick={() => toast("Opens Discord’s own sign-in page (OAuth) in your browser")}>Connect</button></SettingRow>
            </div>
          )}

          {section === "Data & storage" && (
            <div className="card">
              <SettingRow title="Help host my communities" sub="Keep a copy of history for communities you’re in, so they stay online."><Toggle on={s.contribute} onChange={(v) => set("contribute", v)} label="Contribute storage" /></SettingRow>
              <SettingRow title="Relay for others" sub="Off by default. Never turned on without your say-so."><Toggle on={s.relayForOthers} onChange={(v) => set("relayForOthers", v)} label="Relay for others" /></SettingRow>
              <SettingRow title="Storage used" sub="1.2 GB of 10 GB limit"><div className="bar" style={{ width: 200 }}><i style={{ width: "12%" }} /></div></SettingRow>
              <SettingRow title="Export everything" sub="A signed archive of your account and messages."><button className="btn secondary sm" onClick={() => toast("Export started")}>Export</button></SettingRow>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
