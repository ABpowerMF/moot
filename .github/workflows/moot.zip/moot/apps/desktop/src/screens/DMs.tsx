// Direct messages, with Ludus game sharing: send a game card a friend can open in Ludus.
import { useState, type KeyboardEvent } from "react";
import { Icon } from "../components/Icon";
import { Avatar, GameCover, LudusMark } from "../components/ui";
import { DMS, GAMES, IFE_CONVERSATION, PEOPLE, type DMMessage } from "../data/sample";
import { useApp } from "../lib/state";

function GameShareCard({ game, from }: { game: string; from: string }) {
  const { toast } = useApp();
  const g = GAMES[game];
  return (
    <div className="card lift" style={{ width: 320, padding: 0, overflow: "hidden", marginTop: 4 }}>
      <GameCover game={game} h={150}>
        <span className="badge glass" style={{ position: "absolute", left: 10, top: 10, gap: 6 }}><LudusMark size={12} /> Shared from Ludus</span>
      </GameCover>
      <div style={{ padding: 14 }}>
        <div style={{ font: "700 17px var(--disp)" }}>{g.name}</div>
        <div style={{ color: "var(--t3)", fontSize: 12.5, marginTop: 2 }}>{g.genre} · {from === "leo" ? "you have" : "they have"} 46 h played · 2–4 players</div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <button className="btn primary sm" style={{ flex: 1 }} onClick={() => toast(`Opening ${g.name} in Ludus`)}><Icon name="play" size={14} /> Open in Ludus</button>
          <button className="btn secondary sm" onClick={() => toast(`Asked to play ${g.name} together on Thursday`)}>Play together</button>
        </div>
      </div>
    </div>
  );
}

function GamePicker({ onPick, onClose }: { onPick: (g: string) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  const list = Object.values(GAMES).filter((g) => g.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="overlay-scrim" onClick={onClose}>
      <div className="dialog" style={{ width: 640 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "18px 20px", borderBottom: "1px solid var(--line)" }}>
          <LudusMark size={22} /><b style={{ font: "700 17px var(--disp)", flex: 1 }}>Share a game from your Ludus library</b>
          <button className="ibtn" onClick={onClose}><Icon name="x" size={16} /></button>
        </div>
        <div style={{ padding: 20 }}>
          <div className="search" style={{ maxWidth: "none", marginBottom: 16 }}><Icon name="search" size={15} /><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search your library" /></div>
          <div className="grid" style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 12 }}>
            {list.map((g) => (
              <button key={g.id} className="lift" style={{ border: 0, padding: 0, background: "none", textAlign: "left", borderRadius: 10 }} onClick={() => onPick(g.id)}>
                <GameCover game={g.id} h={110} />
                <div style={{ font: "600 13px var(--ui)", marginTop: 8 }}>{g.name}</div>
                <div style={{ font: "500 11.5px var(--ui)", color: "var(--t3)" }}>{g.genre}</div>
              </button>
            ))}
          </div>
          <div className="hint" style={{ marginTop: 14 }}>Moot only receives the game’s name, art and genre from Ludus — never your files or account.</div>
        </div>
      </div>
    </div>
  );
}

export function DMs() {
  const { ludusConnected, openModal, toast } = useApp();
  const [active, setActive] = useState("ife");
  const [conv, setConv] = useState<DMMessage[]>(IFE_CONVERSATION);
  const [text, setText] = useState("");
  const [picker, setPicker] = useState(false);
  const dm = DMS.find((d) => d.id === active)!;
  const title = dm.person ? PEOPLE[dm.person].name : dm.group!.name;

  const push = (m: Partial<DMMessage>) => setConv((c) => [...c, { id: `x${Date.now()}`, from: "leo", time: new Date().toTimeString().slice(0, 5), lines: [], ...m }]);
  const send = () => { const t = text.trim(); if (!t) return; push({ lines: [t] }); setText(""); };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };
  const shown = active === "ife" ? conv : [{ id: "p", from: dm.person ?? "tomas", time: dm.time, lines: [dm.preview.replace(/^you: /, "")] }];

  return (
    <div className="app-content">
      <aside className="dmlist">
        <div style={{ padding: "16px 14px 8px", display: "flex", alignItems: "center" }}><b style={{ font: "700 18px var(--disp)", flex: 1 }}>Messages</b><button className="ibtn" title="New message" onClick={() => toast("New group: pick up to 9 friends")}><Icon name="pen" size={17} /></button></div>
        <div style={{ padding: "0 14px 10px" }}><div className="search" style={{ height: 34 }}><Icon name="search" size={14} /><input placeholder="Find a conversation" /></div></div>
        <div className="scroll" style={{ flex: 1, padding: "0 8px 12px" }}>
          {DMS.map((d) => (
            <button key={d.id} className={`dmrow${active === d.id ? " active" : ""}`} onClick={() => setActive(d.id)}>
              {d.person ? <Avatar id={d.person} size={40} presence={d.presence} ring={active === d.id ? "var(--bg3)" : "var(--bg1)"} /> : (
                <span style={{ position: "relative", width: 40, height: 40, flex: "none" }}>
                  <span style={{ position: "absolute", left: 0, top: 0 }}><Avatar id={d.group!.people[0]} size={28} /></span>
                  <span style={{ position: "absolute", right: 0, bottom: 0 }}><Avatar id={d.group!.people[1]} size={28} ring="var(--bg1)" /></span>
                </span>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center" }}><span style={{ font: `${d.unread ? 700 : 600} 13.5px var(--ui)`, flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{d.person ? PEOPLE[d.person].name : d.group!.name}</span><span className="mono" style={{ fontSize: 10.5, color: "var(--t3)" }}>{d.time}</span></div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ flex: 1, minWidth: 0, font: "500 12.5px var(--ui)", color: d.unread ? "var(--t1)" : "var(--t3)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{d.preview}</span>{d.unread && <span className="rail-badge" style={{ position: "static", boxShadow: "none" }}>{d.unread}</span>}</div>
              </div>
            </button>
          ))}
        </div>
      </aside>
      <section className="chan">
        <div className="chan-head">
          {dm.person && <Avatar id={dm.person} size={30} presence={dm.presence} />}
          <b>{title}</b>
          <span className="badge good"><Icon name="lock" size={10} /> End-to-end encrypted</span>
          <span style={{ flex: 1 }} />
          <button className="ibtn" title="Voice call" onClick={() => toast(`Calling ${title}…`)}><Icon name="phone" size={18} /></button>
          <button className="ibtn" title="Video call" onClick={() => toast(`Video calling ${title}…`)}><Icon name="video" size={18} /></button>
        </div>
        <div className="feed">
          <div className="feed-inner" style={{ padding: "20px 24px 10px", display: "flex", flexDirection: "column", gap: 14 }}>
            {shown.map((m) => (
              <div key={m.id}>
                {"day" in m && m.day && <div className="day" style={{ margin: "6px 0 14px" }}>{m.day}</div>}
                <div style={{ display: "flex", gap: 10, flexDirection: m.from === "leo" ? "row-reverse" : "row", alignItems: "flex-end" }}>
                  {m.from !== "leo" && <Avatar id={m.from} size={28} />}
                  <div className="bubble-group" style={{ alignItems: m.from === "leo" ? "flex-end" : "flex-start" }}>
                    {m.lines.map((l, i) => <div key={i} className={`bubble${m.from === "leo" ? " me" : ""}`}>{l}</div>)}
                    {"game" in m && m.game && <GameShareCard game={m.game} from={m.from} />}
                    <span className="mono" style={{ fontSize: 10.5, color: "var(--t3)" }}>{m.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="composer-wrap" style={{ paddingTop: 8 }}>
          <div className="composer">
            <button className="ibtn" title="Attach"><Icon name="plus" size={18} /></button>
            <button className="ibtn" title="Share a game from Ludus" onClick={() => (ludusConnected ? setPicker(true) : openModal("ludus"))}><Icon name="gamepad" size={18} /></button>
            <textarea rows={1} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={onKey} placeholder={`Message ${title}`} aria-label="Message" />
            <button className="ibtn" title="Emoji"><Icon name="smile" size={18} /></button>
            <button className="btn accent sm" style={{ width: 36, padding: 0 }} onClick={send} disabled={!text.trim()} title="Send"><Icon name="send" size={16} /></button>
          </div>
        </div>
      </section>
      {picker && <GamePicker onClose={() => setPicker(false)} onPick={(g) => { setPicker(false); if (active !== "ife") setActive("ife"); push({ lines: [], game: g }); }} />}
    </div>
  );
}
