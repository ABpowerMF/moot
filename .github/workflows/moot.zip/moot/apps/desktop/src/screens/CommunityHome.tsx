// A community's home: banner, what's happening, events, and who runs its nodes.
import { CommunitySidebar, MemberList } from "../components/CommunitySidebar";
import { Icon } from "../components/Icon";
import { Avatar } from "../components/ui";
import { COMMUNITIES, PEOPLE } from "../data/sample";
import { useApp } from "../lib/state";

export function CommunityHome({ id }: { id: string }) {
  const { go, toast } = useApp();
  const c = COMMUNITIES[id];
  if (!c) return null;
  return (
    <div className="app-content">
      <CommunitySidebar id={id} />
      <div className="page">
        <div style={{ position: "relative", height: 220, overflow: "hidden" }}>
          <img src={c.banner} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, transparent 30%, var(--bg1))" }} />
          <div style={{ position: "absolute", left: 32, bottom: 18, display: "flex", alignItems: "flex-end", gap: 16 }}>
            <img src={c.icon} alt="" style={{ width: 72, height: 72, borderRadius: 18, boxShadow: "0 0 0 4px var(--bg1)" }} />
            <div>
              <div style={{ font: "800 32px/1.05 var(--disp)", letterSpacing: "-.02em" }}>{c.name}</div>
              <div style={{ color: "var(--t2)", fontSize: 13, marginTop: 4 }}>{c.members} members · {c.online} online · {c.category}</div>
            </div>
          </div>
          <div style={{ position: "absolute", right: 24, bottom: 22, display: "flex", gap: 8 }}>
            <button className="btn secondary sm" onClick={() => toast("Invite link copied")}><Icon name="userplus" size={15} /> Invite</button>
            <button className="btn primary sm" onClick={() => go({ name: "channel", id, channel: "shaders" })}>Jump in</button>
          </div>
        </div>
        <div style={{ padding: "20px 32px 40px", display: "grid", gridTemplateColumns: "minmax(0, 1.6fr) minmax(0, 1fr)", gap: 16 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="card">
              <div className="card-head"><Icon name="megaphone" size={18} /><h3 className="grow">Announcements</h3><span className="label">Pinned</span></div>
              <div style={{ font: "700 17px var(--disp)", marginBottom: 6 }}>Shader Jam #7 starts Friday 20:00</div>
              <div style={{ color: "var(--t2)", lineHeight: 1.55 }}>48 hours, one theme, any engine. Post works in progress in #shaders and the final build in #playtests. Theme reveal on stage.</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 14, color: "var(--t3)", fontSize: 12.5 }}><Avatar id="nadia" size={22} /> Nadia Kovač · 2 days ago</div>
            </div>
            <div className="card">
              <div className="card-head"><Icon name="activity" size={18} /><h3 className="grow">Active right now</h3></div>
              {[["shaders", "Mei posted caustics in world space", "18 replies"], ["art-critique", "12 new critique requests", "12 mentions"], ["devlog", "Lanternfall 1.2 patch notes", "4 mentions"]].map(([ch, t, s]) => (
                <button key={ch} className="row hv" style={{ width: "100%", border: 0, background: "none", textAlign: "left", borderRadius: 8, padding: "12px 8px" }} onClick={() => go({ name: "channel", id, channel: ch })}>
                  <Icon name="hash" size={17} color="var(--t3)" />
                  <div className="grow"><div className="t">#{ch}</div><div className="s">{t}</div></div>
                  <span className="badge">{s}</span>
                </button>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="card">
              <div className="card-head"><Icon name="calendar" size={18} /><h3 className="grow">Events</h3></div>
              {[["FRI", "21", "Shader Jam #7", "20:00 · Stage"], ["SUN", "23", "Playtest night", "19:00 · Playtest Room"]].map(([d, n, t, s]) => (
                <div key={t} className="row">
                  <div style={{ width: 44, textAlign: "center", borderRadius: 9, background: "var(--bg3)", padding: "6px 0" }}><div className="label" style={{ fontSize: 9.5 }}>{d}</div><div style={{ font: "800 18px var(--disp)" }}>{n}</div></div>
                  <div className="grow"><div className="t">{t}</div><div className="s">{s}</div></div>
                  <button className="btn secondary xs" onClick={() => toast(`You're going to ${t}`)}>Going</button>
                </div>
              ))}
            </div>
            <div className="card">
              <div className="card-head"><Icon name="nodes" size={18} /><h3 className="grow">Community nodes</h3><span className="badge good">Healthy</span></div>
              <div style={{ color: "var(--t3)", fontSize: 13, lineHeight: 1.5, marginBottom: 8 }}>This community’s history is kept by 3 nodes run by its members. If one goes down the others keep it online.</div>
              {[["nadia", "Primary · Frankfurt", "99.9%"], ["jonah", "Backup · Lisbon", "99.4%"], ["elena", "Backup · Montréal", "98.7%"]].map(([p, l, u]) => (
                <div key={p} className="row"><Avatar id={p} size={28} /><div className="grow"><div className="t">{PEOPLE[p].name}</div><div className="s">{l}</div></div><span className="mono" style={{ fontSize: 12, color: "var(--t2)" }}>{u}</span></div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <MemberList />
    </div>
  );
}
