// Your profile: banner, identity fingerprint, favourite games from Ludus, communities, devices.
import { useState } from "react";
import { BadgeChip, useBadges } from "../components/Badges";
import { Icon } from "../components/Icon";
import { Avatar, GameCover, LudusMark } from "../components/ui";
import { COMMUNITIES, GAMES, img } from "../data/sample";
import { useApp } from "../lib/state";

export function Profile() {
  const { account, ludusConnected, openModal, go, toast } = useApp();
  const [favs, setFavs] = useState(["pinehollow", "lanternfall", "northlight", "neonward"]);
  const [editing, setEditing] = useState(false);
  const all = Object.keys(GAMES);
  const [badges] = useBadges();
  const toggleFav = (g: string) => setFavs((f) => (f.includes(g) ? f.filter((x) => x !== g) : f.length < 6 ? [...f, g] : f));

  return (
    <div className="page">
      <div style={{ position: "relative", height: 240, overflow: "hidden" }}>
        <img src={img("b_tidepool")} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, transparent 20%, var(--bg1))" }} />
      </div>
      <div className="page-inner" style={{ marginTop: -110, position: "relative" }}>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 20 }}>
          <span style={{ borderRadius: "50%", boxShadow: "0 0 0 6px var(--bg1)" }}><Avatar id="leo" size={120} presence="on" ring="var(--bg1)" /></span>
          <div style={{ flex: 1, paddingBottom: 6 }}>
            <div style={{ font: "800 36px/1.05 var(--disp)", letterSpacing: "-.02em" }}>{account?.display_name ?? "Leo Carvalho"}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 6, color: "var(--t3)", fontSize: 13 }}>
              <span>@leoc</span><span>·</span><span className="mono">{account?.fingerprint ?? "7F3A 91C2 4E0D B6A1"}</span>
              <button className="ibtn" style={{ width: 26, height: 26 }} title="Copy fingerprint" onClick={() => toast("Fingerprint copied — compare it in person to verify")}><Icon name="copy" size={14} /></button>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, paddingBottom: 8 }}>
            <button className="btn secondary sm" onClick={() => go({ name: "settings", section: "Account" })}><Icon name="pen" size={14} /> Edit profile</button>
            <button className="btn primary sm" onClick={() => toast("Profile link copied")}><Icon name="share" size={14} /> Share</button>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.7fr) minmax(0, 1fr)", gap: 16, marginTop: 28 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="card">
              <div className="card-head"><LudusMark size={18} /><h3 className="grow">Favourite games</h3>
                {ludusConnected ? <button className="btn secondary xs" onClick={() => setEditing(!editing)}>{editing ? "Done" : "Edit"}</button> : <button className="btn secondary xs" onClick={() => openModal("ludus")}>Connect Ludus</button>}
              </div>
              <div className="grid" style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 12 }}>
                {(editing ? all : favs).map((g) => (
                  <button key={g} className="lift" onClick={() => editing && toggleFav(g)} style={{ border: 0, padding: 0, background: "none", textAlign: "left", borderRadius: 10, opacity: editing && !favs.includes(g) ? 0.45 : 1, cursor: editing ? "pointer" : "default" }}>
                    <GameCover game={g} h={150}>
                      {editing && favs.includes(g) && <span className="badge acc" style={{ position: "absolute", right: 8, top: 8 }}><Icon name="check" size={11} color="var(--acc-ink)" /></span>}
                    </GameCover>
                    <div style={{ font: "600 13px var(--ui)", marginTop: 8 }}>{GAMES[g].name}</div>
                    <div style={{ font: "500 11.5px var(--ui)", color: "var(--t3)" }}>{GAMES[g].genre}</div>
                  </button>
                ))}
              </div>
              {editing && <div className="hint" style={{ marginTop: 12 }}>Pick up to 6 games from your Ludus library ({favs.length}/6).</div>}
            </div>
            <div className="card">
              <div className="card-head"><Icon name="activity" size={18} /><h3 className="grow">Recently</h3></div>
              <div className="row"><GameCover game="pinehollow" h={40} style={{ width: 64, flex: "none", borderRadius: 8 }} /><div className="grow"><div className="t">Played Pinehollow</div><div className="s">2 h 14 m · with Ife and Kai · via Ludus</div></div><span className="mono" style={{ fontSize: 11, color: "var(--t3)" }}>yesterday</span></div>
              <div className="row"><Icon name="nodes" size={20} /><div className="grow"><div className="t">Ran a backup node for Pixel Foundry</div><div className="s">Stored 412 MB of community history this week</div></div><span className="mono" style={{ fontSize: 11, color: "var(--t3)" }}>this week</span></div>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {badges.length > 0 && (
              <div className="card">
                <div className="card-head"><Icon name="spark" size={18} /><h3 className="grow">Badges</h3></div>
                {badges.map((b) => <BadgeChip key={b.title + b.issued_ms} b={b} />)}
              </div>
            )}
            <div className="card">
              <div className="card-head"><h3 className="grow">About</h3></div>
              <div style={{ color: "var(--t2)", lineHeight: 1.6 }}>Making small, weird games in Lisbon. Shader nerd. Ask me about water.</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12 }}>{["Game dev", "Shaders", "Film"].map((t) => <span key={t} className="badge">{t}</span>)}</div>
            </div>
            <div className="card">
              <div className="card-head"><h3 className="grow">Communities</h3></div>
              {["pixel", "polaris", "nightshift", "lowlight"].map((id) => (
                <button key={id} className="row hv" style={{ width: "100%", border: 0, background: "none", borderRadius: 8, padding: "10px 6px", textAlign: "left" }} onClick={() => go({ name: "community", id })}>
                  <img src={COMMUNITIES[id].icon} alt="" style={{ width: 30, height: 30, borderRadius: 9 }} /><div className="grow"><div className="t">{COMMUNITIES[id].name}</div></div>
                  {id === "pixel" && <span className="badge mod">Node host</span>}
                </button>
              ))}
            </div>
            <div className="card">
              <div className="card-head"><Icon name="key" size={18} /><h3 className="grow">Devices</h3></div>
              <div className="row"><Icon name="cpu" size={18} /><div className="grow"><div className="t">{account?.device_name ?? "Desktop"}</div><div className="s">This device · cross-signed</div></div><span className="badge good">Verified</span></div>
              <div className="row"><Icon name="phone" size={18} /><div className="grow"><div className="t">Phone</div><div className="s">Not linked yet</div></div><button className="btn secondary xs" onClick={() => toast("Scan the QR code from Moot on your phone")}>Link</button></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
