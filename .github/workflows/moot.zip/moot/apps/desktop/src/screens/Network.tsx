// Network & nodes: how you're connected, which nodes keep your communities alive, what you contribute.
import { Icon } from "../components/Icon";
import { PrivacyCheck } from "../components/PrivacyCheck";
import { Avatar, SettingRow, Toggle } from "../components/ui";
import { COMMUNITIES, PEOPLE } from "../data/sample";
import { useEffect, useState } from "react";
import { backend, isTauri, type NetworkStatus } from "../lib/backend";
import { useApp } from "../lib/state";

export function Network() {
  const { settings: s, set, myCommunities, toast } = useApp();
  const [net, setNet] = useState<NetworkStatus | null>(null);
  useEffect(() => {
    const load = () => backend.networkStatus().then(setNet).catch(() => {});
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, []);
  const nodes: [string, string, string, string, number][] = [
    ["pixel", "nadia", "Frankfurt", "99.9%", 92],
    ["pixel", "jonah", "Lisbon", "99.4%", 78],
    ["polaris", "amara", "Accra", "99.1%", 66],
  ];
  return (
    <div className="page">
      <div className="page-inner">
        <div className="section-head"><h2 style={{ fontSize: 30 }}>Network & nodes</h2><span className="sub">Moot runs on people, not one company’s servers</span></div>
        <div className="grid" style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))", marginBottom: 16 }}>
          {[["Status", "Online", "var(--on)", "activity"], ["Peers", "14", "var(--t1)", "users"], ["Community nodes", "3", "var(--t1)", "nodes"], ["Latency", "24 ms", "var(--t1)", "wave"]].map(([l, v, c, i]) => (
            <div key={l} className="card"><div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}><Icon name={i} size={16} /><span className="label">{l}</span></div><div className="stat" style={{ color: c }}>{v}</div></div>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.5fr) minmax(0, 1fr)", gap: 16 }}>
          <div className="card">
            <div className="card-head"><Icon name="server" size={18} /><h3 className="grow">Nodes keeping your communities online</h3></div>
            {nodes.map(([c, p, loc, up, load]) => (
              <div key={p} className="row">
                <img src={COMMUNITIES[c].icon} alt="" style={{ width: 34, height: 34, borderRadius: 10 }} />
                <div className="grow"><div className="t">{COMMUNITIES[c].name}</div><div className="s" style={{ display: "flex", alignItems: "center", gap: 6 }}><Avatar id={p} size={16} /> run by {PEOPLE[p].name} · {loc}</div></div>
                <div style={{ width: 120 }}><div className="bar"><i style={{ width: `${load}%` }} /></div><div className="mono" style={{ fontSize: 10.5, color: "var(--t3)", marginTop: 4 }}>synced · {up} uptime</div></div>
              </div>
            ))}
            {myCommunities.map((c) => (
              <div key={c.id} className="row">
                <span style={{ width: 34, height: 34, borderRadius: 10, background: "var(--t1)", color: "var(--bg0)", display: "grid", placeItems: "center", font: "700 13px var(--disp)" }}>{c.name.slice(0, 2)}</span>
                <div className="grow"><div className="t">{c.name}</div><div className="s">Only on this device so far · {c.events} signed events</div></div>
                <button className="btn secondary xs" onClick={() => toast("Run `moot-node serve` on an always-on machine to host it")}>Add a node</button>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <PrivacyCheck compact />
            <div className="card">
              <div className="card-head"><Icon name="relay" size={18} /><h3 className="grow">Connection</h3></div>
              <SettingRow title="Transport" sub="QUIC, end-to-end encrypted between keys"><span className="mono" style={{ fontSize: 12, color: "var(--t2)" }}>iroh 1.0</span></SettingRow>
              <SettingRow title="This device on the network" sub={net ? (net.online ? `${isTauri() ? "Online" : "Preview"} · syncing ${net.synced_communities} communities` : `Offline${net.last_error ? ` · ${net.last_error}` : ""}`) : "…"}>
                <button className="btn secondary xs" title={net?.node_id} onClick={() => { if (net) { navigator.clipboard?.writeText(net.node_id).catch(() => {}); toast("Node id copied"); } }}><span className="mono">{net?.node_id.slice(0, 10) ?? "—"}…</span></button>
              </SettingRow>
            </div>
            <div className="card">
              <div className="card-head"><Icon name="drive" size={18} /><h3 className="grow">What you contribute</h3></div>
              <SettingRow title="Store community history" sub="1.2 GB of 10 GB"><Toggle on={s.contribute} onChange={(v) => set("contribute", v)} label="Contribute" /></SettingRow>
              <SettingRow title="Relay for others" sub="Never on unless you turn it on"><Toggle on={s.relayForOthers} onChange={(v) => set("relayForOthers", v)} label="Relay" /></SettingRow>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
