// In-game overlay preview: what you see over a game launched through Ludus (Shift + ` toggles it).
import { useEffect, useState } from "react";
import { Icon } from "../components/Icon";
import { Avatar, LudusMark } from "../components/ui";
import { PEOPLE, VOICE_USERS, img } from "../data/sample";
import { useApp } from "../lib/state";

export function Overlay() {
  const { back, toast } = useApp();
  const [open, setOpen] = useState(true);
  const [mic, setMic] = useState(true);
  const [msg, setMsg] = useState("");
  const [chat, setChat] = useState([
    { a: "ife", t: "storm front incoming from the north" },
    { a: "kai", t: "i’ve got the lantern, follow me" },
    { a: "tomas", t: "purple rain confirmed 💜" },
  ]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === "`" && e.shiftKey) setOpen((o) => !o);
      if (e.key === "~") setOpen((o) => !o);
      if (e.key === "Escape") back();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [back]);
  const voice = ["leo", ...VOICE_USERS["playtest-room"]];

  return (
    <div className="ovl" style={{ background: `center/cover url(${img("game_pinehollow")})` }}>
      <div style={{ position: "absolute", left: 24, top: 20, display: "flex", alignItems: "center", gap: 10 }}>
        <span className="badge glass" style={{ gap: 6 }}><LudusMark size={12} /> Pinehollow · launched from Ludus</span>
        <span className="badge glass">Shift + ` to {open ? "hide" : "show"} · Esc to exit preview</span>
      </div>
      {/* voice — always visible, compact */}
      <div className="ovl-panel" style={{ left: 24, top: 64, width: 220, padding: 10 }}>
        <div className="label" style={{ padding: "2px 4px 8px", display: "flex", alignItems: "center", gap: 6 }}><Icon name="speaker" size={12} /> Playtest Room</div>
        {voice.map((p, i) => (
          <div key={p} style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 4px" }}>
            <span style={{ borderRadius: "50%", boxShadow: i === 1 ? "0 0 0 2px var(--on)" : "none" }}><Avatar id={p} size={24} ring="transparent" /></span>
            <span style={{ font: "600 12.5px var(--ui)", flex: 1 }}>{p === "leo" ? "You" : PEOPLE[p].name.split(" ")[0]}</span>
            {p === "leo" && !mic && <Icon name="micoff" size={13} color="#ff8a8f" />}
          </div>
        ))}
      </div>
      {open && (
        <>
          <div className="ovl-panel" style={{ right: 24, top: 64, width: 360, display: "flex", flexDirection: "column", maxHeight: "calc(100% - 180px)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 14px", borderBottom: "1px solid rgba(255,255,255,.08)" }}><Icon name="chat" size={16} /><b style={{ flex: 1 }}>Shader Jam team</b><span className="badge good"><Icon name="lock" size={10} /> E2EE</span></div>
            <div style={{ padding: "10px 14px", display: "flex", flexDirection: "column", gap: 10, overflow: "auto" }}>
              {chat.map((c, i) => (
                <div key={i} style={{ display: "flex", gap: 8 }}><Avatar id={c.a} size={24} ring="transparent" /><div><b style={{ fontSize: 12.5 }}>{c.a === "leo" ? "You" : PEOPLE[c.a].name.split(" ")[0]}</b><div style={{ fontSize: 13, color: "#e4e3df" }}>{c.t}</div></div></div>
              ))}
            </div>
            <form style={{ padding: 10 }} onSubmit={(e) => { e.preventDefault(); if (msg.trim()) { setChat((c) => [...c, { a: "leo", t: msg.trim() }]); setMsg(""); } }}>
              <input className="input" style={{ background: "rgba(0,0,0,.35)" }} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Message without leaving the game" />
            </form>
          </div>
          <div className="ovl-panel" style={{ left: "50%", bottom: 28, transform: "translateX(-50%)", display: "flex", gap: 8, padding: 8 }}>
            <button className={`cbtn${mic ? "" : " off"}`} onClick={() => setMic(!mic)} title="Mute"><Icon name={mic ? "mic" : "micoff"} size={19} /></button>
            <button className="cbtn" title="Share screen" onClick={() => toast("Streaming Pinehollow to Playtest Room")}><Icon name="screen" size={19} /></button>
            <button className="cbtn" title="Invite to game" onClick={() => toast("Invite to Pinehollow sent to Shader Jam team")}><Icon name="userplus" size={19} /></button>
            <button className="cbtn" title="Clip last 30 s" onClick={() => toast("Saved the last 30 seconds")}><Icon name="video" size={19} /></button>
            <button className="cbtn leave" onClick={back} title="Close overlay"><Icon name="x" size={19} color="#fff" /></button>
          </div>
        </>
      )}
    </div>
  );
}
