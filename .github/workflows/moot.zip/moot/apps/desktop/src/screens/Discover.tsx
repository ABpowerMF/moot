// Discover: featured community, category filters, public communities, and friends playing via Ludus.
import { useMemo, useState } from "react";
import { Icon } from "../components/Icon";
import { Avatar, GameCover, LudusMark } from "../components/ui";
import { COMMUNITIES, GAMES, PEOPLE } from "../data/sample";
import { useApp } from "../lib/state";

const CATS = ["All", "Game dev", "Music", "Science", "Art", "Film", "Outdoors", "Tabletop"];

export function Discover() {
  const { go, ludusConnected, openModal, toast } = useApp();
  const [cat, setCat] = useState("All");
  const [joined, setJoined] = useState<Set<string>>(new Set(["pixel", "polaris", "nightshift", "lowlight", "basalt", "fern"]));
  const list = useMemo(() => Object.values(COMMUNITIES).filter((c) => cat === "All" || c.category === cat), [cat]);
  const hero = COMMUNITIES.polaris;

  const join = (id: string) => {
    setJoined((s) => new Set(s).add(id));
    toast(`Joined ${COMMUNITIES[id].name}`);
  };

  return (
    <div className="page">
      <div className="page-inner">
        <div className="hero lift">
          <img className="zoom" src={hero.banner} alt="" />
          <div className="hero-shade" />
          <div className="hero-body">
            <span className="badge glass"><Icon name="spark" size={11} /> Featured this week</span>
            <h1>{hero.name}</h1>
            <p style={{ margin: 0, color: "var(--t2)", fontSize: 15, lineHeight: 1.55 }}>{hero.description}</p>
            <div style={{ display: "flex", alignItems: "center", gap: 18, margin: "18px 0 22px", font: "500 13px var(--ui)", color: "var(--t2)" }}>
              <span><b style={{ color: "var(--t1)" }}>{hero.members}</b> members</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--on)" }} /><b style={{ color: "var(--t1)" }}>{hero.online}</b> online</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><Icon name="nodes" size={14} /> 4 community nodes</span>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn primary" onClick={() => go({ name: "community", id: "polaris" })}>{joined.has("polaris") ? "Open community" : "Join community"}</button>
              <button className="btn secondary" onClick={() => go({ name: "community", id: "polaris" })}>Preview</button>
            </div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, margin: "28px 0 22px", flexWrap: "wrap" }}>
          {CATS.map((c) => <button key={c} className={`chip${cat === c ? " on" : ""}`} onClick={() => setCat(c)}>{c}</button>)}
        </div>

        <div className="section-head"><h2>Popular communities</h2><span className="sub">Public, verified, run on community nodes</span></div>
        <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))" }}>
          {list.map((c) => (
            <div key={c.id} className="ccard lift" role="button" tabIndex={0} onClick={() => go({ name: "community", id: c.id })} onKeyDown={(e) => e.key === "Enter" && go({ name: "community", id: c.id })}>
              <div className="ccard-art"><img className="zoom" src={c.banner} alt="" /><div className="ccard-icon"><img src={c.icon} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div></div>
              <div className="ccard-body" style={{ paddingTop: 26 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}><b style={{ font: "700 15.5px var(--disp)", flex: 1 }}>{c.name}</b><span className="badge">{c.category}</span></div>
                <div className="clamp2" style={{ color: "var(--t3)", fontSize: 13, lineHeight: 1.5 }}>{c.description}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: "auto", paddingTop: 8, font: "500 12px var(--ui)", color: "var(--t3)" }}>
                  <span>{c.members} members</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--on)" }} />{c.online}</span>
                  <span style={{ marginLeft: "auto" }}>
                    {joined.has(c.id) ? <span className="badge good">Joined</span> : <button className="btn secondary xs" onClick={(e) => { e.stopPropagation(); join(c.id); }}>Join</button>}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="section-head" style={{ marginTop: 36 }}>
          <h2>Friends are playing</h2><span className="sub" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><LudusMark size={14} /> from Ludus</span>
          {!ludusConnected && <button className="more" onClick={() => openModal("ludus")}>Connect Ludus <Icon name="right" size={14} /></button>}
        </div>
        {ludusConnected ? (
          <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))" }}>
            {([["theo", "neonward", "1h 12m"], ["sasha", "lanternfall", "38m"], ["amara", "northlight", "2h 05m"], ["kai", "pinehollow", "12m"]] as const).map(([p, g, t]) => (
              <div key={p} className="card lift" style={{ padding: 0, overflow: "hidden" }}>
                <GameCover game={g} h={112}><span className="badge glass" style={{ position: "absolute", left: 10, top: 10 }}>{GAMES[g].genre}</span></GameCover>
                <div style={{ display: "flex", alignItems: "center", gap: 10, padding: 12 }}>
                  <Avatar id={p} size={30} presence="on" ring="var(--bg2)" />
                  <div style={{ flex: 1, minWidth: 0 }}><div style={{ font: "600 13px var(--ui)" }}>{PEOPLE[p].name}</div><div style={{ font: "500 11.5px var(--ui)", color: "var(--t3)" }}>{GAMES[g].name} · {t}</div></div>
                  <button className="ibtn filled" title="Ask to join" onClick={() => toast(`Asked ${PEOPLE[p].name.split(" ")[0]} to join ${GAMES[g].name}`)}><Icon name="userplus" size={16} /></button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card empty"><LudusMark size={30} /><div style={{ color: "var(--t2)" }}>Connect Ludus to see what your friends are playing.</div><button className="btn secondary sm" onClick={() => openModal("ludus")}>Connect Ludus</button></div>
        )}
      </div>
    </div>
  );
}
