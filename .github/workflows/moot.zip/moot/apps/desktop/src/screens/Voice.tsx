// Voice and video room. Controls work; real audio/video arrives in Phase 7 (LiveKit SFU).
import { useEffect, useState } from "react";
import { CommunitySidebar } from "../components/CommunitySidebar";
import { Icon } from "../components/Icon";
import { Avatar } from "../components/ui";
import { PEOPLE, VOICE_USERS, img } from "../data/sample";
import { useApp } from "../lib/state";

export function Voice({ id, channel }: { id: string; channel: string }) {
  const { setInVoice, go, toast, settings } = useApp();
  const [mic, setMic] = useState(true);
  const [cam, setCam] = useState(false);
  const [share, setShare] = useState(channel === "playtest-room");
  const [deaf, setDeaf] = useState(false);
  const [speaking, setSpeaking] = useState("mei");
  const people = ["leo", ...(VOICE_USERS[channel] ?? [])];

  useEffect(() => {
    const t = setInterval(() => setSpeaking(people[1 + Math.floor(Math.random() * Math.max(1, people.length - 1))] ?? "leo"), 2200);
    return () => clearInterval(t);
  }, [people.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const leave = () => { setInVoice(null); toast("Left voice"); go({ name: "community", id }); };
  const title = channel.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

  return (
    <div className="app-content">
      <CommunitySidebar id={id} active={channel} />
      <section className="chan" style={{ background: "var(--bg0)" }}>
        <div className="chan-head" style={{ background: "var(--bg1)" }}>
          <Icon name="speaker" size={18} color="var(--t3)" /><b>{title}</b>
          <span className="badge good"><Icon name="lock" size={10} /> Encrypted</span>
          <span style={{ flex: 1 }} />
          <span className="mono" style={{ fontSize: 11.5, color: "var(--t3)" }}>{people.length} in call · 24 ms · {settings.noiseSuppression ? "noise suppression on" : "raw audio"}</span>
        </div>
        <div className="stage" style={{ gridTemplateColumns: share ? "minmax(0, 3fr) minmax(0, 1fr)" : "repeat(3, minmax(0, 1fr))", gridAutoRows: share ? undefined : "minmax(0, 1fr)" }}>
          {share && (
            <div className="tile" style={{ gridRow: "span 6" }}>
              <img src={img("game_pinehollow")} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              <span className="tile-name"><Icon name="screen" size={14} /> Mei is sharing · Pinehollow · 1080p60</span>
            </div>
          )}
          {people.map((p) => (
            <div key={p} className={`tile${speaking === p && !(p === "leo" && !mic) ? " speaking" : ""}`} style={{ minHeight: share ? 96 : 0 }}>
              {p === "leo" && cam ? (
                <img src={img("b_tidepool")} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "saturate(.6)" }} />
              ) : (
                <Avatar id={p} size={share ? 52 : 84} />
              )}
              <span className="tile-name">
                {p === "leo" ? "You" : PEOPLE[p].name.split(" ")[0]}
                {p === "leo" && !mic && <Icon name="micoff" size={13} color="#ff8a8f" />}
              </span>
            </div>
          ))}
        </div>
        <div className="callbar">
          <button className={`cbtn${mic ? "" : " off"}`} title={mic ? "Mute" : "Unmute"} onClick={() => setMic(!mic)}><Icon name={mic ? "mic" : "micoff"} size={20} /></button>
          <button className={`cbtn${deaf ? " off" : ""}`} title="Deafen" onClick={() => setDeaf(!deaf)}><Icon name="headphones" size={20} /></button>
          <button className={`cbtn${cam ? "" : " off"}`} title="Camera" onClick={() => setCam(!cam)}><Icon name={cam ? "video" : "videooff"} size={20} /></button>
          <button className={`cbtn${share ? " " : ""}`} style={share ? { boxShadow: "inset 0 0 0 1.5px var(--acc)" } : undefined} title="Share screen" onClick={() => setShare(!share)}><Icon name="screen" size={20} color={share ? "var(--acc)" : undefined} /></button>
          <button className="cbtn" title="Open in-game overlay" onClick={() => go({ name: "overlay" })}><Icon name="gamepad" size={20} /></button>
          <button className="cbtn leave" title="Leave" onClick={leave}><Icon name="leave" size={20} color="#fff" /></button>
        </div>
      </section>
    </div>
  );
}
