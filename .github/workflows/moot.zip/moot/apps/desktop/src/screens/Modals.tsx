// Modals: create a community (real — writes signed events through moot-core) and connect Ludus.
import { useState } from "react";
import { Icon } from "../components/Icon";
import { Logo, LudusMark, Segmented } from "../components/ui";
import { backend } from "../lib/backend";
import { useApp } from "../lib/state";

export function CreateCommunity() {
  const { openModal, refreshCommunities, go, toast } = useApp();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [vis, setVis] = useState<"Public" | "InviteOnly" | "Private">("InviteOnly");
  const [busy, setBusy] = useState(false);
  const [joining, setJoining] = useState(false);
  const [code, setCode] = useState("");
  const close = () => openModal(null);

  const join = async () => {
    setBusy(true);
    try {
      const c = await backend.joinWithCode(code.trim());
      await refreshCommunities();
      close();
      toast(`Joined ${c.name} — ${c.events} events synced and verified`);
      go({ name: "channel", id: c.id, channel: "general" });
    } catch (e) {
      toast(`Couldn’t join: ${e}`);
    } finally { setBusy(false); }
  };

  if (joining) {
    return (
      <div className="overlay-scrim" onClick={close}>
        <div className="dialog" style={{ width: 520, padding: 24 }} onClick={(e) => e.stopPropagation()}>
          <div style={{ display: "flex", alignItems: "center", marginBottom: 12 }}><b style={{ font: "800 22px var(--disp)", flex: 1 }}>Join with a code</b><button className="ibtn" onClick={close}><Icon name="x" size={16} /></button></div>
          <label className="field"><span>Invite code</span><textarea className="textarea mono" autoFocus rows={5} value={code} onChange={(e) => setCode(e.target.value)} placeholder="moot1…" style={{ fontSize: 12, wordBreak: "break-all" }} /></label>
          <div className="hint">Moot connects to the person or node that made the code, downloads the community and checks every signature before showing anything.</div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 18 }}>
            <button className="btn secondary" onClick={() => setJoining(false)}>Back</button>
            <button className="btn primary" disabled={!code.trim().startsWith("moot1") || busy} onClick={join}>{busy ? "Connecting…" : "Join community"}</button>
          </div>
        </div>
      </div>
    );
  }

  const create = async () => {
    setBusy(true);
    try {
      const c = await backend.createCommunity(name.trim(), desc.trim(), vis);
      await refreshCommunities();
      close();
      toast(`${c.name} created — ${c.events} signed events`);
      go({ name: "channel", id: c.id, channel: "general" });
    } catch (e) {
      toast(`Couldn’t create: ${e}`);
    } finally { setBusy(false); }
  };

  return (
    <div className="overlay-scrim" onClick={close}>
      <div className="dialog" style={{ width: 520 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: "22px 24px 8px", display: "flex", alignItems: "center", gap: 10 }}>
          <b style={{ font: "800 22px var(--disp)", flex: 1 }}>{step === 0 ? "Start a community" : "Who can join?"}</b>
          <span className="mono" style={{ color: "var(--t3)", fontSize: 12 }}>{step + 1}/2</span>
          <button className="ibtn" onClick={close}><Icon name="x" size={16} /></button>
        </div>
        <div style={{ padding: "8px 24px 4px" }}>
          {step === 0 ? (
            <>
              <label className="field"><span>Name</span><input className="input" autoFocus value={name} maxLength={60} onChange={(e) => setName(e.target.value)} placeholder="e.g. Lisbon Game Makers" /></label>
              <label className="field"><span>What’s it about?</span><textarea className="textarea" rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="One or two lines for the Discover page" /></label>
              <div className="hint">You’ll own it. It starts with #general, #announcements and a Lounge voice room.</div>
              <button className="btn secondary sm" style={{ marginTop: 16, width: "100%" }} onClick={() => setJoining(true)}><Icon name="link" size={14} /> Have an invite code? Join instead</button>
            </>
          ) : (
            <>
              <Segmented fill value={vis} onChange={setVis} options={[{ value: "Public", label: "Public" }, { value: "InviteOnly", label: "Invite only" }, { value: "Private", label: "Private" }]} />
              <div className="card" style={{ marginTop: 14, background: "var(--bg1)" }}>
                {vis === "Public" && "Listed on Discover. Anyone can join and read."}
                {vis === "InviteOnly" && "Not listed. People join with an invite link you or your admins create."}
                {vis === "Private" && "Not listed and invite only. End-to-end encryption for every channel is coming in the next update."}
              </div>
              <div className="hint" style={{ marginTop: 12 }}><Icon name="nodes" size={12} /> It lives on your device first. Add a community node later to keep it online when you’re away — nothing is hosted without your say-so.</div>
            </>
          )}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "18px 24px 22px" }}>
          <button className="btn secondary" onClick={() => (step ? setStep(0) : close())}>{step ? "Back" : "Cancel"}</button>
          {step === 0 ? <button className="btn primary" disabled={!name.trim()} onClick={() => setStep(1)}>Next</button>
            : <button className="btn primary" disabled={busy} onClick={create}>{busy ? "Creating…" : "Create community"}</button>}
        </div>
      </div>
    </div>
  );
}

export function LudusConnect() {
  const { openModal, setLudusConnected, toast } = useApp();
  const [stage, setStage] = useState<"ask" | "waiting">("ask");
  const close = () => openModal(null);
  const approve = () => {
    setStage("waiting");
    setTimeout(() => { setLudusConnected(true); close(); toast("Ludus connected"); }, 1400);
  };
  return (
    <div className="overlay-scrim" onClick={close}>
      <div className="dialog" style={{ width: 480 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: "28px 28px 0", display: "flex", alignItems: "center", justifyContent: "center", gap: 14 }}>
          <Logo size={52} /><Icon name="link" size={20} color="var(--t3)" /><LudusMark size={52} />
        </div>
        <div style={{ padding: "18px 28px 6px", textAlign: "center" }}>
          <div style={{ font: "800 22px var(--disp)" }}>Connect Ludus</div>
          <div style={{ color: "var(--t2)", marginTop: 6, lineHeight: 1.55 }}>Ludus will ask you to approve. Moot never sees your Ludus or Discord password.</div>
        </div>
        <div style={{ padding: "14px 28px" }}>
          {[["gamepad", "See your game library", "to share games and pick favourites"], ["activity", "See what you’re playing", "only if you turn on activity sharing"], ["chat", "Show the Moot overlay in games", "when you launch through Ludus"]].map(([i, t, s]) => (
            <div key={t} className="row"><Icon name={i} size={18} /><div className="grow"><div className="t">{t}</div><div className="s">{s}</div></div><Icon name="check" size={16} color="var(--on)" /></div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 10, padding: "6px 28px 26px" }}>
          <button className="btn secondary" style={{ flex: 1 }} onClick={close}>Not now</button>
          <button className="btn primary" style={{ flex: 1 }} onClick={approve} disabled={stage === "waiting"}>{stage === "waiting" ? "Waiting for Ludus…" : "Open Ludus to approve"}</button>
        </div>
      </div>
    </div>
  );
}
