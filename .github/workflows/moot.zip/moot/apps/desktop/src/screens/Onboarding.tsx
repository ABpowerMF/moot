// First run: create your identity (keys made on this device) and write down the 12 recovery words.
import { useState } from "react";
import { Icon } from "../components/Icon";
import { Logo } from "../components/ui";
import { backend } from "../lib/backend";
import { useApp } from "../lib/state";

export function Onboarding() {
  const { setAccount, toast } = useApp();
  const [mode, setMode] = useState<"start" | "create" | "words" | "restore">("start");
  const [name, setName] = useState("");
  const [phrase, setPhrase] = useState("");
  const [words, setWords] = useState<string[]>([]);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<Awaited<ReturnType<typeof backend.createAccount>>["account"] | null>(null);

  const create = async () => {
    setBusy(true);
    try { const r = await backend.createAccount(name.trim()); setWords(r.recovery_words); setPending(r.account); setMode("words"); }
    catch (e) { toast(String(e)); } finally { setBusy(false); }
  };
  const restore = async () => {
    setBusy(true);
    try { setAccount(await backend.restoreAccount(phrase.trim().toLowerCase(), name.trim() || "Me")); }
    catch (e) { toast(`That phrase didn’t work: ${e}`); } finally { setBusy(false); }
  };

  return (
    <div style={{ height: "100%", display: "grid", placeItems: "center", background: "radial-gradient(80% 60% at 50% 0%, #141821, var(--bg0))" }} data-tauri-drag-region>
      <div className="dialog" style={{ width: 520, padding: "34px 34px 28px" }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 18 }}><Logo size={64} /></div>
        {mode === "start" && (
          <>
            <div style={{ font: "800 30px var(--disp)", textAlign: "center", letterSpacing: "-.02em" }}>Welcome to Moot</div>
            <p style={{ color: "var(--t2)", textAlign: "center", lineHeight: 1.6, margin: "10px 0 24px" }}>Your account is a key made on this device — no email, no phone number, no password stored on anyone’s server.</p>
            <button className="btn primary lg" style={{ width: "100%" }} onClick={() => setMode("create")}>Create my account</button>
            <button className="btn secondary lg" style={{ width: "100%", marginTop: 10 }} onClick={() => setMode("restore")}>I have a recovery phrase</button>
          </>
        )}
        {mode === "create" && (
          <>
            <div style={{ font: "800 24px var(--disp)", marginBottom: 16 }}>What should people call you?</div>
            <label className="field"><span>Display name</span><input className="input" autoFocus value={name} maxLength={40} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && name.trim() && create()} placeholder="Your name" /></label>
            <div className="hint">You can change this any time.</div>
            <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
              <button className="btn secondary" onClick={() => setMode("start")}>Back</button>
              <button className="btn primary" style={{ flex: 1 }} disabled={!name.trim() || busy} onClick={create}>{busy ? "Making your keys…" : "Continue"}</button>
            </div>
          </>
        )}
        {mode === "words" && (
          <>
            <div style={{ font: "800 24px var(--disp)" }}>Your recovery phrase</div>
            <p style={{ color: "var(--t2)", lineHeight: 1.55, margin: "8px 0 16px" }}>Write these 12 words down and keep them somewhere safe. They’re the only way back into your account if you lose this device. Moot can’t reset them.</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
              {words.map((w, i) => (
                <div key={i} className="mono" style={{ padding: "9px 10px", borderRadius: 8, background: "var(--bg1)", boxShadow: "inset 0 0 0 1px var(--line2)", fontSize: 13 }}><span style={{ color: "var(--t3)", marginRight: 8 }}>{i + 1}</span>{w}</div>
              ))}
            </div>
            <label style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 18, color: "var(--t2)", cursor: "pointer" }}>
              <input type="checkbox" checked={saved} onChange={(e) => setSaved(e.target.checked)} style={{ accentColor: "var(--acc)", width: 16, height: 16 }} /> I’ve written them down
            </label>
            <button className="btn primary lg" style={{ width: "100%", marginTop: 16 }} disabled={!saved} onClick={() => setAccount(pending)}>Enter Moot</button>
            <div className="hint" style={{ display: "flex", alignItems: "center", gap: 6, justifyContent: "center", marginTop: 10 }}><Icon name="key" size={12} /> Fingerprint <span className="mono">{pending?.fingerprint}</span></div>
          </>
        )}
        {mode === "restore" && (
          <>
            <div style={{ font: "800 24px var(--disp)", marginBottom: 16 }}>Restore your account</div>
            <label className="field"><span>Recovery phrase</span><textarea className="textarea mono" rows={3} value={phrase} onChange={(e) => setPhrase(e.target.value)} placeholder="twelve words separated by spaces" /></label>
            <label className="field"><span>Display name</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" /></label>
            <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
              <button className="btn secondary" onClick={() => setMode("start")}>Back</button>
              <button className="btn primary" style={{ flex: 1 }} disabled={phrase.trim().split(/\s+/).length !== 12 || busy} onClick={restore}>{busy ? "Restoring…" : "Restore"}</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
