// A text channel: message feed, reactions, replies, a thread panel and the composer.
// Sample communities use placeholder messages; communities you create are fully real —
// every message is a signed event written through moot-core.
import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { CommunitySidebar, MemberList } from "../components/CommunitySidebar";
import { Icon } from "../components/Icon";
import { Avatar } from "../components/ui";
import { COMMUNITIES, PEOPLE, SHADER_MESSAGES, THREAD, type Message, type Reaction } from "../data/sample";
import { backend, type MessageInfo } from "../lib/backend";
import { useApp } from "../lib/state";

const CHANNEL_TOPIC: Record<string, string> = {
  shaders: "Shader Jam #7 runs this weekend — post works in progress here",
  devlog: "Weekly progress posts. One thread per project, please",
  "art-critique": "Share work, ask for the kind of feedback you want",
};

const time = (d = new Date()) => d.toTimeString().slice(0, 5);

function Code({ code }: { code: string }) {
  return (
    <pre className="code">
      {code.split("\n").map((l, i) => (
        <div key={i} className={l.trim().startsWith("//") ? "cm" : ""}>{l}</div>
      ))}
    </pre>
  );
}

function MessageRow({ m, onReact, onReply, onThread }: { m: Message; onReact: (id: string, r: Reaction["icon"]) => void; onReply: (m: Message) => void; onThread: () => void }) {
  const p = PEOPLE[m.author];
  if (m.system) {
    return (
      <div className="msg" style={{ alignItems: "center", color: "var(--t3)", fontSize: 13 }}>
        <span style={{ width: 40, display: "flex", justifyContent: "center" }}><Icon name="pin" size={16} /></span>
        <span><b style={{ color: "var(--t2)" }}>{p.name}</b> {m.system}</span>
        <span className="msg-time">{m.time}</span>
      </div>
    );
  }
  return (
    <div className="msg">
      <div className="msg-tools">
        <button className="ibtn" title="React" onClick={() => onReact(m.id, "flame")}><Icon name="smile" size={16} /></button>
        <button className="ibtn" title="Reply" onClick={() => onReply(m)}><Icon name="reply" size={16} /></button>
        <button className="ibtn" title="Open thread" onClick={onThread}><Icon name="thread" size={16} /></button>
        <button className="ibtn" title="More"><Icon name="more" size={16} /></button>
      </div>
      <Avatar id={m.author} size={40} />
      <div style={{ minWidth: 0, flex: 1 }}>
        {m.replyTo && <div className="reply-to"><Avatar id={m.replyTo.author} size={16} /> <b style={{ color: "var(--t2)" }}>{PEOPLE[m.replyTo.author].name}</b> <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.replyTo.text}</span></div>}
        <div><span className="msg-name">{p.name}</span><span className="msg-time">{m.time}</span>{m.edited && <span className="msg-time">(edited)</span>}</div>
        {m.text && <div className="msg-text">{m.text}</div>}
        {m.attachment?.kind === "code" && m.attachment.code && <Code code={m.attachment.code} />}
        {m.attachment?.kind === "video" && (
          <div style={{ position: "relative", width: 440, maxWidth: "100%", aspectRatio: "16/9", marginTop: 8, borderRadius: 12, overflow: "hidden" }}>
            <img src={m.attachment.src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
            <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>
              <span style={{ width: 54, height: 54, borderRadius: "50%", background: "rgba(10,11,13,.6)", display: "grid", placeItems: "center", boxShadow: "inset 0 0 0 1px rgba(255,255,255,.2)" }}><Icon name="play" size={22} color="#fff" /></span>
            </div>
            <span className="badge glass" style={{ position: "absolute", left: 10, bottom: 10 }}>{m.attachment.name} · {m.attachment.meta}</span>
          </div>
        )}
        {m.attachment?.kind === "file" && (
          <div className="file">
            <span style={{ width: 40, height: 40, borderRadius: 9, background: "var(--bg4)", display: "grid", placeItems: "center" }}><Icon name="file" size={18} /></span>
            <div style={{ flex: 1, minWidth: 0 }}><div style={{ font: "600 13.5px var(--ui)" }}>{m.attachment.name}</div><div className="mono" style={{ fontSize: 11.5, color: "var(--t3)" }}>{m.attachment.meta} · checked</div></div>
            <button className="ibtn" title="Download"><Icon name="download" size={17} /></button>
          </div>
        )}
        {!!m.reactions?.length && (
          <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
            {m.reactions.map((r) => (
              <button key={r.icon} className={`reaction${r.mine ? " mine" : ""}`} onClick={() => onReact(m.id, r.icon)}>
                <Icon name={r.icon} size={14} color={r.color} /> {r.count}
              </button>
            ))}
            <button className="reaction" title="Add reaction" onClick={() => onReact(m.id, "heart")}><Icon name="smile" size={14} /></button>
          </div>
        )}
        {m.thread && (
          <button onClick={onThread} className="hv" style={{ display: "inline-flex", alignItems: "center", gap: 8, marginTop: 8, padding: "6px 10px 6px 6px", border: 0, borderRadius: 9, background: "var(--bg2)", boxShadow: "inset 0 0 0 1px var(--line)", color: "var(--t2)", font: "500 12.5px var(--ui)" }}>
            <span style={{ display: "flex" }}>{m.thread.people.map((x, i) => <span key={x} style={{ marginLeft: i ? -6 : 0 }}><Avatar id={x} size={20} ring="var(--bg2)" /></span>)}</span>
            <b style={{ color: "var(--acc)" }}>{m.thread.count} replies</b> · last reply {m.thread.last}
          </button>
        )}
      </div>
    </div>
  );
}

function Composer({ placeholder, onSend, replyTo, clearReply, others = true }: { placeholder: string; onSend: (t: string) => void; replyTo?: Message | null; clearReply?: () => void; others?: boolean }) {
  const [text, setText] = useState("");
  const { settings } = useApp();
  const send = () => { const t = text.trim(); if (!t) return; onSend(t); setText(""); };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };
  return (
    <div className="composer-wrap">
      {replyTo && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", margin: "0 0 -6px", borderRadius: "12px 12px 0 0", background: "var(--bg2)", font: "500 12.5px var(--ui)", color: "var(--t3)", boxShadow: "inset 0 0 0 1px var(--line)" }}>
          <Icon name="reply" size={14} /> Replying to <b style={{ color: "var(--t1)" }}>{PEOPLE[replyTo.author].name}</b>
          <button className="ibtn" style={{ width: 24, height: 24, marginLeft: "auto" }} onClick={clearReply}><Icon name="x" size={14} /></button>
        </div>
      )}
      <div className="composer">
        <button className="ibtn" title="Attach"><Icon name="plus" size={18} /></button>
        <textarea rows={1} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={onKey} placeholder={placeholder} aria-label={placeholder} />
        <button className="ibtn" title="GIF"><Icon name="gif" size={18} /></button>
        <button className="ibtn" title="Emoji"><Icon name="smile" size={18} /></button>
        <button className="btn accent sm" style={{ width: 36, padding: 0 }} title="Send" onClick={send} disabled={!text.trim()}><Icon name="send" size={16} /></button>
      </div>
      <div className="typing">{settings.typing && others ? <><Icon name="pen" size={12} /> Tomás is typing…</> : null}<span style={{ marginLeft: "auto" }} className="mono"><Icon name="lock" size={11} /> signed · ed25519</span></div>
    </div>
  );
}

function ThreadPanel({ onClose }: { onClose: () => void }) {
  const [replies, setReplies] = useState(THREAD);
  return (
    <aside className="thread">
      <div className="chan-head"><Icon name="thread" size={18} /><b style={{ flex: 1 }}>Thread</b><span className="mono" style={{ color: "var(--t3)", fontSize: 11.5 }}>caustics_v3.glsl</span><button className="ibtn" onClick={onClose}><Icon name="x" size={16} /></button></div>
      <div className="scroll" style={{ flex: 1, padding: "10px 0" }}>
        {replies.map((r, i) => (
          <div key={i} className="msg" style={{ padding: "8px 16px" }}>
            <Avatar id={r.author} size={32} />
            <div><span className="msg-name" style={{ fontSize: 13.5 }}>{PEOPLE[r.author].name}</span><span className="msg-time">{r.time}</span><div className="msg-text" style={{ fontSize: 13.5 }}>{r.text}</div></div>
          </div>
        ))}
      </div>
      <Composer placeholder="Reply in thread" onSend={(t) => setReplies((x) => [...x, { author: "leo", time: time(), text: t }])} />
    </aside>
  );
}

export function Channel({ id, channel }: { id: string; channel: string }) {
  const { myCommunities, toast } = useApp();
  const sample = COMMUNITIES[id];
  const real = myCommunities.find((c) => c.id === id);
  const [msgs, setMsgs] = useState<Message[]>(SHADER_MESSAGES);
  const [realMsgs, setRealMsgs] = useState<MessageInfo[]>([]);
  const [thread, setThread] = useState(channel === "shaders");
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const feed = useRef<HTMLDivElement>(null);

  // Real communities: refresh often, so messages synced from other peers show up.
  const isReal = !!real;
  useEffect(() => {
    if (!isReal) return;
    let live = true;
    const load = () => backend.listMessages(id, channel).then((m) => { if (live) setRealMsgs((old) => (old.length === m.length ? old : m)); }).catch(() => {});
    load();
    const t = setInterval(load, 2500);
    return () => { live = false; clearInterval(t); };
  }, [id, channel, isReal]);
  useEffect(() => { if (feed.current) feed.current.scrollTop = 0; }, [msgs.length, realMsgs.length]);

  const react = (mid: string, icon: Reaction["icon"]) =>
    setMsgs((ms) => ms.map((m) => {
      if (m.id !== mid) return m;
      const rs = [...(m.reactions ?? [])];
      const i = rs.findIndex((r) => r.icon === icon);
      if (i < 0) rs.push({ icon, color: icon === "heart" ? "#FF7B9C" : "#4AA3FF", count: 1, mine: true });
      else rs[i] = { ...rs[i], mine: !rs[i].mine, count: rs[i].count + (rs[i].mine ? -1 : 1) };
      return { ...m, reactions: rs.filter((r) => r.count > 0) };
    }));

  const send = async (text: string) => {
    if (real) {
      try { const m = await backend.postMessage(id, channel, text); setRealMsgs((x) => [...x, m]); }
      catch (e) { toast(`Couldn’t post: ${e}`); }
      return;
    }
    setMsgs((x) => [...x, { id: `local-${Date.now()}`, author: "leo", time: time(), text, replyTo: replyTo ? { author: replyTo.author, text: replyTo.text.slice(0, 80) } : undefined }]);
    setReplyTo(null);
  };

  return (
    <div className="app-content">
      <CommunitySidebar id={id} active={channel} />
      <section className="chan">
        <div className="chan-head">
          <Icon name="hash" size={19} color="var(--t3)" />
          <b style={{ font: "700 15px var(--ui)" }}>{channel}</b>
          <span className="vsep" />
          <span style={{ flex: 1, minWidth: 0, color: "var(--t3)", fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{CHANNEL_TOPIC[channel] ?? (real ? "Every message here is a signed event stored on your device" : "")}</span>
          <button className="ibtn" title="Threads" onClick={() => setThread((t) => !t)}><Icon name="thread" size={18} /></button>
          <button className="ibtn" title="Pinned"><Icon name="pin" size={18} /></button>
          <button className="ibtn" title="Members"><Icon name="users" size={18} /></button>
        </div>
        <div className="feed" ref={feed}>
          <div className="feed-inner">
            {sample ? (
              <>
                <div style={{ padding: "12px 24px 18px" }}>
                  <div style={{ width: 52, height: 52, borderRadius: 14, background: "var(--bg3)", display: "grid", placeItems: "center", marginBottom: 12 }}><Icon name="hash" size={26} /></div>
                  <div style={{ font: "800 26px var(--disp)" }}>Welcome to #{channel}</div>
                  <div style={{ color: "var(--t3)", marginTop: 4 }}>The start of #{channel} in {sample.name}.</div>
                </div>
                <div className="day">Today</div>
                {msgs.map((m) => <MessageRow key={m.id} m={m} onReact={react} onReply={setReplyTo} onThread={() => setThread(true)} />)}
              </>
            ) : (
              <>
                <div style={{ padding: "12px 24px 18px" }}>
                  <div style={{ width: 52, height: 52, borderRadius: 14, background: "var(--bg3)", display: "grid", placeItems: "center", marginBottom: 12 }}><Icon name="hash" size={26} /></div>
                  <div style={{ font: "800 26px var(--disp)" }}>Welcome to #{channel}</div>
                  <div style={{ color: "var(--t3)", marginTop: 4 }}>You created {real?.name}. Say hello — your message is signed with your device key.</div>
                </div>
                {realMsgs.map((m) => (
                  <div key={m.id} className="msg">
                    {m.mine ? <Avatar id="leo" size={40} /> : <Avatar id={m.author_fingerprint.replace(/ /g, "").toLowerCase()} size={40} />}
                    <div style={{ minWidth: 0 }}>
                      <div><span className="msg-name">{m.mine ? "You" : m.author_device}</span>{!m.mine && <span className="msg-time">{m.author_fingerprint}</span>}<span className="msg-time">{time(new Date(m.timestamp_ms))}</span><span className="msg-time" title={m.id}>event {m.id.slice(0, 8)}</span></div>
                      <div className="msg-text">{m.text}</div>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
        <Composer placeholder={`Message #${channel}`} onSend={send} replyTo={replyTo} clearReply={() => setReplyTo(null)} others={!!sample} />
      </section>
      {sample && thread ? <ThreadPanel onClose={() => setThread(false)} /> : sample ? <MemberList /> : null}
    </div>
  );
}
