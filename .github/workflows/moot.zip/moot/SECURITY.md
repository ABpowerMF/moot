# Security policy

Moot is built so that nobody — not even its developers — can read your messages, see your IP address, or pretend to be you. If you find a way around any of that, we want to hear from you first.

## Report a vulnerability privately

**Please don't open a public issue for security bugs.**

Use GitHub's private reporting: open the repository's **Security** tab and press **Report a vulnerability**. Only the maintainers can see the report.

Include what you can:

- what an attacker could do (read messages, learn an IP, impersonate someone, crash other people's apps…)
- steps to reproduce, or a proof of concept
- the version or commit you tested
- your Moot **public key** (Settings → Account → Security badges → Copy), if you'd like a badge

## What happens next

| | |
|---|---|
| We confirm we've received it | within **72 hours** |
| We tell you whether it's valid and how severe | within **7 days** |
| Critical and high-severity fixes released | within **30 days** |
| Other fixes released | within **90 days** |
| We publish an advisory and credit you | when the fix is out |

We'll keep you updated along the way. If we need longer, we'll tell you why. Please give us until the fix ships (or 90 days, whichever comes first) before you publish.

## Scope

**In scope**

- The Moot desktop app (`apps/desktop`) and its Rust core
- `moot-core`: identity, recovery, signatures, community rules, encrypted storage
- `moot-net`: the sync protocol, invite codes, relay-only (IP-hiding) mode
- `moot-node`
- Leaks of IP addresses, message content, keys or metadata that our docs say are protected
- Ways to forge events, bypass roles or bans, or make two devices disagree about a community
- Crashes or freezes another person can trigger remotely (a message, invite code, file…)

**Out of scope**

- Denial of service by flooding (sheer volume) — report it, but it won't earn a badge
- Attacks needing physical access to an unlocked device, or malware already running as the user
- Social engineering, phishing of Moot users, or attacks on our team
- The relay operator seeing your IP — that's documented and expected
- Bugs in third-party services or upstream libraries (please report those upstream; tell us too if Moot is affected)
- Anything in the sample/placeholder content of the prototype interface

## Rules of engagement

- Only test against accounts, communities and nodes **you own** or have permission to test.
- Don't access or keep other people's data. If you hit some by accident, stop, don't share it, and tell us.
- Don't degrade the service for others (no flooding public relays or nodes).
- Give us reasonable time to fix before disclosure.

## Safe harbour

If you act in good faith and follow these rules, we will not pursue or support any legal action against you for your research. We consider such research authorised, and we'll say so publicly if anyone asks. If you're unsure whether something is OK, ask us first through the same private channel.

## Recognition

We don't pay cash rewards. Instead:

- **Credit** in the advisory and in the [Hall of Fame](docs/HALL_OF_FAME.md) — your name or handle, linked where you like (or anonymous, if you prefer).
- **A signed badge on your Moot profile.** It's a certificate signed by the Moot security key and bound to your own public key, so it can't be faked or copied to another account. Tiers follow severity:

| Badge | For |
|---|---|
| 🛡 **Finder** | low-severity issues |
| 🛡 **Hunter** | medium and high-severity issues |
| 🛡 **Legend** | critical issues (e.g. reading others' messages, unmasking IPs, account takeover) |

To claim one, send your public key with the report. Once the fix ships we'll send you a `mootbadge1…` code; paste it in **Settings → Account → Security badges**.

## What we already do

So you don't spend time on things we know about:

- Relay-only networking by default; no IP sockets are opened in private mode (tested in `crates/moot-net/tests/privacy.rs`).
- Local data encrypted with XChaCha20-Poly1305; the key is held by the OS keychain (`crates/moot-core/tests/storage.rs`).
- Fuzzing of every input from other people (`fuzz/`, `crates/moot-fuzz`).
- Dependency audits with `cargo audit` and `npm audit` on every change.

Known gaps are listed honestly in [README.md](README.md#known-limitations-read-before-showing-anyone) — reports that help close them are very welcome.
