# Moot

A decentralised, desktop-first place for communities — like Discord, but nobody owns the server. Communities are signed, tamper-evident histories that live on members' devices and on **community nodes** that members choose to run. Moot is designed to work hand-in-hand with the **Ludus** game launcher.

> **Status: working prototype (v0.2.0 — security pass).** Identity, signed community histories, permissions, local storage, peer-to-peer sync and the full desktop interface are real and tested. Voice/video, end-to-end encrypted private channels and Ludus's side of the integration are designed but not built yet. Not audited. **Don't use it for anything sensitive yet.**

---

## What's in the box

| Part | Path | What it does |
|---|---|---|
| **moot-core** | `crates/moot-core` | Identity from a 12-word recovery phrase, device keys cross-signed by your identity, social recovery (3-of-5 shares), signed hash-linked community events, roles and moderation rules, sync and tamper detection, SQLite storage. |
| **moot-net** | `crates/moot-net` | Peer-to-peer sync over [Iroh](https://iroh.computer) (QUIC, dial by public key, hole punching, relay fallback). Invite codes, joining, two-way sync. Every received event is re-verified. |
| **moot-node** | `crates/moot-node` | Headless node that keeps communities online when members' apps are closed. Runs on a home PC or a cheap server; no port forwarding needed. |
| **Moot desktop** | `apps/desktop` | Tauri 2 app (Rust core + React interface) with every screen from the approved Marquee mockups. |

### What works in the desktop app

- **First-run account creation** — keys are made on your device; you get 12 recovery words. Restore from the phrase works too.
- **Create a community** (Public / Invite only / Private). Every message you post is an Ed25519-signed event stored in SQLite and re-verified on load.
- **Invite people with a code and join with a code** — the friend's app connects directly to yours over QUIC (or via a relay), downloads the history, checks every signature, signs a Join and syncs. New messages from either side arrive automatically every few seconds.
- **Settings → Account → Verify now** re-checks every signature on disk.
- **The whole interface**: Discover, community home, channels with replies/reactions/threads, voice room UI, DMs with **Ludus game sharing**, profile with **favourite games**, settings (theme + accent colour picker apply live), network & nodes, the **in-game overlay** preview (`Shift` + `` ` ``), create/join and Ludus-connect dialogs.

Sample communities (Pixel Foundry, Polaris, …) are placeholder content so the interface can be judged; they aren't on the network. Communities you create or join are fully real.

---

## Run it

You need **Rust** (stable, via [rustup](https://rustup.rs)) and **Node.js 20+**. On Windows 10/11 WebView2 is already installed; on Linux install the Tauri packages ([list](https://v2.tauri.app/start/prerequisites/)).

```bash
cd apps/desktop
npm install
npm run tauri dev        # opens the desktop app with hot reload
npm run tauri build      # makes an installer for your OS (.msi/.exe on Windows, .dmg on macOS, .deb/.AppImage on Linux)
```

Try the networking with two machines (or two user accounts on one machine): create a **Public** community on one, click **Invite people**, copy the code, and on the other press **+ → Have an invite code? Join instead**.

### Tests

```bash
cargo test --workspace --features moot-net/test-relay   # 38 Rust tests (see below)
cd apps/desktop && npm test                             # 9 interface tests, incl. "no outside content" checks
```

What they prove, among other things:

- **IP privacy** — two peers chat through a real (local) relay with **zero IP sockets open**; invite codes carry no IP; a tampered invite with an attacker's IP is never dialled; a control test proves the leak detector catches direct connections.
- **Encryption at rest** — after writing an account, a community and messages, none of the text, names or keys appear anywhere in the raw database files; wrong keys and swapped or flipped bytes are rejected; old unencrypted databases are migrated with no plaintext left behind.
- **Convergence** — a ban and a message written at the same moment resolve the same way on every device, whatever order they arrive in.
- **Robustness** — every input from other people survives tens of thousands of random and mutated inputs (fast pass on every `cargo test`).

### Fuzzing

Deep, coverage-guided fuzzing with [cargo-fuzz](https://github.com/rust-fuzz/cargo-fuzz) (needs nightly Rust):

```bash
cd fuzz
cargo fuzz run community_ops      # or: invite_code, sync_frame, event_bytes, recovery
```

CI fuzzes every target for a minute on each push and 30 minutes each week. First runs: ~50 million inputs, two bugs found and fixed (see [Hall of Fame](docs/HALL_OF_FAME.md)).

### Run a community node

```bash
cargo run -p moot-node -- init --name "Leo's mini PC"   # make the node's key (prints its recovery phrase once)
cargo run -p moot-node -- demo                           # optional: create a sample public community
cargo run -p moot-node -- serve                          # go online; prints an invite code per public community
cargo run -p moot-node -- join moot1…                    # fetch a community from an invite and help host it
```

Nodes are private by default too (`--direct` to allow direct connections). Their database key is read from `MOOT_VAULT_KEY` or a user-only `node.db.key` file — back it up.

### Web preview

`npm run build` then open `apps/desktop/dist/index.html` through any static server. In a plain browser the app uses an in-memory stand-in for the Rust core, so everything is clickable but nothing is signed, stored or networked.

### Installers from GitHub

`.github/workflows/release.yml` builds Windows, macOS and Linux installers whenever you push a tag like `v0.1.0`, and attaches them to a draft release. `ci.yml` runs all tests on every push.

---

## Decisions made overnight (all reversible)

You asked for this to be built while you slept, so I picked defaults instead of waiting. Each is easy to change:

1. **Own protocol on Iroh + OpenMLS** rather than building on Matrix or Nostr — best fit for "nobody owns the server", desktop-first and game-friendly latency. (OpenMLS is planned for private channels; not wired yet.)
2. **Tauri 2** (Rust + web UI) rather than Electron — small installers, low RAM, and all crypto stays in Rust.
3. **Licence AGPL-3.0-or-later** — keeps forks and hosted versions open. Switch to MIT/Apache if you'd rather allow closed forks.
4. **Fonts bundled in the app** (Bricolage Grotesque, Inter, JetBrains Mono) — no calls to Google Fonts, works offline.
5. **Invite codes work for Public communities** in this prototype. Invite-only joins need a moderator to approve a member's key first; the rules are enforced in the core already, the "approve request" UI isn't built.
6. **Sidekick** logo used as the placeholder, as you said.

## Security

See **[SECURITY.md](SECURITY.md)** for how to report a vulnerability (credit and a signed profile badge, no cash), and the **[Hall of Fame](docs/HALL_OF_FAME.md)**.

| Protection | How |
|---|---|
| **Your IP is hidden** (default) | Relay-only networking: Moot opens no IP socket at all, so the people you talk to only ever see the relay. No IPs in invite codes or address lookups, IPs in others' codes are ignored, no router port-mapping. Switch: Settings → Privacy → *Hide my IP*. |
| **Privacy check** | Settings → Privacy shows, live, who can see your IP and how every connection was carried. |
| **No outside content** | The app window can't load anything from other websites (enforced by its security policy and by tests), so no image or link preview can log your IP. |
| **Keys locked away** | The key that unlocks your data lives in Windows Credential Manager / macOS Keychain / Secret Service. |
| **Encrypted at rest** | Account keys, every message and every peer address are sealed with XChaCha20-Poly1305 and bound to their row. |
| **Tamper-proof history** | Every event is signed and hash-linked; every device re-checks every rule. |
| **Dependency audits** | `cargo audit` and `npm audit` on every change: 0 known vulnerabilities. |

## Known limitations (read before showing anyone)

- **Channel contents aren't end-to-end encrypted yet.** Traffic is encrypted in transit (QUIC), and data is encrypted on your disk, but community nodes and members' apps hold readable copies. MLS encryption for every channel is the next phase.
- **The relay sees your IP** (not your messages). Two-hop relays and an optional Tor mode will remove that; you can already point Moot at relays you trust.
- **One network key per install.** It's how people reach you, so a relay can tell it's the same device over time. Per-community keys are planned.
- **Backup owners can claim ownership at any time.** A waiting period with an owner veto is planned.
- **Racing a ban**: a message written *before* the author saw their ban can still appear (it's decided the same way on every device). Moderators can delete it.
- If the OS keychain is unavailable (some minimal Linux setups), the key falls back to a user-only file, and the privacy check says so.
- Voice and video are interface only (LiveKit SFU — Phase 7).
- Ludus integration is mocked on Moot's side; the API your friend implements is in the Ludus integration spec.
- Discord import is a placeholder button. When built it will use Discord's official OAuth only — never passwords, tokens or scraping.
- Sync polls every few seconds; push notifications between peers come later.
- Invite codes are long (~500 characters) because they carry the signed genesis event; short links come with node discovery.
- The person who joins pulls updates from whoever made the code, so that app (or a node) has to be online.
- Not independently audited yet (Phase 9).

## Roadmap

| Phase | | Status |
|---|---|---|
| 1 | Mockups and visual direction | ✅ |
| 2 | Architecture and threat model | ✅ |
| 3 | Desktop app shell and interface | ✅ prototype |
| 4 | Identity, devices, recovery | ✅ keychain + encrypted storage |
| 5 | Networking, nodes, sync | ✅ relay-only privacy · push + node discovery next |
| 6 | Communities, text, MLS-encrypted private channels | 🟡 text done, MLS next |
| 7 | Voice, video, screen share | ⬜ |
| 8 | Discord migration, Ludus, advanced features | 🟡 UI done |
| 9 | Audits and public release | ⬜ |

## Design docs

- [Phase 1 — visual direction & mockups](https://claude.ai/artifact/48aSD2AHq1M9tvbT8ye6NE)
- [Phase 2 — architecture & threat model](https://claude.ai/artifact/SoVEhkj2QdmLb6ufmRRytv)
- [Moot × Ludus — integration spec for Ludus](https://claude.ai/artifact/B61omiUZA5T1BTTeaPAwHU)
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — what the code does today: event format, rules, sync protocol, invite codes

## Layout

```
crates/moot-core     identity, events, community rules, sync, storage
crates/moot-net      Iroh transport, invite codes, sync protocol moot/sync/1
crates/moot-node     headless community node (also issues security badges)
crates/moot-fuzz     fuzz harnesses; fuzz/ runs them with cargo-fuzz
apps/desktop         Tauri 2 app
  src/               React interface (screens/, components/, lib/backend.ts bridges to Rust)
  src-tauri/         Rust side: commands the interface calls, background sync
docs/                design notes
```
