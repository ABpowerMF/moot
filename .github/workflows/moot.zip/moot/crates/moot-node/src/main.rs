//! `moot-node` — keep communities online.
//!
//! ```text
//! moot-node init  [--data node.db] [--name "Leo's mini PC"]   create the node's key
//! moot-node demo  [--data node.db]                            create a sample community
//! moot-node list  [--data node.db]                            list hosted communities
//! moot-node serve [--data node.db] [--local|--direct]         go online and serve sync
//! moot-node join CODE [--data node.db] [--local|--direct]     fetch a community from an invite and help host it
//! moot-node badge-key [--key badge-issuer.key]                 create the security team's badge-signing key
//! moot-node issue-badge --to IDENTITY_HEX --tier finder|hunter|legend --title "…" --advisory MOOT-2026-001 [--key …]
//! ```
//!
//! **Private by default**: the node talks only through relays and opens no IP socket, so
//! members never learn where it runs (which also protects the host from DDoS). `--direct`
//! allows direct connections for speed; `--local` is for LAN tests.
//!
//! The database is encrypted. Its key is read from `MOOT_VAULT_KEY` (64 hex characters) if
//! set, otherwise from `<data>.key`, created on first run and readable only by you.
//!
//! A node is just the Moot core without a window: it verifies every event it receives with
//! the same rules as the app, stores them, and serves them to members. It can be run on a
//! home PC behind an ordinary router: Iroh hole-punches or relays, no port forwarding.

use anyhow::{anyhow, Result};
use moot_core::{Badge, BadgeTier, CommunityState, Device, EventKind, Identity, Keypair, PublicKey, Store, VaultKey, Visibility};
use moot_net::{strip_ips, EndpointAddr, Invite, Library, NetMode, Peer};
use std::time::Duration;

struct Args {
    cmd: String,
    code: Option<String>,
    data: String,
    name: String,
    local: bool,
    direct: bool,
    opts: std::collections::HashMap<String, String>,
}

fn parse() -> Args {
    let mut it = std::env::args().skip(1);
    let cmd = it.next().unwrap_or_else(|| "help".into());
    let (mut data, mut name, mut local, mut direct, mut code) = ("node.db".to_string(), "Moot node".to_string(), false, false, None);
    let mut opts = std::collections::HashMap::new();
    while let Some(a) = it.next() {
        match a.as_str() {
            "--data" => data = it.next().unwrap_or(data),
            "--name" => name = it.next().unwrap_or(name),
            "--local" => local = true,
            "--direct" => direct = true,
            other if other.starts_with("moot1") => code = Some(other.to_string()),
            "--to" | "--tier" | "--title" | "--advisory" | "--key" => {
                if let Some(v) = it.next() {
                    opts.insert(a.trim_start_matches("--").to_string(), v);
                }
            }
            _ => {}
        }
    }
    Args { cmd, code, data, name, local, direct, opts }
}

impl Args {
    fn mode(&self) -> NetMode {
        if self.local {
            NetMode::LocalOnly
        } else if self.direct {
            NetMode::Direct
        } else {
            NetMode::Private
        }
    }
}

/// The vault key: `MOOT_VAULT_KEY`, or a user-only key file next to the database.
fn vault_key(data: &str) -> Result<VaultKey> {
    if let Ok(hex) = std::env::var("MOOT_VAULT_KEY") {
        return Ok(VaultKey::from_hex(&hex)?);
    }
    let path = format!("{data}.key");
    if let Ok(s) = std::fs::read_to_string(&path) {
        return Ok(VaultKey::from_hex(&s)?);
    }
    let key = VaultKey::generate();
    #[cfg(unix)]
    {
        use std::io::Write;
        use std::os::unix::fs::OpenOptionsExt;
        let mut f = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&path)?;
        f.write_all(key.to_hex().as_bytes())?;
    }
    #[cfg(not(unix))]
    std::fs::write(&path, key.to_hex())?;
    eprintln!("Created database key {path} — back it up; without it the database can't be opened.");
    Ok(key)
}

fn badges(args: &Args) -> Result<()> {
    let key_path = args.opts.get("key").cloned().unwrap_or_else(|| "badge-issuer.key".into());
    if args.cmd == "badge-key" {
        if std::path::Path::new(&key_path).exists() {
            return Err(anyhow!("{key_path} already exists — refusing to overwrite a signing key"));
        }
        let k = Keypair::generate();
        #[cfg(unix)]
        {
            use std::io::Write;
            use std::os::unix::fs::OpenOptionsExt;
            let mut f = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(&key_path)?;
            f.write_all(hex::encode(k.secret_bytes()).as_bytes())?;
        }
        #[cfg(not(unix))]
        std::fs::write(&key_path, hex::encode(k.secret_bytes()))?;
        println!("Badge-signing key written to {key_path}. Keep it offline and backed up.");
        println!("Paste this public key into SECURITY_ISSUERS in crates/moot-core/src/badge.rs:\n  {}", k.public().to_hex());
        return Ok(());
    }
    let secret = hex::decode(std::fs::read_to_string(&key_path)?.trim())?;
    let secret: [u8; 32] = secret.try_into().map_err(|_| anyhow!("{key_path} is not a badge key"))?;
    let issuer = Keypair::from_secret(secret);
    let get = |k: &str| args.opts.get(k).cloned().ok_or_else(|| anyhow!("missing --{k}"));
    let holder = PublicKey::from_hex(&get("to")?)?;
    let tier = BadgeTier::parse(&get("tier")?).ok_or_else(|| anyhow!("tier must be finder, hunter or legend"))?;
    let badge = Badge::issue(&issuer, holder, tier, &get("title")?, &args.opts.get("advisory").cloned().unwrap_or_default())?;
    println!("Badge for {} ({tier:?}). Send them this code; they paste it in Settings → Account → Badges:\n{}", holder.fingerprint(), badge.encode());
    Ok(())
}

async fn start_peer(store: &Store, args: &Args, library: Library) -> Result<Peer> {
    let key = store.persistent_secret("network_key")?;
    let peer = Peer::spawn_keyed(args.mode(), library, key).await?;
    println!("Network mode: {} ({})", peer.mode().label(), if peer.mode().hides_ip() { "your IP is hidden from peers" } else { "peers can see your IP" });
    Ok(peer)
}

fn account(store: &Store) -> Result<(Identity, Device, String)> {
    store.load_account()?.ok_or_else(|| anyhow!("no node key yet: run `moot-node init` first"))
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = parse();
    // Badge commands don't touch the node database.
    if args.cmd == "badge-key" || args.cmd == "issue-badge" {
        return badges(&args);
    }
    let store = Store::open(&args.data, vault_key(&args.data)?)?;
    match args.cmd.as_str() {
        "init" => {
            if store.load_account()?.is_some() {
                println!("This node already has a key.");
                return Ok(());
            }
            let (id, phrase) = Identity::create();
            let dev = Device::new(&id, &args.name);
            store.save_account(&id, &dev, &args.name)?;
            println!("Node created: {}", args.name);
            println!("Identity fingerprint: moot:{}", id.public().fingerprint());
            println!("Recovery phrase (write it down, it is not shown again):\n  {}", phrase.0);
        }
        "demo" => {
            let (_id, dev, _) = account(&store)?;
            let (mut c, evs) = CommunityState::create(&dev, "Pixel Foundry", "Indie devs trading devlogs and shader tricks", Visibility::Public)?;
            store.save_events(&c.id, &evs)?;
            for text in ["Welcome to Pixel Foundry!", "Shader Jam #7 is this Friday at 20:00 WET."] {
                let e = c.author(&dev, EventKind::Message { channel: "general".into(), text: text.into(), reply_to: None })?;
                store.save_event(&c.id, &e)?;
            }
            println!("Created community {} ({})", c.name, c.id.to_hex());
        }
        "list" => {
            for (id, name) in store.list_communities()? {
                let c = store.load_community(&id)?;
                println!("{name}  {}  {} events, {} members", id.to_hex(), c.len(), c.members.len());
            }
        }
        "join" => {
            let (_id, dev, _) = account(&store)?;
            let invite = Invite::decode(args.code.as_deref().ok_or_else(|| anyhow!("usage: moot-node join CODE"))?)?;
            let peer = start_peer(&store, &args, Library::default()).await?;
            let joined = peer.join(&invite, &dev).await?;
            let evs = peer.library.with(&joined.community, |s| s.events_in_order().cloned().collect::<Vec<_>>()).unwrap_or_default();
            store.save_events(&joined.community, &evs)?;
            let host = if args.local { invite.host.clone() } else { strip_ips(invite.host.clone()) };
            store.save_remote(&joined.community, &serde_json::to_string(&host)?)?;
            println!("Joined and stored {} events ({} new). `moot-node serve` will keep it online.", evs.len(), joined.report.applied);
            peer.shutdown().await?;
        }
        "serve" => {
            let (_id, _dev, name) = account(&store)?;
            let peer = start_peer(&store, &args, Library::default()).await?;
            let ids: Vec<_> = store.list_communities()?.into_iter().map(|(id, _)| id).collect();
            for id in &ids {
                peer.library.insert(store.load_community(id)?);
            }
            println!("{name} is online. Node id: {}", peer.id());
            println!("Hosting {} communities. Press Ctrl+C to stop.", ids.len());
            if !args.local {
                let _ = tokio::time::timeout(Duration::from_secs(8), peer.online()).await;
            }
            for id in &ids {
                let public = peer.library.with(id, |s| (s.visibility == Visibility::Public, s.name.clone()));
                if let Some((true, name)) = public {
                    println!("\nInvite code for {name} (paste it into Moot → + → Join with a code):\n{}", peer.invite(id)?.encode());
                }
            }
            let remotes: Vec<(moot_core::EventId, EndpointAddr)> = store
                .load_remotes()?
                .into_iter()
                .filter_map(|(id, a)| serde_json::from_str(&a).ok().map(|a| (id, a)))
                .collect();
            let mut tick = tokio::time::interval(Duration::from_secs(5));
            loop {
                tokio::select! {
                    _ = tick.tick() => {
                        for (id, addr) in &remotes {
                            if let Ok(Ok(r)) = tokio::time::timeout(Duration::from_secs(10), peer.sync_with(addr.clone(), *id)).await {
                                if r.applied > 0 { println!("pulled {} events from a peer", r.applied); }
                            }
                        }
                        for r in peer.received() {
                            println!("sync: +{} events, {} rejected", r.applied, r.rejected.len());
                        }
                        // Persist anything new.
                        for id in &ids {
                            if let Some(evs) = peer.library.with(id, |s| s.events_in_order().cloned().collect::<Vec<_>>()) {
                                store.save_events(id, &evs)?;
                            }
                        }
                    }
                    _ = tokio::signal::ctrl_c() => {
                        println!("Shutting down.");
                        peer.shutdown().await?;
                        return Ok(());
                    }
                }
            }
        }
        _ => {
            println!("moot-node — keep Moot communities online\n");
            println!("  moot-node init  [--data node.db] [--name NAME]");
            println!("  moot-node demo  [--data node.db]");
            println!("  moot-node list  [--data node.db]");
            println!("  moot-node serve [--data node.db] [--local]");
            println!("  moot-node join CODE [--data node.db] [--local]");
        }
    }
    Ok(())
}
