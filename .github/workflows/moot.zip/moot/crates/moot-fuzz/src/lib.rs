//! Fuzz harnesses for everything Moot reads from other people.
//!
//! Each function takes arbitrary bytes and must never panic, hang or allocate without
//! bound. Where there is a property to check (round trips, permission rules), the harness
//! asserts it — an assertion failure counts as a bug.
//!
//! The same harnesses are driven two ways:
//! * `fuzz/` — coverage-guided fuzzing with cargo-fuzz (libFuzzer), for long runs;
//! * the tests below — a fast randomized pass on stable Rust, run on every `cargo test`.

use arbitrary::{Arbitrary, Unstructured};
use moot_core::sync::import;
use moot_core::*;
use moot_net::{fuzzing, Invite};
use std::sync::OnceLock;

// ---------------------------------------------------------------- fixtures

/// Deterministic people, so any crash reproduces exactly from its input.
pub struct Cast {
    pub owner: Device,
    pub others: Vec<Device>,
    pub genesis: Event,
    pub base: CommunityState,
}

fn device(seed: u8, name: &str) -> Device {
    let id = Identity::from_secret([seed; 32]);
    let key = Keypair::from_secret([seed.wrapping_add(100); 32]);
    let cert = id.certify_device(&key.public(), name);
    Device::from_parts(key.secret_bytes(), cert).unwrap()
}

pub fn cast() -> &'static Cast {
    static CAST: OnceLock<Cast> = OnceLock::new();
    CAST.get_or_init(|| {
        let owner = device(1, "owner");
        let others = (2..7).map(|i| device(i, "member")).collect();
        let (base, evs) = CommunityState::create(&owner, "Fuzz Club", "", Visibility::Public).unwrap();
        Cast { owner, others, genesis: evs[0].clone(), base }
    })
}

// ---------------------------------------------------------------- byte-level harnesses

/// Invite codes arrive as text from anyone. Decoding must never panic, and anything that
/// decodes must survive a re-encode unchanged and carry a valid genesis.
pub fn invite_code(data: &[u8]) {
    let text = String::from_utf8_lossy(data);
    if let Ok(inv) = Invite::decode(&text) {
        assert!(inv.genesis.verify_self().is_ok(), "decoded invite with an unverified genesis");
        let again = Invite::decode(&inv.encode()).expect("re-encoded invite must decode");
        assert_eq!(again.community(), inv.community());
        assert_eq!(again.host, inv.host);
    }
}

/// Network frames from peers: decode, then hand them to a community like the host does.
pub fn sync_frame(data: &[u8]) {
    let _ = fuzzing::decode_frame(data);
    let mut state = cast().base.clone();
    let before = state.len();
    if let Some(report) = fuzzing::handle_frame(&mut state, data) {
        assert_eq!(state.len(), before + report.applied, "import report disagrees with the state");
    }
}

/// Raw events (binary and JSON): must never panic, and nothing unverified may be applied.
pub fn event_bytes(data: &[u8]) {
    for ev in [Event::from_bytes(data).ok(), std::str::from_utf8(data).ok().and_then(|s| Event::from_json(s).ok())].into_iter().flatten() {
        let mut state = cast().base.clone();
        if state.apply(&ev).is_ok() {
            assert!(ev.verify_self().is_ok(), "applied an event that doesn't verify");
            assert_eq!(ev.body.community, state.id);
        }
        let _ = ev.to_json();
    }
}

/// Recovery phrases and social-recovery shares typed or pasted by users.
pub fn recovery(data: &[u8]) {
    let text = String::from_utf8_lossy(data);
    let _ = Identity::from_phrase(&RecoveryPhrase(text.to_string()));
    if let Some((&threshold, rest)) = data.split_first() {
        let shares: Vec<RecoveryShare> = rest.chunks(34).map(|c| RecoveryShare(c.to_vec())).collect();
        let _ = Identity::recover_from_shares(threshold, &shares);
    }
    let _ = VaultKey::from_hex(&text);
    if let Ok(b) = Badge::decode(&text) {
        let _ = b.verify();
        assert_eq!(Badge::decode(&b.encode()).unwrap(), b, "badge round trip changed it");
    }
    let _ = PublicKey::from_hex(&text);
}

// ---------------------------------------------------------------- structured harness

#[derive(Arbitrary, Debug)]
enum Kind {
    Message { channel: u8, text: String, reply: Option<u8> },
    Edit { target: u8, text: String },
    Delete { target: u8 },
    Join,
    Leave,
    Invite { who: u8 },
    Grant { who: u8, role: u8 },
    Ban { who: u8 },
    Unban { who: u8 },
    Channel { id: u8, kind: u8, private: bool },
    Backup { who: u8 },
    Transfer { who: u8 },
    Node { who: u8 },
    Unnode { who: u8 },
}

#[derive(Arbitrary, Debug)]
enum Parents {
    /// Normal: the current heads.
    Heads,
    /// One earlier event (a concurrent branch).
    Old(u8),
    /// No parents at all.
    None,
    /// A made-up parent that doesn't exist.
    Missing,
}

#[derive(Arbitrary, Debug)]
struct Op {
    actor: u8,
    kind: Kind,
    parents: Parents,
    /// Lamport clock offset from the correct value (negative = stale, wrong).
    clock: i8,
}

/// Validly signed events of every kind, from owner, members and strangers, with sane and
/// insane parents and clocks. Checks the permission rules hold after every step and that
/// whatever was accepted is accepted again on replay.
///
/// Returns (operations tried, operations accepted) so tests can check it isn't vacuous.
pub fn community_ops(data: &[u8]) -> (usize, usize) {
    let c = cast();
    let mut u = Unstructured::new(data);
    let mut ops = Vec::new();
    while ops.len() < 64 {
        match Op::arbitrary(&mut u) {
            Ok(op) => ops.push(op),
            Err(_) => break,
        }
    }
    let tried = ops.len();
    let mut state = c.base.clone();
    let mut accepted: Vec<Event> = Vec::new();
    let all: Vec<&Device> = std::iter::once(&c.owner).chain(c.others.iter()).collect();
    let pk = |i: u8| all[i as usize % all.len()].identity();
    let channels = ["general", "announcements", "art", "voice"];

    for op in ops {
        let dev = all[op.actor as usize % all.len()];
        let ids: Vec<EventId> = state.events_in_order().map(|e| e.id).collect();
        let pick = |i: u8| ids[i as usize % ids.len()];
        let kind = match op.kind {
            Kind::Message { channel, text, reply } => EventKind::Message {
                channel: channels[channel as usize % channels.len()].into(),
                text: text.chars().take(200).collect(),
                reply_to: reply.map(pick),
            },
            Kind::Edit { target, text } => EventKind::Edit { target: pick(target), text: text.chars().take(200).collect() },
            Kind::Delete { target } => EventKind::Delete { target: pick(target) },
            Kind::Join => EventKind::Join,
            Kind::Leave => EventKind::Leave,
            Kind::Invite { who } => EventKind::Invite { member: pk(who) },
            Kind::Grant { who, role } => EventKind::RoleGrant {
                member: pk(who),
                role: [Role::Member, Role::Moderator, Role::Admin, Role::Owner][role as usize % 4],
            },
            Kind::Ban { who } => EventKind::Ban { member: pk(who), reason: String::new() },
            Kind::Unban { who } => EventKind::Unban { member: pk(who) },
            Kind::Channel { id, kind, private } => EventKind::ChannelCreate {
                channel: channels[id as usize % channels.len()].into(),
                name: "x".into(),
                kind: [ChannelKind::Text, ChannelKind::Voice, ChannelKind::Announcement][kind as usize % 3],
                private,
            },
            Kind::Backup { who } => EventKind::SetBackupOwner { backup: pk(who) },
            Kind::Transfer { who } => EventKind::OwnershipTransfer { to: pk(who) },
            Kind::Node { who } => EventKind::NodeCertify { node: pk(who), name: "n".into() },
            Kind::Unnode { who } => EventKind::NodeRevoke { node: pk(who) },
        };
        let prev = match op.parents {
            Parents::Heads => state.heads(),
            Parents::Old(i) => vec![pick(i)],
            Parents::None => vec![],
            Parents::Missing => vec![EventId::from_hex(&"ab".repeat(32)).unwrap()],
        };
        let parent_clock = prev.iter().filter_map(|p| state.event(p)).map(|e| e.body.lamport).max().unwrap_or(0);
        let lamport = (parent_clock as i64 + 1 + op.clock as i64).max(0) as u64;
        let author = dev.identity();
        let was_banned = state.banned.contains(&author);
        let was_member = state.members.contains(&author);
        let is_message = matches!(kind, EventKind::Message { .. });
        let ev = Event::new(dev, state.id, prev, lamport, kind);
        // Identical operations in the same millisecond produce the identical event, which
        // `apply` treats as already known. Count each event once.
        let new = !state.contains(&ev.id);

        if state.apply(&ev).is_ok() && new {
            accepted.push(ev);
            // Banned people can't speak; strangers can't speak.
            if is_message {
                assert!(!was_banned, "a banned identity posted a message");
                assert!(was_member, "a non-member posted a message");
            }
        }
        check_invariants(&state);
    }

    // Replay determinism: the accepted log must be accepted again, in full, by a replica.
    let mut replica = CommunityState::from_genesis(&c.genesis).unwrap();
    for e in c.base.events_in_order().skip(1) {
        replica.apply(e).unwrap();
    }
    let report = import(&mut replica, accepted.clone());
    assert_eq!(report.applied, accepted.len(), "replica rejected events the original accepted: {:?}", report.rejected);
    assert_eq!(replica.len(), state.len());
    assert_eq!(replica.owner, state.owner);
    assert_eq!(replica.members, state.members);
    assert_eq!(replica.banned, state.banned);
    same_state(&state, &replica);

    // Convergence: the same events delivered in a scrambled order give the same state.
    let mut scrambled = accepted.clone();
    let n = scrambled.len();
    for i in 0..n {
        let j = (data.get(i).copied().unwrap_or(0) as usize * 31 + i * 17) % n;
        scrambled.swap(i, j);
    }
    let mut third = CommunityState::from_genesis(&c.genesis).unwrap();
    for e in c.base.events_in_order().skip(1) {
        third.apply(e).unwrap();
    }
    for e in scrambled.iter().rev() {
        let _ = third.apply(e); // some arrive before their parents; import below retries
    }
    let r = import(&mut third, scrambled);
    assert!(r.rejected.is_empty(), "scrambled delivery rejected events: {:?}", r.rejected);
    same_state(&state, &third);
    (tried, accepted.len())
}

fn same_state(a: &CommunityState, b: &CommunityState) {
    assert_eq!(a.len(), b.len(), "different number of events");
    assert_eq!(a.owner, b.owner, "replicas disagree on the owner");
    assert_eq!(a.backup_owner, b.backup_owner);
    assert_eq!(a.members, b.members, "replicas disagree on members");
    assert_eq!(a.banned, b.banned, "replicas disagree on bans");
    assert_eq!(a.roles, b.roles, "replicas disagree on roles");
    assert_eq!(a.invited, b.invited);
    assert_eq!(a.channels, b.channels);
    assert_eq!(a.nodes, b.nodes);
    for ch in ["general", "announcements", "art"] {
        let ma: Vec<_> = a.messages(ch).iter().map(|m| (m.id, m.text.clone(), m.edited)).collect();
        let mb: Vec<_> = b.messages(ch).iter().map(|m| (m.id, m.text.clone(), m.edited)).collect();
        assert_eq!(ma, mb, "replicas disagree on messages in #{ch}");
    }
    for e in a.events_in_order() {
        assert_eq!(a.is_effective(&e.id), b.is_effective(&e.id), "replicas disagree whether an event took effect");
    }
    let oa: Vec<_> = a.events_in_order().map(|e| e.id).collect();
    let ob: Vec<_> = b.events_in_order().map(|e| e.id).collect();
    assert_eq!(oa, ob, "replicas disagree on the canonical order");
}

fn check_invariants(s: &CommunityState) {
    assert_eq!(s.role_of(&s.owner), Some(Role::Owner), "the owner lost the owner role");
    assert!(!s.banned.contains(&s.owner), "the owner was banned");
    for b in &s.banned {
        assert!(!s.members.contains(b), "a banned identity is still a member");
    }
    let owners = s.roles.iter().filter(|(_, r)| **r == Role::Owner).count();
    assert!(owners <= 1, "more than one owner");
    assert!(s.members.contains(&s.owner), "the owner isn't a member");
}

// ---------------------------------------------------------------- seeds

/// Valid inputs to start mutating from.
pub fn seeds() -> Vec<(&'static str, Vec<u8>)> {
    let c = cast();
    let mut st = c.base.clone();
    let msg = st.author(&c.owner, EventKind::Message { channel: "general".into(), text: "hi".into(), reply_to: None }).unwrap();
    let key = iroh_free_addr_bytes();
    let invite = Invite { genesis: c.genesis.clone(), host: key }.encode();
    vec![
        ("invite_code", invite.into_bytes()),
        ("sync_frame", fuzzing::encode_push(vec![msg.clone()])),
        ("event_bytes", msg.to_bytes()),
        ("event_bytes", msg.to_json().into_bytes()),
        ("recovery", Identity::create().1 .0.clone().into_bytes()),
    ]
}

fn iroh_free_addr_bytes() -> moot_net::EndpointAddr {
    // A syntactically valid address without touching the network stack.
    let invite_code = {
        let c = cast();
        let fake = moot_net::EndpointAddr::from_parts(
            c.owner.identity().to_hex().parse().expect("ed25519 keys are valid endpoint ids"),
            [moot_net::TransportAddr::Relay("https://relay.example.org".parse().unwrap())],
        );
        fake
    };
    invite_code
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Small, dependency-free PRNG so failures reproduce from the printed seed.
    struct Rng(u64);
    impl Rng {
        fn next(&mut self) -> u64 {
            self.0 ^= self.0 << 13;
            self.0 ^= self.0 >> 7;
            self.0 ^= self.0 << 17;
            self.0
        }
        fn below(&mut self, n: usize) -> usize {
            (self.next() % n.max(1) as u64) as usize
        }
        fn bytes(&mut self, max: usize) -> Vec<u8> {
            let n = self.below(max + 1);
            (0..n).map(|_| self.next() as u8).collect()
        }
        /// Flip, insert, delete and splice bytes of a valid input.
        fn mutate(&mut self, seed: &[u8]) -> Vec<u8> {
            let mut v = seed.to_vec();
            for _ in 0..1 + self.below(8) {
                match self.below(5) {
                    0 if !v.is_empty() => {
                        let i = self.below(v.len());
                        v[i] ^= 1 << self.below(8);
                    }
                    1 => {
                        let i = self.below(v.len() + 1);
                        v.insert(i, self.next() as u8);
                    }
                    2 if !v.is_empty() => {
                        let i = self.below(v.len());
                        v.remove(i);
                    }
                    3 if !v.is_empty() => {
                        let i = self.below(v.len());
                        v.truncate(i);
                    }
                    _ => {
                        let i = self.below(v.len() + 1);
                        let extra = self.bytes(16);
                        v.splice(i..i, extra);
                    }
                }
            }
            v
        }
    }

    fn run(name: &str, f: fn(&[u8]), iterations: usize) {
        let seeds: Vec<Vec<u8>> = seeds().into_iter().filter(|(n, _)| *n == name).map(|(_, b)| b).collect();
        let mut rng = Rng(0x9E37_79B9_7F4A_7C15 ^ name.len() as u64);
        for i in 0..iterations {
            let input = if !seeds.is_empty() && i % 3 != 0 { rng.mutate(&seeds[i % seeds.len()]) } else { rng.bytes(512) };
            f(&input);
        }
        for s in &seeds {
            f(s);
        }
    }

    #[test]
    fn invite_codes_survive_garbage() {
        run("invite_code", invite_code, 20_000);
    }

    #[test]
    fn sync_frames_survive_garbage() {
        run("sync_frame", sync_frame, 20_000);
    }

    #[test]
    fn events_survive_garbage() {
        run("event_bytes", event_bytes, 20_000);
    }

    #[test]
    fn recovery_input_survives_garbage() {
        run("recovery", recovery, 3_000);
    }

    #[test]
    fn community_rules_hold_under_random_operations() {
        let mut rng = Rng(42);
        let (mut tried, mut accepted) = (0, 0);
        for _ in 0..300 {
            let data = rng.bytes(2048);
            let (t, a) = community_ops(&data);
            tried += t;
            accepted += a;
        }
        println!("community_ops: {tried} operations tried, {accepted} accepted");
        assert!(tried > 5_000, "harness generated too few operations: {tried}");
        assert!(accepted > 200, "harness is vacuous: only {accepted} operations were accepted");
    }

    /// `MOOT_SEED_DIR=fuzz/corpus cargo test -p moot-fuzz write_seed_corpus -- --ignored`
    #[test]
    #[ignore]
    fn write_seed_corpus() {
        let dir = std::path::PathBuf::from(std::env::var("MOOT_SEED_DIR").expect("set MOOT_SEED_DIR"));
        for (i, (name, bytes)) in seeds().into_iter().enumerate() {
            let d = dir.join(name);
            std::fs::create_dir_all(&d).unwrap();
            std::fs::write(d.join(format!("seed-{i}")), bytes).unwrap();
        }
        let d = dir.join("community_ops");
        std::fs::create_dir_all(&d).unwrap();
        let mut rng = Rng(7);
        for i in 0..8 {
            std::fs::write(d.join(format!("seed-{i}")), rng.bytes(2048)).unwrap();
        }
    }

    #[test]
    fn seeds_are_valid() {
        let s = seeds();
        assert!(Invite::decode(std::str::from_utf8(&s[0].1).unwrap()).is_ok());
        assert!(fuzzing::decode_frame(&s[1].1));
        assert!(Event::from_bytes(&s[2].1).is_ok());
    }
}
