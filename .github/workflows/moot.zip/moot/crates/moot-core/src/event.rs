//! Events: the only way anything happens in a community.
//!
//! An event's id is the BLAKE3 hash of its body, and the body names the events that came
//! before it (`prev`). So the log is a hash-linked graph: changing any past event changes
//! every id after it, and a node can't quietly rewrite history.

use crate::identity::{Device, DeviceCert, PublicKey, Sig};
use crate::{now_ms, Error, Result};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct EventId(pub [u8; 32]);

impl EventId {
    pub const ZERO: EventId = EventId([0; 32]);

    pub fn to_hex(&self) -> String {
        hex::encode(self.0)
    }

    pub fn from_hex(s: &str) -> Result<Self> {
        let v = hex::decode(s).map_err(|_| Error::InvalidArgument("event id".into()))?;
        Ok(EventId(v.try_into().map_err(|_| Error::InvalidArgument("event id".into()))?))
    }

    pub fn short(&self) -> String {
        hex::encode(&self.0[..4])
    }
}

impl std::fmt::Debug for EventId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "EventId({})", self.short())
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum EventKind {
    /// The first event; its id becomes the community id.
    Genesis { name: String, description: String, visibility: crate::Visibility },
    ChannelCreate { channel: String, name: String, kind: crate::ChannelKind, private: bool },
    Invite { member: PublicKey },
    Join,
    Leave,
    RoleGrant { member: PublicKey, role: crate::Role },
    Message { channel: String, text: String, reply_to: Option<EventId> },
    Edit { target: EventId, text: String },
    Delete { target: EventId },
    Ban { member: PublicKey, reason: String },
    Unban { member: PublicKey },
    NodeCertify { node: PublicKey, name: String },
    NodeRevoke { node: PublicKey },
    SetBackupOwner { backup: PublicKey },
    OwnershipTransfer { to: PublicKey },
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct EventBody {
    /// The community's id (the genesis event id). `ZERO` for the genesis itself.
    pub community: EventId,
    /// Who wrote it: the device, and the identity's certificate for that device.
    pub author: DeviceCert,
    /// The heads of the log when this event was written.
    pub prev: Vec<EventId>,
    /// Lamport clock: always greater than every parent's.
    pub lamport: u64,
    pub timestamp_ms: u64,
    pub kind: EventKind,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Event {
    pub id: EventId,
    pub body: EventBody,
    /// The device's signature over the id.
    pub sig: Sig,
}

fn signing_bytes(id: &EventId) -> Vec<u8> {
    let mut v = b"moot/event/v1:".to_vec();
    v.extend_from_slice(&id.0);
    v
}

impl EventBody {
    pub fn hash(&self) -> EventId {
        let bytes = postcard::to_allocvec(self).expect("postcard encoding of plain data cannot fail");
        EventId(*blake3::hash(&bytes).as_bytes())
    }
}

impl Event {
    /// Create and sign an event.
    pub fn new(device: &Device, community: EventId, prev: Vec<EventId>, lamport: u64, kind: EventKind) -> Event {
        let body = EventBody {
            community,
            author: device.cert.clone(),
            prev,
            lamport,
            timestamp_ms: now_ms(),
            kind,
        };
        let id = body.hash();
        let sig = device.key.sign(&signing_bytes(&id));
        Event { id, body, sig }
    }

    /// Checks that need nothing but the event itself: id, device certificate, signature.
    pub fn verify_self(&self) -> Result<()> {
        if self.body.hash() != self.id {
            return Err(Error::BadEventId);
        }
        self.body.author.verify()?;
        self.body.author.device.verify(&signing_bytes(&self.id), &self.sig)
    }

    /// The account (identity) that wrote this event.
    pub fn author_identity(&self) -> PublicKey {
        self.body.author.identity
    }

    pub fn to_json(&self) -> String {
        serde_json::to_string(self).expect("events serialize")
    }

    pub fn from_json(s: &str) -> Result<Event> {
        serde_json::from_str(s).map_err(|e| Error::InvalidArgument(format!("event json: {e}")))
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        postcard::to_allocvec(self).expect("events serialize")
    }

    pub fn from_bytes(b: &[u8]) -> Result<Event> {
        postcard::from_bytes(b).map_err(|e| Error::InvalidArgument(format!("event bytes: {e}")))
    }
}
