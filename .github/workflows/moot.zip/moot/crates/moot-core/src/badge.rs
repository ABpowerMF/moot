//! Security researcher badges.
//!
//! When someone reports a real vulnerability, the Moot security team signs a badge for the
//! researcher's identity key. The badge is a small certificate: who earned it, which tier,
//! which advisory, signed by a key listed in [`SECURITY_ISSUERS`]. Anyone can verify it
//! offline, and it can't be copied onto someone else's profile because it names their key.
//!
//! Tiers follow severity: **Finder** (low), **Hunter** (medium/high), **Legend** (critical).

use crate::identity::{Keypair, PublicKey, Sig};
use crate::{now_ms, Error, Result};
use serde::{Deserialize, Serialize};

/// Public keys allowed to issue badges, as hex. Generate one with `moot-node badge-key`
/// on a machine you trust, keep the key file offline, and paste the public key here.
pub const SECURITY_ISSUERS: &[&str] = &[];

const DOMAIN: &[u8] = b"moot/badge/v1:";
const PREFIX: &str = "mootbadge1";

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum BadgeTier {
    Finder,
    Hunter,
    Legend,
}

impl BadgeTier {
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_ascii_lowercase().as_str() {
            "finder" | "low" => Some(BadgeTier::Finder),
            "hunter" | "medium" | "high" => Some(BadgeTier::Hunter),
            "legend" | "critical" => Some(BadgeTier::Legend),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct BadgeBody {
    pub holder: PublicKey,
    pub tier: BadgeTier,
    /// Short public description, e.g. "Crash in invite code decoding".
    pub title: String,
    /// Advisory id, e.g. "MOOT-2026-001".
    pub advisory: String,
    pub issued_ms: u64,
    pub issuer: PublicKey,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Badge {
    pub body: BadgeBody,
    pub sig: Sig,
}

fn signing_bytes(body: &BadgeBody) -> Vec<u8> {
    let mut m = DOMAIN.to_vec();
    m.extend(postcard::to_allocvec(body).expect("badge body serialises"));
    m
}

impl Badge {
    pub fn issue(issuer: &Keypair, holder: PublicKey, tier: BadgeTier, title: &str, advisory: &str) -> Result<Self> {
        if title.trim().is_empty() || title.len() > 120 || advisory.len() > 40 {
            return Err(Error::InvalidArgument("title must be 1-120 characters, advisory up to 40".into()));
        }
        let body = BadgeBody { holder, tier, title: title.trim().into(), advisory: advisory.trim().into(), issued_ms: now_ms(), issuer: issuer.public() };
        let sig = issuer.sign(&signing_bytes(&body));
        Ok(Badge { body, sig })
    }

    /// Check the signature and that the issuer is one of `trusted`.
    pub fn verify_with(&self, trusted: &[PublicKey]) -> Result<()> {
        if !trusted.contains(&self.body.issuer) {
            return Err(Error::NotAllowed("not issued by the Moot security team".into()));
        }
        self.body.issuer.verify(&signing_bytes(&self.body), &self.sig)
    }

    /// Check against the issuers built into this version of Moot.
    pub fn verify(&self) -> Result<()> {
        let trusted: Vec<PublicKey> = SECURITY_ISSUERS.iter().filter_map(|h| PublicKey::from_hex(h).ok()).collect();
        self.verify_with(&trusted)
    }

    pub fn encode(&self) -> String {
        format!("{PREFIX}{}", hex::encode(postcard::to_allocvec(self).expect("badge serialises")))
    }

    pub fn decode(code: &str) -> Result<Self> {
        let code = code.trim();
        if code.len() > 4096 {
            return Err(Error::InvalidArgument("badge code too long".into()));
        }
        let hexpart = code.strip_prefix(PREFIX).ok_or_else(|| Error::InvalidArgument("not a Moot badge code".into()))?;
        let bytes = hex::decode(hexpart).map_err(|_| Error::InvalidArgument("badge code is damaged".into()))?;
        postcard::from_bytes(&bytes).map_err(|_| Error::InvalidArgument("badge code is damaged".into()))
    }
}
