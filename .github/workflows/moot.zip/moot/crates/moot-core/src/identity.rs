//! Accounts are keys the user owns.
//!
//! * An **identity key** (Ed25519) is the account. It is derived from a 12-word recovery
//!   phrase, so the phrase alone can restore it.
//! * Each device gets its own **device key**, certified by the identity key
//!   (cross-signing). Day-to-day messages are signed by the device, so one device can be
//!   revoked without touching the others.
//! * The identity secret can also be split for **social recovery** (e.g. 2 of 3 friends).

use crate::{now_ms, Error, Result};
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use zeroize::Zeroize;

/// A public key, as bytes, with a stable text form.
#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct PublicKey(pub [u8; 32]);

impl PublicKey {
    pub fn verifying_key(&self) -> Result<VerifyingKey> {
        VerifyingKey::from_bytes(&self.0).map_err(|_| Error::BadKey)
    }

    pub fn verify(&self, msg: &[u8], sig: &Sig) -> Result<()> {
        let vk = self.verifying_key()?;
        vk.verify(msg, &Signature::from_bytes(&sig.to_bytes())).map_err(|_| Error::BadSignature)
    }

    /// Short, human-comparable fingerprint, e.g. `7F3A 91C2 4E0D B6A1`.
    pub fn fingerprint(&self) -> String {
        let h = blake3::hash(&self.0);
        let hexs = hex::encode_upper(&h.as_bytes()[..8]);
        hexs.as_bytes()
            .chunks(4)
            .map(|c| std::str::from_utf8(c).unwrap().to_string())
            .collect::<Vec<_>>()
            .join(" ")
    }

    pub fn to_hex(&self) -> String {
        hex::encode(self.0)
    }

    pub fn from_hex(s: &str) -> Result<Self> {
        let v = hex::decode(s).map_err(|_| Error::BadKey)?;
        let a: [u8; 32] = v.try_into().map_err(|_| Error::BadKey)?;
        Ok(PublicKey(a))
    }
}

impl std::fmt::Debug for PublicKey {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "PublicKey({})", self.fingerprint())
    }
}

/// An Ed25519 signature (stored as two 32-byte halves so serde can derive it).
#[derive(Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Sig {
    hi: [u8; 32],
    lo: [u8; 32],
}

impl Sig {
    pub const EMPTY: Sig = Sig { hi: [0; 32], lo: [0; 32] };

    pub fn from_bytes(b: [u8; 64]) -> Self {
        let mut hi = [0u8; 32];
        let mut lo = [0u8; 32];
        hi.copy_from_slice(&b[..32]);
        lo.copy_from_slice(&b[32..]);
        Sig { hi, lo }
    }

    pub fn to_bytes(&self) -> [u8; 64] {
        let mut out = [0u8; 64];
        out[..32].copy_from_slice(&self.hi);
        out[32..].copy_from_slice(&self.lo);
        out
    }
}

impl std::fmt::Debug for Sig {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Sig({}…)", hex::encode(&self.hi[..6]))
    }
}

/// A key pair that can sign. Secret bytes are wiped on drop.
pub struct Keypair {
    signing: SigningKey,
}

impl Keypair {
    pub fn generate() -> Self {
        Keypair { signing: SigningKey::generate(&mut OsRng) }
    }

    pub fn from_secret(mut secret: [u8; 32]) -> Self {
        let kp = Keypair { signing: SigningKey::from_bytes(&secret) };
        secret.zeroize();
        kp
    }

    pub fn public(&self) -> PublicKey {
        PublicKey(self.signing.verifying_key().to_bytes())
    }

    pub fn sign(&self, msg: &[u8]) -> Sig {
        Sig::from_bytes(self.signing.sign(msg).to_bytes())
    }

    /// Raw secret, for encrypted storage. Handle with care.
    pub fn secret_bytes(&self) -> [u8; 32] {
        self.signing.to_bytes()
    }
}

/// The account. Derived deterministically from the recovery phrase.
pub struct Identity {
    key: Keypair,
}

/// What a device proves to everyone else: "this device key belongs to this identity".
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct DeviceCert {
    pub identity: PublicKey,
    pub device: PublicKey,
    pub device_name: String,
    pub issued_ms: u64,
    pub sig: Sig,
}

#[derive(Serialize)]
struct DeviceCertBody<'a> {
    domain: &'static str,
    identity: &'a PublicKey,
    device: &'a PublicKey,
    device_name: &'a str,
    issued_ms: u64,
}

impl DeviceCert {
    fn body(&self) -> Vec<u8> {
        postcard::to_allocvec(&DeviceCertBody {
            domain: "moot/device-cert/v1",
            identity: &self.identity,
            device: &self.device,
            device_name: &self.device_name,
            issued_ms: self.issued_ms,
        })
        .expect("postcard encoding of plain data cannot fail")
    }

    /// Check that the identity really signed this device key.
    pub fn verify(&self) -> Result<()> {
        self.identity.verify(&self.body(), &self.sig).map_err(|_| Error::BadCertificate)
    }
}

impl Identity {
    /// Create a new account. Returns the identity and its 12-word recovery phrase.
    pub fn create() -> (Self, RecoveryPhrase) {
        let mut entropy = [0u8; 16];
        rand::RngCore::fill_bytes(&mut OsRng, &mut entropy);
        let mnemonic = bip39::Mnemonic::from_entropy(&entropy).expect("16 bytes is valid BIP-39 entropy");
        entropy.zeroize();
        let phrase = RecoveryPhrase(mnemonic.to_string());
        let id = Self::from_phrase(&phrase).expect("freshly generated phrase is valid");
        (id, phrase)
    }

    /// Restore an account from its recovery phrase.
    pub fn from_phrase(phrase: &RecoveryPhrase) -> Result<Self> {
        let mnemonic = bip39::Mnemonic::parse_normalized(phrase.0.trim()).map_err(|_| Error::BadRecoveryPhrase)?;
        let seed = mnemonic.to_seed("");
        let secret = blake3::derive_key("moot identity key v1", &seed);
        Ok(Identity { key: Keypair::from_secret(secret) })
    }

    pub fn from_secret(secret: [u8; 32]) -> Self {
        Identity { key: Keypair::from_secret(secret) }
    }

    pub fn public(&self) -> PublicKey {
        self.key.public()
    }

    pub fn secret_bytes(&self) -> [u8; 32] {
        self.key.secret_bytes()
    }

    /// Certify a device key (done once, when a device is added).
    pub fn certify_device(&self, device: &PublicKey, device_name: &str) -> DeviceCert {
        let mut cert = DeviceCert {
            identity: self.public(),
            device: *device,
            device_name: device_name.to_string(),
            issued_ms: now_ms(),
            sig: Sig::EMPTY,
        };
        cert.sig = self.key.sign(&cert.body());
        cert
    }

    /// Split the identity secret so that any `threshold` of `shares` friends can restore it.
    pub fn split_for_social_recovery(&self, threshold: u8, shares: u8) -> Result<Vec<RecoveryShare>> {
        if threshold < 2 || threshold > shares {
            return Err(Error::InvalidArgument("need 2 <= threshold <= shares".into()));
        }
        let sharks = blahaj::Sharks(threshold);
        let mut secret = self.secret_bytes();
        let dealer = sharks.dealer(&secret);
        let out = dealer.take(shares as usize).map(|s| RecoveryShare(Vec::from(&s))).collect();
        secret.zeroize();
        Ok(out)
    }

    /// Rebuild an identity from friends' shares.
    pub fn recover_from_shares(threshold: u8, shares: &[RecoveryShare]) -> Result<Self> {
        let parsed: Vec<blahaj::Share> = shares
            .iter()
            .map(|s| blahaj::Share::try_from(s.0.as_slice()).map_err(|_| Error::BadRecoveryShare))
            .collect::<Result<_>>()?;
        let secret = blahaj::Sharks(threshold).recover(parsed.iter()).map_err(|_| Error::NotEnoughShares)?;
        let arr: [u8; 32] = secret.try_into().map_err(|_| Error::BadRecoveryShare)?;
        Ok(Identity::from_secret(arr))
    }
}

/// A device: its own key plus the certificate from the identity.
pub struct Device {
    pub key: Keypair,
    pub cert: DeviceCert,
}

impl Clone for Device {
    fn clone(&self) -> Self {
        Device { key: Keypair::from_secret(self.key.secret_bytes()), cert: self.cert.clone() }
    }
}

impl Device {
    pub fn new(identity: &Identity, name: &str) -> Self {
        let key = Keypair::generate();
        let cert = identity.certify_device(&key.public(), name);
        Device { key, cert }
    }

    pub fn from_parts(secret: [u8; 32], cert: DeviceCert) -> Result<Self> {
        let key = Keypair::from_secret(secret);
        if key.public() != cert.device {
            return Err(Error::BadCertificate);
        }
        cert.verify()?;
        Ok(Device { key, cert })
    }

    pub fn identity(&self) -> PublicKey {
        self.cert.identity
    }
}

/// The 12 words shown once at sign-up.
#[derive(Clone, PartialEq, Eq)]
pub struct RecoveryPhrase(pub String);

impl RecoveryPhrase {
    pub fn words(&self) -> Vec<&str> {
        self.0.split_whitespace().collect()
    }
}

impl std::fmt::Debug for RecoveryPhrase {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("RecoveryPhrase(<hidden>)")
    }
}

impl Drop for RecoveryPhrase {
    fn drop(&mut self) {
        self.0.zeroize();
    }
}

/// One friend's piece of a social-recovery split.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct RecoveryShare(pub Vec<u8>);
