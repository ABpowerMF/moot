//! # moot-core
//!
//! The shared heart of Moot: accounts as keys, communities as signed, hash-linked event
//! logs, role-based permissions, sync between replicas, and local storage.
//!
//! Every node and every client runs this same code, which is what lets a community live on
//! several independent nodes: none of them can forge an event, and any of them can be
//! checked against the others.

pub mod badge;
pub mod community;
pub mod event;
pub mod identity;
pub mod store;
pub mod sync;

pub use badge::{Badge, BadgeTier, SECURITY_ISSUERS};
pub use community::{Channel, ChannelKind, CommunityState, MessageView, Role, Roster, Visibility};
pub use event::{Event, EventBody, EventId, EventKind};
pub use identity::{Device, DeviceCert, Identity, Keypair, PublicKey, RecoveryPhrase, RecoveryShare, Sig};
pub use store::{Store, VaultKey, WRONG_VAULT_KEY};

/// Everything that can go wrong in the core.
#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum Error {
    #[error("invalid public key")]
    BadKey,
    #[error("signature does not verify")]
    BadSignature,
    #[error("device certificate is invalid")]
    BadCertificate,
    #[error("recovery phrase is not valid")]
    BadRecoveryPhrase,
    #[error("recovery share is malformed")]
    BadRecoveryShare,
    #[error("not enough recovery shares")]
    NotEnoughShares,
    #[error("event id does not match its contents")]
    BadEventId,
    #[error("event belongs to a different community")]
    WrongCommunity,
    #[error("event refers to parents we don't have yet")]
    MissingParents,
    #[error("event clock is not after its parents")]
    BadClock,
    #[error("not allowed: {0}")]
    NotAllowed(String),
    #[error("unknown {0}")]
    Unknown(String),
    #[error("invalid argument: {0}")]
    InvalidArgument(String),
    #[error("storage error: {0}")]
    Storage(String),
}

pub type Result<T> = std::result::Result<T, Error>;

pub fn now_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}
