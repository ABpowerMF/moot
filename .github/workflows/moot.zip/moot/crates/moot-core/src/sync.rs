//! Sync between replicas (two nodes, or a client and a node).
//!
//! The protocol is deliberately simple for the prototype:
//! 1. Each side sends the ids it has.
//! 2. The other side sends back every event the first is missing, oldest first.
//! 3. The receiver applies them, retrying events whose parents arrive later in the batch.
//!
//! A node that withholds events shows up as a gap: its heads are behind another node's.

use crate::community::CommunityState;
use crate::event::{Event, EventId};
use crate::{Error, Result};
use std::collections::HashSet;

/// Everything `state` has that a peer holding `their_ids` doesn't, in applied order.
pub fn missing_for(state: &CommunityState, their_ids: &HashSet<EventId>) -> Vec<Event> {
    state.events_in_order().filter(|e| !their_ids.contains(&e.id)).cloned().collect()
}

pub fn ids(state: &CommunityState) -> HashSet<EventId> {
    state.events_in_order().map(|e| e.id).collect()
}

/// Outcome of importing a batch.
#[derive(Debug, Default, PartialEq, Eq)]
pub struct ImportReport {
    pub applied: usize,
    pub already_had: usize,
    pub rejected: Vec<(EventId, Error)>,
    pub waiting_for_parents: usize,
}

/// Apply a batch of events from a peer. Bad events are rejected individually; the rest go in.
pub fn import(state: &mut CommunityState, mut batch: Vec<Event>) -> ImportReport {
    let mut report = ImportReport::default();
    batch.sort_by_key(|e| (e.body.lamport, e.id));
    loop {
        let mut progress = false;
        let mut still_waiting = Vec::new();
        for ev in batch.drain(..) {
            if state.contains(&ev.id) {
                report.already_had += 1;
                continue;
            }
            match state.apply(&ev) {
                Ok(()) => {
                    report.applied += 1;
                    progress = true;
                }
                Err(Error::MissingParents) => still_waiting.push(ev),
                Err(e) => report.rejected.push((ev.id, e)),
            }
        }
        batch = still_waiting;
        if batch.is_empty() || !progress {
            report.waiting_for_parents = batch.len();
            return report;
        }
    }
}

/// Two replicas agree when they hold the same set of events.
pub fn in_sync(a: &CommunityState, b: &CommunityState) -> bool {
    ids(a) == ids(b)
}

/// Compare what two nodes serve; returns ids one has that the other is not showing.
pub fn detect_withholding(a: &CommunityState, b: &CommunityState) -> (Vec<EventId>, Vec<EventId>) {
    let (ia, ib) = (ids(a), ids(b));
    let only_a = ia.difference(&ib).copied().collect();
    let only_b = ib.difference(&ia).copied().collect();
    (only_a, only_b)
}

/// Convenience: full two-way sync between two in-memory replicas.
pub fn sync_pair(a: &mut CommunityState, b: &mut CommunityState) -> Result<(ImportReport, ImportReport)> {
    if a.id != b.id {
        return Err(Error::WrongCommunity);
    }
    let to_b = missing_for(a, &ids(b));
    let to_a = missing_for(b, &ids(a));
    let rb = import(b, to_b);
    let ra = import(a, to_a);
    Ok((ra, rb))
}
