//! Local storage in SQLite, encrypted at rest.
//!
//! Every secret and every piece of content is sealed with XChaCha20-Poly1305 under a
//! 32-byte [`VaultKey`] before it touches the disk: the account keys, every event (messages,
//! names, members) and the addresses of peers you sync with. The vault key itself never
//! lives in the database — the desktop app keeps it in the OS keychain (Windows Credential
//! Manager, macOS Keychain, Secret Service on Linux); a node keeps it in a key file.
//!
//! Each sealed value is bound to its row (for events, to the event id) as associated data,
//! so rows can't be swapped or replayed into another place without detection.
//!
//! What is **not** hidden: the table structure, community and event ids (random-looking
//! hashes), event counts and Lamport clocks. Those reveal how active you are, not what
//! anyone said.

use crate::community::CommunityState;
use crate::event::{Event, EventId, EventKind};
use crate::identity::{Device, DeviceCert, Identity};
use crate::{Error, Result};
use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::{XChaCha20Poly1305, XNonce};
use rand::RngCore;
use rusqlite::{params, Connection, OptionalExtension};
use std::path::Path;
use zeroize::{Zeroize, ZeroizeOnDrop};

/// Schema version written to `PRAGMA user_version`. 0 = the unencrypted v0.1.0 prototype.
const SCHEMA_VERSION: i64 = 2;
const CHECK_PLAINTEXT: &[u8] = b"moot vault check v1";

/// The key that unlocks a store. Keep it outside the database (keychain or key file).
#[derive(Clone, Zeroize, ZeroizeOnDrop)]
pub struct VaultKey([u8; 32]);

impl VaultKey {
    pub fn generate() -> Self {
        let mut k = [0u8; 32];
        rand::rngs::OsRng.fill_bytes(&mut k);
        VaultKey(k)
    }

    pub fn from_bytes(bytes: [u8; 32]) -> Self {
        VaultKey(bytes)
    }

    pub fn to_hex(&self) -> String {
        hex::encode(self.0)
    }

    pub fn from_hex(s: &str) -> Result<Self> {
        let mut v = hex::decode(s.trim()).map_err(|_| Error::Storage("vault key is not valid hex".into()))?;
        let arr: [u8; 32] = v.as_slice().try_into().map_err(|_| Error::Storage("vault key has the wrong length".into()))?;
        v.zeroize();
        Ok(VaultKey(arr))
    }

    fn cipher(&self) -> XChaCha20Poly1305 {
        XChaCha20Poly1305::new((&self.0).into())
    }

    /// nonce (24 bytes) || ciphertext+tag
    fn seal(&self, aad: &[u8], plaintext: &[u8]) -> Vec<u8> {
        let mut nonce = [0u8; 24];
        rand::rngs::OsRng.fill_bytes(&mut nonce);
        let ct = self
            .cipher()
            .encrypt(XNonce::from_slice(&nonce), Payload { msg: plaintext, aad })
            .expect("XChaCha20-Poly1305 encryption cannot fail for in-memory buffers");
        let mut out = Vec::with_capacity(24 + ct.len());
        out.extend_from_slice(&nonce);
        out.extend_from_slice(&ct);
        out
    }

    fn open(&self, aad: &[u8], sealed: &[u8]) -> Result<Vec<u8>> {
        if sealed.len() < 24 + 16 {
            return Err(Error::Storage("sealed value is truncated".into()));
        }
        let (nonce, ct) = sealed.split_at(24);
        self.cipher()
            .decrypt(XNonce::from_slice(nonce), Payload { msg: ct, aad })
            .map_err(|_| Error::Storage("stored data failed its integrity check (wrong key or tampered file)".into()))
    }

    /// Keyed hash, for de-duplicating sealed values without revealing them.
    fn tag(&self, data: &[u8]) -> String {
        hex::encode(blake3::keyed_hash(&self.0, data).as_bytes())
    }
}

/// The error the app shows when the vault key doesn't match the database.
pub const WRONG_VAULT_KEY: &str = "this database is locked with a different key";

pub struct Store {
    conn: Connection,
    key: VaultKey,
}

fn db(e: rusqlite::Error) -> Error {
    Error::Storage(e.to_string())
}

fn event_aad(id: &EventId) -> Vec<u8> {
    let mut a = b"moot/store/event:".to_vec();
    a.extend_from_slice(id.to_hex().as_bytes());
    a
}

impl Store {
    /// Open (or create) an encrypted store. Fails with [`WRONG_VAULT_KEY`] if `key` isn't the
    /// key the database was created with. Unencrypted prototype databases are migrated.
    pub fn open(path: impl AsRef<Path>, key: VaultKey) -> Result<Self> {
        let conn = Connection::open(path).map_err(db)?;
        Self::init(conn, key)
    }

    /// A throwaway store for tests, with a random key.
    pub fn in_memory() -> Result<Self> {
        Self::init(Connection::open_in_memory().map_err(db)?, VaultKey::generate())
    }

    fn init(conn: Connection, key: VaultKey) -> Result<Self> {
        conn.execute_batch(
            "PRAGMA journal_mode=WAL;
             PRAGMA secure_delete=ON;",
        )
        .map_err(db)?;
        let version: i64 = conn.query_row("PRAGMA user_version", [], |r| r.get(0)).map_err(db)?;
        let has_old: bool = conn
            .query_row("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='events'", [], |r| r.get::<_, i64>(0))
            .map_err(db)?
            > 0;
        let store = Store { conn, key };
        if version == 0 && has_old {
            store.migrate_from_plaintext()?;
        } else if version == 0 {
            store.create_schema()?;
        } else if version != SCHEMA_VERSION {
            return Err(Error::Storage(format!("database version {version} is newer than this app understands")));
        }
        store.check_key()?;
        Ok(store)
    }

    fn create_schema(&self) -> Result<()> {
        self.conn
            .execute_batch(&format!(
                "BEGIN;
                 CREATE TABLE meta (k TEXT PRIMARY KEY, v BLOB NOT NULL);
                 CREATE TABLE account (id INTEGER PRIMARY KEY CHECK (id = 1), sealed BLOB NOT NULL);
                 CREATE TABLE events (
                   id TEXT PRIMARY KEY,
                   community TEXT NOT NULL,
                   seq INTEGER NOT NULL,
                   sealed BLOB NOT NULL
                 );
                 CREATE INDEX events_by_community ON events (community, seq);
                 CREATE TABLE remotes (community TEXT NOT NULL, tag TEXT NOT NULL, sealed BLOB NOT NULL, PRIMARY KEY (community, tag));
                 CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT NOT NULL);
                 PRAGMA user_version = {SCHEMA_VERSION};
                 COMMIT;"
            ))
            .map_err(db)?;
        let check = self.key.seal(b"moot/store/check", CHECK_PLAINTEXT);
        self.conn.execute("INSERT INTO meta (k, v) VALUES ('check', ?1)", params![check]).map_err(db)?;
        Ok(())
    }

    fn check_key(&self) -> Result<()> {
        let sealed: Vec<u8> = self.conn.query_row("SELECT v FROM meta WHERE k = 'check'", [], |r| r.get(0)).map_err(db)?;
        match self.key.open(b"moot/store/check", &sealed) {
            Ok(p) if p == CHECK_PLAINTEXT => Ok(()),
            _ => Err(Error::Storage(WRONG_VAULT_KEY.into())),
        }
    }

    /// Re-write a v0.1.0 (unencrypted) database encrypted, then scrub the old plaintext.
    fn migrate_from_plaintext(&self) -> Result<()> {
        let c = &self.conn;
        c.execute_batch(
            "ALTER TABLE events RENAME TO old_events;
             ALTER TABLE account RENAME TO old_account;
             DROP INDEX IF EXISTS events_by_community;",
        )
        .map_err(db)?;
        let had_remotes = c
            .query_row("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='remotes'", [], |r| r.get::<_, i64>(0))
            .map_err(db)?
            > 0;
        if had_remotes {
            c.execute_batch("ALTER TABLE remotes RENAME TO old_remotes;").map_err(db)?;
        }
        self.create_schema()?;

        let account: Option<(Vec<u8>, Vec<u8>, String, String)> = c
            .query_row("SELECT identity_secret, device_secret, device_cert, display_name FROM old_account WHERE id = 1", [], |r| {
                Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?))
            })
            .optional()
            .map_err(db)?;
        if let Some((mut isec, mut dsec, cert, name)) = account {
            let isec_a: [u8; 32] = isec.as_slice().try_into().map_err(|_| Error::Storage("identity secret".into()))?;
            let dsec_a: [u8; 32] = dsec.as_slice().try_into().map_err(|_| Error::Storage("device secret".into()))?;
            isec.zeroize();
            dsec.zeroize();
            let cert: DeviceCert = serde_json::from_str(&cert).map_err(|e| Error::Storage(e.to_string()))?;
            let identity = Identity::from_secret(isec_a);
            let device = Device::from_parts(dsec_a, cert)?;
            self.save_account(&identity, &device, &name)?;
        }

        let mut rows: Vec<(String, Vec<u8>)> = Vec::new();
        {
            let mut stmt = c.prepare("SELECT community, body FROM old_events ORDER BY community, seq").map_err(db)?;
            let it = stmt.query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, Vec<u8>>(1)?))).map_err(db)?;
            for r in it {
                rows.push(r.map_err(db)?);
            }
        }
        for (community, body) in rows {
            let ev = Event::from_bytes(&body)?;
            self.save_event(&EventId::from_hex(&community)?, &ev)?;
        }
        if had_remotes {
            let mut out: Vec<(String, String)> = Vec::new();
            {
                let mut stmt = c.prepare("SELECT community, addr FROM old_remotes").map_err(db)?;
                let it = stmt.query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?))).map_err(db)?;
                for r in it {
                    out.push(r.map_err(db)?);
                }
            }
            for (community, addr) in out {
                self.save_remote(&EventId::from_hex(&community)?, &addr)?;
            }
        }
        // secure_delete zeroes the freed pages; VACUUM and a WAL checkpoint make sure no old
        // plaintext is left anywhere in the file.
        c.execute_batch("DROP TABLE old_events; DROP TABLE old_account; DROP TABLE IF EXISTS old_remotes;").map_err(db)?;
        c.execute_batch("VACUUM; PRAGMA wal_checkpoint(TRUNCATE);").map_err(db)?;
        Ok(())
    }

    // ---------- account ----------

    /// Save the local account (identity + this device), sealed.
    pub fn save_account(&self, identity: &Identity, device: &Device, display_name: &str) -> Result<()> {
        #[derive(serde::Serialize)]
        struct Plain<'a> {
            identity_secret: [u8; 32],
            device_secret: [u8; 32],
            device_cert: &'a DeviceCert,
            display_name: &'a str,
        }
        let mut bytes = postcard::to_allocvec(&Plain {
            identity_secret: identity.secret_bytes(),
            device_secret: device.key.secret_bytes(),
            device_cert: &device.cert,
            display_name,
        })
        .map_err(|e| Error::Storage(e.to_string()))?;
        let sealed = self.key.seal(b"moot/store/account", &bytes);
        bytes.zeroize();
        self.conn.execute("INSERT OR REPLACE INTO account (id, sealed) VALUES (1, ?1)", params![sealed]).map_err(db)?;
        Ok(())
    }

    /// Load the local account, if one exists.
    pub fn load_account(&self) -> Result<Option<(Identity, Device, String)>> {
        #[derive(serde::Deserialize)]
        struct Plain {
            identity_secret: [u8; 32],
            device_secret: [u8; 32],
            device_cert: DeviceCert,
            display_name: String,
        }
        let sealed: Option<Vec<u8>> = self.conn.query_row("SELECT sealed FROM account WHERE id = 1", [], |r| r.get(0)).optional().map_err(db)?;
        let Some(sealed) = sealed else { return Ok(None) };
        let mut bytes = self.key.open(b"moot/store/account", &sealed)?;
        let plain: std::result::Result<Plain, _> = postcard::from_bytes(&bytes);
        bytes.zeroize();
        let mut plain = plain.map_err(|_| Error::Storage("account record is damaged".into()))?;
        let identity = Identity::from_secret(plain.identity_secret);
        let device = Device::from_parts(plain.device_secret, plain.device_cert.clone())?;
        plain.identity_secret.zeroize();
        plain.device_secret.zeroize();
        if device.identity() != identity.public() {
            return Err(Error::BadCertificate);
        }
        Ok(Some((identity, device, std::mem::take(&mut plain.display_name))))
    }

    pub fn set_display_name(&self, name: &str) -> Result<()> {
        let (identity, device, _) = self.load_account()?.ok_or_else(|| Error::Unknown("account".into()))?;
        self.save_account(&identity, &device, name)
    }

    // ---------- events ----------

    /// Store an event that has already been applied to a `CommunityState`.
    pub fn save_event(&self, community: &EventId, ev: &Event) -> Result<()> {
        let exists: bool = self
            .conn
            .query_row("SELECT COUNT(*) FROM events WHERE id = ?1", params![ev.id.to_hex()], |r| r.get::<_, i64>(0))
            .map_err(db)?
            > 0;
        if exists {
            return Ok(());
        }
        let seq: i64 = self
            .conn
            .query_row("SELECT COALESCE(MAX(seq), -1) + 1 FROM events WHERE community = ?1", params![community.to_hex()], |r| r.get(0))
            .map_err(db)?;
        let sealed = self.key.seal(&event_aad(&ev.id), &ev.to_bytes());
        self.conn
            .execute(
                "INSERT INTO events (id, community, seq, sealed) VALUES (?1, ?2, ?3, ?4)",
                params![ev.id.to_hex(), community.to_hex(), seq, sealed],
            )
            .map_err(db)?;
        Ok(())
    }

    pub fn save_events(&self, community: &EventId, evs: &[Event]) -> Result<()> {
        let tx = self.conn.unchecked_transaction().map_err(db)?;
        for e in evs {
            self.save_event(community, e)?;
        }
        tx.commit().map_err(db)?;
        Ok(())
    }

    fn load_event(&self, id_hex: &str, sealed: &[u8]) -> Result<Event> {
        let id = EventId::from_hex(id_hex)?;
        let ev = Event::from_bytes(&self.key.open(&event_aad(&id), sealed)?)?;
        if ev.id != id {
            return Err(Error::BadEventId);
        }
        Ok(ev)
    }

    /// Rebuild a community from disk, decrypting and re-verifying every event.
    pub fn load_community(&self, community: &EventId) -> Result<CommunityState> {
        let mut stmt = self.conn.prepare("SELECT id, sealed FROM events WHERE community = ?1 ORDER BY seq").map_err(db)?;
        let rows = stmt.query_map(params![community.to_hex()], |r| Ok((r.get::<_, String>(0)?, r.get::<_, Vec<u8>>(1)?))).map_err(db)?;
        let mut events = Vec::new();
        for r in rows {
            let (id, sealed) = r.map_err(db)?;
            events.push(self.load_event(&id, &sealed)?);
        }
        let genesis = events.first().ok_or_else(|| Error::Unknown("community".into()))?;
        let mut state = CommunityState::from_genesis(genesis)?;
        for e in &events[1..] {
            state.apply(e)?;
        }
        Ok(state)
    }

    /// Ids and names of every community stored locally.
    pub fn list_communities(&self) -> Result<Vec<(EventId, String)>> {
        let mut stmt = self.conn.prepare("SELECT id, sealed FROM events WHERE community = id ORDER BY rowid").map_err(db)?;
        let rows = stmt.query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, Vec<u8>>(1)?))).map_err(db)?;
        let mut out = Vec::new();
        for r in rows {
            let (id, sealed) = r.map_err(db)?;
            let ev = self.load_event(&id, &sealed)?;
            if let EventKind::Genesis { name, .. } = &ev.body.kind {
                out.push((ev.id, name.clone()));
            }
        }
        Ok(out)
    }

    // ---------- remotes ----------

    /// Remember a peer (an opaque address string from the network layer) that hosts a community.
    pub fn save_remote(&self, community: &EventId, addr: &str) -> Result<()> {
        let tag = self.key.tag(addr.as_bytes());
        let sealed = self.key.seal(format!("moot/store/remote:{}", community.to_hex()).as_bytes(), addr.as_bytes());
        self.conn
            .execute("INSERT OR IGNORE INTO remotes (community, tag, sealed) VALUES (?1, ?2, ?3)", params![community.to_hex(), tag, sealed])
            .map_err(db)?;
        Ok(())
    }

    /// Every remembered (community, peer address) pair.
    pub fn load_remotes(&self) -> Result<Vec<(EventId, String)>> {
        let mut stmt = self.conn.prepare("SELECT community, sealed FROM remotes").map_err(db)?;
        let rows = stmt.query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, Vec<u8>>(1)?))).map_err(db)?;
        let mut out = Vec::new();
        for r in rows {
            let (c, sealed) = r.map_err(db)?;
            let addr = self.key.open(format!("moot/store/remote:{c}").as_bytes(), &sealed)?;
            out.push((EventId::from_hex(&c)?, String::from_utf8(addr).map_err(|_| Error::Storage("remote address".into()))?));
        }
        Ok(out)
    }

    /// Forget every remembered peer address (used after a privacy migration).
    pub fn clear_remotes(&self) -> Result<()> {
        self.conn.execute("DELETE FROM remotes", []).map_err(db)?;
        Ok(())
    }

    // ---------- sealed secrets (e.g. the network key) ----------

    /// Store a named secret, sealed with the vault key.
    pub fn put_secret(&self, name: &str, value: &[u8]) -> Result<()> {
        let sealed = self.key.seal(format!("moot/store/secret:{name}").as_bytes(), value);
        self.conn.execute("INSERT OR REPLACE INTO meta (k, v) VALUES (?1, ?2)", params![format!("secret:{name}"), sealed]).map_err(db)?;
        Ok(())
    }

    pub fn get_secret(&self, name: &str) -> Result<Option<Vec<u8>>> {
        let sealed: Option<Vec<u8>> =
            self.conn.query_row("SELECT v FROM meta WHERE k = ?1", params![format!("secret:{name}")], |r| r.get(0)).optional().map_err(db)?;
        sealed.map(|s| self.key.open(format!("moot/store/secret:{name}").as_bytes(), &s)).transpose()
    }

    /// A random 32-byte secret that is created once and then kept (sealed).
    pub fn persistent_secret(&self, name: &str) -> Result<[u8; 32]> {
        if let Some(mut v) = self.get_secret(name)? {
            let arr: [u8; 32] = v.as_slice().try_into().map_err(|_| Error::Storage(format!("{name} has the wrong length")))?;
            v.zeroize();
            return Ok(arr);
        }
        let mut k = [0u8; 32];
        rand::rngs::OsRng.fill_bytes(&mut k);
        self.put_secret(name, &k)?;
        Ok(k)
    }

    // ---------- settings (non-secret flags, e.g. "hide_ip") ----------

    pub fn setting(&self, key: &str) -> Result<Option<String>> {
        self.conn.query_row("SELECT v FROM settings WHERE k = ?1", params![key], |r| r.get(0)).optional().map_err(db)
    }

    pub fn set_setting(&self, key: &str, value: &str) -> Result<()> {
        self.conn.execute("INSERT OR REPLACE INTO settings (k, v) VALUES (?1, ?2)", params![key, value]).map_err(db)?;
        Ok(())
    }
}
