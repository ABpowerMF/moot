//! A community's state, derived from its signed events.
//!
//! `apply` is the gatekeeper every node and client runs. Two rules make every replica agree,
//! whatever order events arrive in:
//!
//! 1. **Admission** — an event joins the log only if it is well-formed, correctly signed,
//!    linked to events we already have, and allowed by the author's role *in the history
//!    it was written on* (its ancestors). That depends only on the event and its ancestors,
//!    which are fixed by their hashes, so every replica admits exactly the same events.
//! 2. **Effect** — the community's state (members, roles, bans, messages…) is the result of
//!    applying all admitted events in one canonical order, `(lamport, id)`, re-checking each
//!    against the state so far. An event that was fine where it was written but loses to a
//!    concurrent change (say, a message racing a ban) stays in the log with no effect.
//!
//! So two replicas holding the same set of events always compute the same state.

use crate::event::{Event, EventId, EventKind};
use crate::identity::{Device, PublicKey};
use crate::{Error, Result};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub enum Role {
    Member = 0,
    Moderator = 1,
    Admin = 2,
    Owner = 3,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum Visibility {
    /// Listed in Discover; anyone can join.
    Public,
    /// Not listed; anyone with an invite can join.
    InviteOnly,
    /// Hidden; invite plus moderator approval (approval = the invite itself here).
    Private,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChannelKind {
    Text,
    Voice,
    Announcement,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Channel {
    pub id: String,
    pub name: String,
    pub kind: ChannelKind,
    pub private: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct MessageView {
    pub id: EventId,
    pub channel: String,
    pub author: PublicKey,
    pub author_device: String,
    pub text: String,
    pub timestamp_ms: u64,
    pub reply_to: Option<EventId>,
    pub edited: bool,
    pub deleted: bool,
}

/// Everything derived from the log: who's in, who can do what, what was said.
#[derive(Clone, Debug)]
pub struct Roster {
    pub name: String,
    pub description: String,
    pub visibility: Visibility,
    pub owner: PublicKey,
    pub backup_owner: Option<PublicKey>,
    pub roles: HashMap<PublicKey, Role>,
    pub members: BTreeSet<PublicKey>,
    pub invited: HashSet<PublicKey>,
    pub banned: HashSet<PublicKey>,
    pub channels: BTreeMap<String, Channel>,
    pub nodes: BTreeMap<PublicKey, String>,
    messages: Vec<MessageView>,
    message_index: HashMap<EventId, usize>,
}

#[derive(Clone, Debug)]
pub struct CommunityState {
    pub id: EventId,
    roster: Roster,
    events: HashMap<EventId, Event>,
    /// Canonical order: (lamport, id). Lamport clocks grow along every edge, so this is
    /// also a valid causal order.
    order: Vec<EventId>,
    heads: BTreeSet<EventId>,
    max_lamport: u64,
    /// Admitted events that have no effect in canonical order.
    ineffective: HashSet<EventId>,
}

impl std::ops::Deref for CommunityState {
    type Target = Roster;
    fn deref(&self) -> &Roster {
        &self.roster
    }
}

fn key(ev: &Event) -> (u64, EventId) {
    (ev.body.lamport, ev.id)
}

impl CommunityState {
    /// Create a new community: signs the genesis event and a `#general` channel.
    pub fn create(owner_device: &Device, name: &str, description: &str, visibility: Visibility) -> Result<(Self, Vec<Event>)> {
        if name.trim().is_empty() || name.len() > 64 {
            return Err(Error::InvalidArgument("community name must be 1-64 characters".into()));
        }
        let genesis = Event::new(
            owner_device,
            EventId::ZERO,
            vec![],
            1,
            EventKind::Genesis { name: name.trim().into(), description: description.into(), visibility },
        );
        let mut state = CommunityState::from_genesis(&genesis)?;
        let general = state.author(
            owner_device,
            EventKind::ChannelCreate { channel: "general".into(), name: "general".into(), kind: ChannelKind::Text, private: false },
        )?;
        Ok((state, vec![genesis, general]))
    }

    /// Start a state from a genesis event received from someone else.
    pub fn from_genesis(genesis: &Event) -> Result<Self> {
        genesis.verify_self()?;
        let (name, description, visibility) = match &genesis.body.kind {
            EventKind::Genesis { name, description, visibility } => (name.clone(), description.clone(), *visibility),
            _ => return Err(Error::InvalidArgument("first event must be a genesis".into())),
        };
        if genesis.body.community != EventId::ZERO || !genesis.body.prev.is_empty() {
            return Err(Error::InvalidArgument("genesis must have no parents".into()));
        }
        let owner = genesis.author_identity();
        let mut s = CommunityState {
            id: genesis.id,
            roster: Roster {
                name,
                description,
                visibility,
                owner,
                backup_owner: None,
                roles: HashMap::from([(owner, Role::Owner)]),
                members: BTreeSet::from([owner]),
                invited: HashSet::new(),
                banned: HashSet::new(),
                channels: BTreeMap::new(),
                nodes: BTreeMap::new(),
                messages: vec![],
                message_index: HashMap::new(),
            },
            events: HashMap::new(),
            order: vec![],
            heads: BTreeSet::new(),
            max_lamport: genesis.body.lamport,
            ineffective: HashSet::new(),
        };
        s.events.insert(genesis.id, genesis.clone());
        s.order.push(genesis.id);
        s.heads.insert(genesis.id);
        Ok(s)
    }

    /// Write a new event as `device`, apply it locally, and return it for sending.
    pub fn author(&mut self, device: &Device, kind: EventKind) -> Result<Event> {
        let prev: Vec<EventId> = self.heads.iter().copied().collect();
        let ev = Event::new(device, self.id, prev, self.max_lamport + 1, kind);
        self.apply(&ev)?;
        Ok(ev)
    }

    pub fn contains(&self, id: &EventId) -> bool {
        self.events.contains_key(id)
    }

    pub fn event(&self, id: &EventId) -> Option<&Event> {
        self.events.get(id)
    }

    /// Events in canonical (causal) order.
    pub fn events_in_order(&self) -> impl Iterator<Item = &Event> {
        self.order.iter().filter_map(|id| self.events.get(id))
    }

    pub fn heads(&self) -> Vec<EventId> {
        self.heads.iter().copied().collect()
    }

    pub fn len(&self) -> usize {
        self.order.len()
    }

    pub fn is_empty(&self) -> bool {
        self.order.is_empty()
    }

    /// Whether an admitted event actually took effect (false if it lost a race, e.g. a
    /// message from someone banned concurrently).
    pub fn is_effective(&self, id: &EventId) -> bool {
        self.events.contains_key(id) && !self.ineffective.contains(id)
    }

    /// Validate and apply one event. Applying an event we already have is a no-op.
    pub fn apply(&mut self, ev: &Event) -> Result<()> {
        if self.events.contains_key(&ev.id) {
            return Ok(());
        }
        ev.verify_self()?;
        if ev.body.community != self.id {
            return Err(Error::WrongCommunity);
        }
        if ev.body.prev.is_empty() {
            return Err(Error::InvalidArgument("only the genesis may have no parents".into()));
        }
        if ev.body.prev.len() > 64 {
            return Err(Error::InvalidArgument("too many parents".into()));
        }
        let mut parent_max = 0;
        for p in &ev.body.prev {
            match self.events.get(p) {
                Some(pe) => parent_max = parent_max.max(pe.body.lamport),
                None => return Err(Error::MissingParents),
            }
        }
        if ev.body.lamport <= parent_max {
            return Err(Error::BadClock);
        }
        let author = ev.author_identity();

        // Admission: allowed in the history the author saw. When the event builds on all
        // current heads (the normal case) that history is everything we have.
        let parents: BTreeSet<EventId> = ev.body.prev.iter().copied().collect();
        if parents == self.heads {
            self.roster.clone().step(ev, &author)?;
        } else {
            let ancestors = self.ancestors(&ev.body.prev);
            let (mut at, _) = self.fold(self.order.iter().filter(|id| ancestors.contains(id)));
            at.step(ev, &author)?;
        }

        for p in &ev.body.prev {
            self.heads.remove(p);
        }
        self.heads.insert(ev.id);
        self.max_lamport = self.max_lamport.max(ev.body.lamport);
        self.events.insert(ev.id, ev.clone());

        // Effect, in canonical order.
        let last = self.order.last().and_then(|id| self.events.get(id)).map(key);
        if last.map_or(true, |l| key(ev) > l) {
            self.order.push(ev.id);
            if self.roster.step(ev, &author).is_err() {
                self.ineffective.insert(ev.id);
            }
        } else {
            let pos = self.order.partition_point(|id| key(&self.events[id]) < key(ev));
            self.order.insert(pos, ev.id);
            let (roster, ineffective) = self.fold(self.order.iter());
            self.roster = roster;
            self.ineffective = ineffective;
        }
        Ok(())
    }

    /// Every ancestor of `from` (inclusive).
    fn ancestors(&self, from: &[EventId]) -> HashSet<EventId> {
        let mut seen = HashSet::new();
        let mut stack: Vec<EventId> = from.to_vec();
        while let Some(id) = stack.pop() {
            if seen.insert(id) {
                if let Some(e) = self.events.get(&id) {
                    stack.extend(e.body.prev.iter().copied());
                }
            }
        }
        seen
    }

    /// Replay events (genesis first, canonical order) into a fresh roster.
    fn fold<'a>(&self, ids: impl Iterator<Item = &'a EventId>) -> (Roster, HashSet<EventId>) {
        let mut ids = ids.peekable();
        let genesis = ids.next().and_then(|id| self.events.get(id)).expect("the genesis comes first");
        let mut roster = CommunityState::from_genesis(genesis).expect("stored genesis is valid").roster;
        let mut ineffective = HashSet::new();
        for id in ids {
            let e = &self.events[id];
            if roster.step(e, &e.author_identity()).is_err() {
                ineffective.insert(*id);
            }
        }
        (roster, ineffective)
    }
}

impl Roster {
    pub fn role_of(&self, who: &PublicKey) -> Option<Role> {
        if self.banned.contains(who) || !self.members.contains(who) {
            return None;
        }
        Some(*self.roles.get(who).unwrap_or(&Role::Member))
    }

    fn require(&self, who: &PublicKey, min: Role, what: &str) -> Result<Role> {
        match self.role_of(who) {
            Some(r) if r >= min => Ok(r),
            Some(_) => Err(Error::NotAllowed(format!("{what} needs {min:?} or higher"))),
            None => Err(Error::NotAllowed(format!("{what}: not a member"))),
        }
    }

    pub fn messages(&self, channel: &str) -> Vec<&MessageView> {
        self.messages.iter().filter(|m| m.channel == channel && !m.deleted).collect()
    }

    /// Check one event against this roster and, if allowed, apply its effect.
    fn step(&mut self, ev: &Event, author: &PublicKey) -> Result<()> {
        match &ev.body.kind {
            EventKind::Genesis { .. } => Err(Error::InvalidArgument("a community has one genesis".into())),
            EventKind::ChannelCreate { channel, name, kind, private } => {
                self.require(author, Role::Admin, "creating channels")?;
                if channel.is_empty() || channel.len() > 48 || self.channels.contains_key(channel) {
                    return Err(Error::InvalidArgument("channel id must be new and 1-48 characters".into()));
                }
                self.channels.insert(channel.clone(), Channel { id: channel.clone(), name: name.clone(), kind: *kind, private: *private });
                Ok(())
            }
            EventKind::Invite { member } => {
                self.require(author, Role::Moderator, "inviting")?;
                self.invited.insert(*member);
                Ok(())
            }
            EventKind::Join => {
                if self.banned.contains(author) {
                    return Err(Error::NotAllowed("banned".into()));
                }
                let ok = self.visibility == Visibility::Public || self.invited.contains(author);
                if !ok {
                    return Err(Error::NotAllowed("joining needs an invite".into()));
                }
                self.members.insert(*author);
                Ok(())
            }
            EventKind::Leave => {
                if *author == self.owner {
                    return Err(Error::NotAllowed("the owner must transfer ownership before leaving".into()));
                }
                self.members.remove(author);
                self.roles.remove(author);
                Ok(())
            }
            EventKind::RoleGrant { member, role } => {
                let mine = self.require(author, Role::Admin, "changing roles")?;
                if *role == Role::Owner {
                    return Err(Error::NotAllowed("ownership moves only with a transfer".into()));
                }
                if !self.members.contains(member) {
                    return Err(Error::NotAllowed("roles can only be given to members".into()));
                }
                let theirs = *self.roles.get(member).unwrap_or(&Role::Member);
                if theirs >= mine || *role >= mine {
                    return Err(Error::NotAllowed("can only manage roles below your own".into()));
                }
                self.roles.insert(*member, *role);
                Ok(())
            }
            EventKind::Message { channel, text, reply_to } => {
                let role = self.require(author, Role::Member, "posting")?;
                let ch = self.channels.get(channel).ok_or_else(|| Error::Unknown(format!("channel {channel}")))?;
                if ch.kind == ChannelKind::Announcement && role < Role::Admin {
                    return Err(Error::NotAllowed("only admins post announcements".into()));
                }
                if ch.kind == ChannelKind::Voice {
                    return Err(Error::InvalidArgument("voice channels have no text log".into()));
                }
                if text.trim().is_empty() || text.len() > 4000 {
                    return Err(Error::InvalidArgument("messages must be 1-4000 characters".into()));
                }
                self.message_index.insert(ev.id, self.messages.len());
                self.messages.push(MessageView {
                    id: ev.id,
                    channel: channel.clone(),
                    author: *author,
                    author_device: ev.body.author.device_name.clone(),
                    text: text.clone(),
                    timestamp_ms: ev.body.timestamp_ms,
                    reply_to: *reply_to,
                    edited: false,
                    deleted: false,
                });
                Ok(())
            }
            EventKind::Edit { target, text } => {
                self.require(author, Role::Member, "editing")?;
                let idx = *self.message_index.get(target).ok_or_else(|| Error::Unknown("message".into()))?;
                if self.messages[idx].author != *author {
                    return Err(Error::NotAllowed("only the author can edit a message".into()));
                }
                if text.trim().is_empty() || text.len() > 4000 {
                    return Err(Error::InvalidArgument("messages must be 1-4000 characters".into()));
                }
                let m = &mut self.messages[idx];
                m.text = text.clone();
                m.edited = true;
                Ok(())
            }
            EventKind::Delete { target } => {
                let idx = *self.message_index.get(target).ok_or_else(|| Error::Unknown("message".into()))?;
                if self.messages[idx].author != *author {
                    self.require(author, Role::Moderator, "deleting others' messages")?;
                } else {
                    self.require(author, Role::Member, "deleting")?;
                }
                self.messages[idx].deleted = true;
                Ok(())
            }
            EventKind::Ban { member, .. } => {
                let mine = self.require(author, Role::Moderator, "banning")?;
                let theirs = *self.roles.get(member).unwrap_or(&Role::Member);
                if *member == self.owner || theirs >= mine {
                    return Err(Error::NotAllowed("can only ban members below your own role".into()));
                }
                self.banned.insert(*member);
                self.members.remove(member);
                self.roles.remove(member);
                Ok(())
            }
            EventKind::Unban { member } => {
                self.require(author, Role::Moderator, "unbanning")?;
                self.banned.remove(member);
                Ok(())
            }
            EventKind::NodeCertify { node, name } => {
                self.require(author, Role::Admin, "approving nodes")?;
                self.nodes.insert(*node, name.clone());
                Ok(())
            }
            EventKind::NodeRevoke { node } => {
                self.require(author, Role::Admin, "revoking nodes")?;
                self.nodes.remove(node);
                Ok(())
            }
            EventKind::SetBackupOwner { backup } => {
                self.require(author, Role::Owner, "choosing a backup owner")?;
                if !self.members.contains(backup) {
                    return Err(Error::NotAllowed("the backup owner must be a member".into()));
                }
                self.backup_owner = Some(*backup);
                Ok(())
            }
            EventKind::OwnershipTransfer { to } => {
                let by_owner = *author == self.owner;
                let by_backup = self.backup_owner == Some(*author) && *to == *author;
                if !(by_owner || by_backup) {
                    return Err(Error::NotAllowed("only the owner, or the backup owner claiming it, can transfer ownership".into()));
                }
                if !self.members.contains(to) || self.banned.contains(to) {
                    return Err(Error::NotAllowed("the new owner must be a member".into()));
                }
                let old = self.owner;
                self.roles.insert(old, Role::Admin);
                self.roles.insert(*to, Role::Owner);
                self.owner = *to;
                if self.backup_owner == Some(*to) {
                    self.backup_owner = None;
                }
                Ok(())
            }
        }
    }
}
