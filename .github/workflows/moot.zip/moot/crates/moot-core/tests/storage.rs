//! Encryption at rest: nothing readable may reach the disk.

use moot_core::*;
use std::path::PathBuf;

fn person(name: &str) -> (Identity, Device) {
    let (id, _) = Identity::create();
    let dev = Device::new(&id, name);
    (id, dev)
}

fn temp_db(tag: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!("moot-test-{tag}-{}.db", VaultKey::generate().to_hex()));
    p
}

/// Every byte of the database and its side files (WAL, shared memory).
fn raw_bytes(path: &PathBuf) -> Vec<u8> {
    let mut all = Vec::new();
    for suffix in ["", "-wal", "-shm"] {
        let mut f = path.clone().into_os_string();
        f.push(suffix);
        if let Ok(b) = std::fs::read(&f) {
            all.extend(b);
        }
    }
    all
}

fn contains(hay: &[u8], needle: &[u8]) -> bool {
    hay.windows(needle.len()).any(|w| w == needle)
}

fn cleanup(path: &PathBuf) {
    for suffix in ["", "-wal", "-shm"] {
        let mut f = path.clone().into_os_string();
        f.push(suffix);
        let _ = std::fs::remove_file(f);
    }
}

const SECRET_TEXT: &str = "meet at the old lighthouse at nine";

#[test]
fn nothing_readable_reaches_the_disk() {
    let path = temp_db("plain");
    let key = VaultKey::generate();
    let (id, dev) = person("Leo's desktop");
    let identity_secret = id.secret_bytes();
    let device_secret = dev.key.secret_bytes();
    {
        let store = Store::open(&path, key.clone()).unwrap();
        store.save_account(&id, &dev, "Leo Carvalho").unwrap();
        let (mut c, mut evs) = CommunityState::create(&dev, "Lighthouse Keepers", "secret club", Visibility::Private).unwrap();
        evs.push(c.author(&dev, EventKind::Message { channel: "general".into(), text: SECRET_TEXT.into(), reply_to: None }).unwrap());
        store.save_events(&c.id, &evs).unwrap();
        store.save_remote(&c.id, "{\"relay\":\"https://relay.example.org\"}").unwrap();
    }
    let raw = raw_bytes(&path);
    assert!(raw.len() > 1000, "database should exist");
    for needle in [SECRET_TEXT.as_bytes(), b"Lighthouse Keepers", b"Leo Carvalho", b"Leo's desktop", b"relay.example.org", b"secret club"] {
        assert!(!contains(&raw, needle), "found {:?} in the raw database", String::from_utf8_lossy(needle));
    }
    assert!(!contains(&raw, &identity_secret), "identity secret is on disk in the clear");
    assert!(!contains(&raw, &device_secret), "device secret is on disk in the clear");

    // And it all comes back with the right key.
    let store = Store::open(&path, key).unwrap();
    let (id2, _, name) = store.load_account().unwrap().unwrap();
    assert_eq!(id2.public(), id.public());
    assert_eq!(name, "Leo Carvalho");
    let (cid, cname) = store.list_communities().unwrap().remove(0);
    assert_eq!(cname, "Lighthouse Keepers");
    let c = store.load_community(&cid).unwrap();
    assert_eq!(c.messages("general")[0].text, SECRET_TEXT);
    assert_eq!(store.load_remotes().unwrap().len(), 1);
    drop(store);
    cleanup(&path);
}

#[test]
fn wrong_key_is_refused() {
    let path = temp_db("wrongkey");
    let (id, dev) = person("d");
    Store::open(&path, VaultKey::generate()).unwrap().save_account(&id, &dev, "x").unwrap();
    let err = Store::open(&path, VaultKey::generate()).err().expect("opened with the wrong key");
    assert!(err.to_string().contains(WRONG_VAULT_KEY), "{err}");
    cleanup(&path);
}

#[test]
fn tampered_rows_are_detected() {
    let path = temp_db("tamper");
    let key = VaultKey::generate();
    let (_, dev) = person("d");
    let (mut c, mut evs) = CommunityState::create(&dev, "Club", "", Visibility::Public).unwrap();
    evs.push(c.author(&dev, EventKind::Message { channel: "general".into(), text: "one".into(), reply_to: None }).unwrap());
    Store::open(&path, key.clone()).unwrap().save_events(&c.id, &evs).unwrap();

    // Swap the sealed bodies of two events: each is bound to its own id, so this must fail.
    {
        let conn = rusqlite::Connection::open(&path).unwrap();
        let rows: Vec<(String, Vec<u8>)> = conn
            .prepare("SELECT id, sealed FROM events ORDER BY seq")
            .unwrap()
            .query_map([], |r| Ok((r.get(0)?, r.get(1)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();
        conn.execute("UPDATE events SET sealed = ?1 WHERE id = ?2", rusqlite::params![rows[1].1, rows[2].0]).unwrap();
        conn.execute("UPDATE events SET sealed = ?1 WHERE id = ?2", rusqlite::params![rows[2].1, rows[1].0]).unwrap();
    }
    assert!(Store::open(&path, key.clone()).unwrap().load_community(&c.id).is_err());

    // Flipping one bit anywhere in a sealed value is caught too.
    {
        let conn = rusqlite::Connection::open(&path).unwrap();
        let mut b: Vec<u8> = conn.query_row("SELECT sealed FROM events WHERE id = community", [], |r| r.get(0)).unwrap();
        let last = b.len() - 1;
        b[last] ^= 1;
        conn.execute("UPDATE events SET sealed = ?1 WHERE id = community", rusqlite::params![b]).unwrap();
    }
    assert!(Store::open(&path, key).unwrap().list_communities().is_err());
    cleanup(&path);
}

#[test]
fn prototype_databases_are_migrated_and_scrubbed() {
    let path = temp_db("migrate");
    let (id, dev) = person("Old laptop");
    let (mut c, mut evs) = CommunityState::create(&dev, "Old Club", "", Visibility::Public).unwrap();
    evs.push(c.author(&dev, EventKind::Message { channel: "general".into(), text: SECRET_TEXT.into(), reply_to: None }).unwrap());

    // Write a database exactly like v0.1.0 did: everything in the clear.
    {
        let conn = rusqlite::Connection::open(&path).unwrap();
        conn.execute_batch(
            "CREATE TABLE account (id INTEGER PRIMARY KEY CHECK (id = 1), identity_secret BLOB NOT NULL, device_secret BLOB NOT NULL, device_cert TEXT NOT NULL, display_name TEXT NOT NULL);
             CREATE TABLE events (id TEXT PRIMARY KEY, community TEXT NOT NULL, lamport INTEGER NOT NULL, seq INTEGER NOT NULL, body BLOB NOT NULL);
             CREATE INDEX events_by_community ON events (community, seq);
             CREATE TABLE remotes (community TEXT NOT NULL, addr TEXT NOT NULL, PRIMARY KEY (community, addr));",
        )
        .unwrap();
        conn.execute(
            "INSERT INTO account VALUES (1, ?1, ?2, ?3, 'Old Name')",
            rusqlite::params![id.secret_bytes().to_vec(), dev.key.secret_bytes().to_vec(), serde_json::to_string(&dev.cert).unwrap()],
        )
        .unwrap();
        for (i, e) in evs.iter().enumerate() {
            conn.execute(
                "INSERT INTO events VALUES (?1, ?2, ?3, ?4, ?5)",
                rusqlite::params![e.id.to_hex(), c.id.to_hex(), e.body.lamport as i64, i as i64, e.to_bytes()],
            )
            .unwrap();
        }
        conn.execute("INSERT INTO remotes VALUES (?1, 'peer-address')", rusqlite::params![c.id.to_hex()]).unwrap();
    }
    assert!(contains(&raw_bytes(&path), SECRET_TEXT.as_bytes()), "test setup should start in the clear");

    let key = VaultKey::generate();
    {
        let store = Store::open(&path, key.clone()).unwrap();
        let (id2, _, name) = store.load_account().unwrap().unwrap();
        assert_eq!((id2.public(), name.as_str()), (id.public(), "Old Name"));
        assert_eq!(store.load_community(&c.id).unwrap().messages("general")[0].text, SECRET_TEXT);
        assert_eq!(store.load_remotes().unwrap()[0].1, "peer-address");
    }
    let raw = raw_bytes(&path);
    assert!(!contains(&raw, SECRET_TEXT.as_bytes()), "plaintext survived the migration");
    assert!(!contains(&raw, b"Old Name"));
    assert!(!contains(&raw, &id.secret_bytes()), "identity secret survived the migration");
    cleanup(&path);
}

#[test]
fn settings_round_trip() {
    let store = Store::in_memory().unwrap();
    assert_eq!(store.setting("hide_ip").unwrap(), None);
    store.set_setting("hide_ip", "true").unwrap();
    assert_eq!(store.setting("hide_ip").unwrap().as_deref(), Some("true"));
}

#[test]
fn persistent_secrets_survive_reopening_and_stay_sealed() {
    let path = temp_db("secret");
    let key = VaultKey::generate();
    let first = Store::open(&path, key.clone()).unwrap().persistent_secret("network_key").unwrap();
    let again = Store::open(&path, key).unwrap().persistent_secret("network_key").unwrap();
    assert_eq!(first, again);
    assert!(!contains(&raw_bytes(&path), &first), "network key is on disk in the clear");
    cleanup(&path);
}
