use moot_core::sync::{detect_withholding, import, in_sync, missing_for, sync_pair};
use moot_core::*;
use std::collections::HashSet;

fn person(name: &str) -> (Identity, Device) {
    let (id, _phrase) = Identity::create();
    let dev = Device::new(&id, &format!("{name}'s desktop"));
    (id, dev)
}

#[test]
fn recovery_phrase_restores_the_same_identity() {
    let (id, phrase) = Identity::create();
    assert_eq!(phrase.words().len(), 12);
    let restored = Identity::from_phrase(&phrase).unwrap();
    assert_eq!(id.public(), restored.public());
    assert!(Identity::from_phrase(&RecoveryPhrase("not a real phrase at all".into())).is_err());
}

#[test]
fn social_recovery_needs_the_threshold() {
    let (id, _) = Identity::create();
    let shares = id.split_for_social_recovery(2, 3).unwrap();
    assert_eq!(shares.len(), 3);
    let back = Identity::recover_from_shares(2, &shares[1..3]).unwrap();
    assert_eq!(back.public(), id.public());
    // One share alone must not give the key back.
    let one = Identity::recover_from_shares(2, &shares[0..1]);
    assert!(one.is_err() || one.unwrap().public() != id.public());
}

#[test]
fn device_certificates_are_checked() {
    let (alice, dev) = person("alice");
    assert!(dev.cert.verify().is_ok());
    let (mallory, _) = person("mallory");
    let mut forged = dev.cert.clone();
    forged.identity = mallory.public();
    assert_eq!(forged.verify(), Err(Error::BadCertificate));
    assert_eq!(dev.identity(), alice.public());
    assert_eq!(alice.public().fingerprint().split(' ').count(), 4);
}

#[test]
fn owner_creates_community_and_members_post() {
    let (_alice, a) = person("alice");
    let (bob_id, b) = person("bob");
    let (mut s, evs) = CommunityState::create(&a, "Pixel Foundry", "indie devs", Visibility::Public).unwrap();
    assert_eq!(evs.len(), 2);
    assert!(s.channels.contains_key("general"));

    // Bob isn't a member yet: posting is refused.
    let early = Event::new(&b, s.id, s.heads(), 99, EventKind::Message { channel: "general".into(), text: "hi".into(), reply_to: None });
    assert!(matches!(s.apply(&early), Err(Error::NotAllowed(_))));

    s.author(&b, EventKind::Join).unwrap();
    s.author(&b, EventKind::Message { channel: "general".into(), text: "hello!".into(), reply_to: None }).unwrap();
    let msgs = s.messages("general");
    assert_eq!(msgs.len(), 1);
    assert_eq!(msgs[0].author, bob_id.public());
    assert_eq!(s.role_of(&bob_id.public()), Some(Role::Member));
}

#[test]
fn tampered_or_forged_events_are_rejected() {
    let (_a, a) = person("alice");
    let (mut s, _) = CommunityState::create(&a, "Test", "", Visibility::Public).unwrap();
    let ev = Event::new(&a, s.id, s.heads(), 10, EventKind::Message { channel: "general".into(), text: "real".into(), reply_to: None });

    let mut tampered = ev.clone();
    tampered.body.kind = EventKind::Message { channel: "general".into(), text: "edited by a node".into(), reply_to: None };
    assert_eq!(s.apply(&tampered), Err(Error::BadEventId));

    let mut resigned = tampered.clone();
    resigned.id = resigned.body.hash();
    assert_eq!(s.apply(&resigned), Err(Error::BadSignature));

    assert!(s.apply(&ev).is_ok());
}

#[test]
fn invite_only_needs_an_invite() {
    let (_a, a) = person("alice");
    let (bob, b) = person("bob");
    let (mut s, _) = CommunityState::create(&a, "Tidewater Devs", "", Visibility::InviteOnly).unwrap();
    assert!(matches!(s.author(&b, EventKind::Join), Err(Error::NotAllowed(_))));
    s.author(&a, EventKind::Invite { member: bob.public() }).unwrap();
    s.author(&b, EventKind::Join).unwrap();
    assert!(s.members.contains(&bob.public()));
}

#[test]
fn roles_and_moderation_follow_the_hierarchy() {
    let (_a, a) = person("alice");
    let (bob, b) = person("bob");
    let (carol, c) = person("carol");
    let (mut s, _) = CommunityState::create(&a, "Mods", "", Visibility::Public).unwrap();
    s.author(&b, EventKind::Join).unwrap();
    s.author(&c, EventKind::Join).unwrap();

    // A member can't make themselves a moderator.
    assert!(matches!(s.author(&b, EventKind::RoleGrant { member: bob.public(), role: Role::Moderator }), Err(Error::NotAllowed(_))));
    s.author(&a, EventKind::RoleGrant { member: bob.public(), role: Role::Moderator }).unwrap();

    // Moderators can't create channels, admins can.
    assert!(s.author(&b, EventKind::ChannelCreate { channel: "x".into(), name: "x".into(), kind: ChannelKind::Text, private: false }).is_err());
    s.author(&a, EventKind::ChannelCreate { channel: "news".into(), name: "news".into(), kind: ChannelKind::Announcement, private: false }).unwrap();

    // Only admins post announcements.
    assert!(s.author(&b, EventKind::Message { channel: "news".into(), text: "hey".into(), reply_to: None }).is_err());

    // A moderator deletes carol's message and bans her; she can't post afterwards.
    let m = s.author(&c, EventKind::Message { channel: "general".into(), text: "spam".into(), reply_to: None }).unwrap();
    s.author(&b, EventKind::Delete { target: m.id }).unwrap();
    assert!(s.messages("general").is_empty());
    s.author(&b, EventKind::Ban { member: carol.public(), reason: "spam".into() }).unwrap();
    assert!(s.author(&c, EventKind::Message { channel: "general".into(), text: "again".into(), reply_to: None }).is_err());
    assert!(s.author(&c, EventKind::Join).is_err());

    // Nobody can ban the owner.
    assert!(s.author(&b, EventKind::Ban { member: s.owner, reason: "coup".into() }).is_err());
}

#[test]
fn only_the_author_edits() {
    let (_a, a) = person("alice");
    let (_b, b) = person("bob");
    let (mut s, _) = CommunityState::create(&a, "Edits", "", Visibility::Public).unwrap();
    s.author(&b, EventKind::Join).unwrap();
    let m = s.author(&a, EventKind::Message { channel: "general".into(), text: "v1".into(), reply_to: None }).unwrap();
    assert!(s.author(&b, EventKind::Edit { target: m.id, text: "hijack".into() }).is_err());
    s.author(&a, EventKind::Edit { target: m.id, text: "v2".into() }).unwrap();
    let msgs = s.messages("general");
    assert_eq!(msgs[0].text, "v2");
    assert!(msgs[0].edited);
}

#[test]
fn community_survives_owner_with_backup_owner() {
    let (alice, a) = person("alice");
    let (bob, b) = person("bob");
    let (mut s, _) = CommunityState::create(&a, "Survives", "", Visibility::Public).unwrap();
    s.author(&b, EventKind::Join).unwrap();
    s.author(&a, EventKind::SetBackupOwner { backup: bob.public() }).unwrap();
    // Alice loses her keys; Bob claims ownership as the backup owner.
    s.author(&b, EventKind::OwnershipTransfer { to: bob.public() }).unwrap();
    assert_eq!(s.owner, bob.public());
    assert_eq!(s.role_of(&alice.public()), Some(Role::Admin));
    // A random member can't claim it.
    let (_m, m) = person("mallory");
    s.author(&m, EventKind::Join).unwrap();
    assert!(s.author(&m, EventKind::OwnershipTransfer { to: m.identity() }).is_err());
}

#[test]
fn replicas_sync_and_converge() {
    let (_a, a) = person("alice");
    let (_b, b) = person("bob");
    let (mut node1, evs) = CommunityState::create(&a, "Synced", "", Visibility::Public).unwrap();
    // node2 starts from the genesis only.
    let mut node2 = CommunityState::from_genesis(&evs[0]).unwrap();
    for i in 0..20 {
        node1.author(&a, EventKind::Message { channel: "general".into(), text: format!("m{i}"), reply_to: None }).unwrap();
    }
    let (_ra, rb) = sync_pair(&mut node1, &mut node2).unwrap();
    assert_eq!(rb.applied, 21);
    assert!(in_sync(&node1, &node2));

    // Concurrent writes on both sides, then sync again.
    node2.author(&b, EventKind::Join).unwrap();
    node2.author(&b, EventKind::Message { channel: "general".into(), text: "from node2".into(), reply_to: None }).unwrap();
    node1.author(&a, EventKind::Message { channel: "general".into(), text: "from node1".into(), reply_to: None }).unwrap();
    sync_pair(&mut node1, &mut node2).unwrap();
    assert!(in_sync(&node1, &node2));
    assert_eq!(node1.messages("general").len(), 22);
    assert_eq!(node2.messages("general").len(), 22);
    // After both sides saw everything, they share the same heads.
    assert_eq!(node1.heads().len(), 2);
}

#[test]
fn out_of_order_batches_still_apply_and_bad_ones_are_dropped() {
    let (_a, a) = person("alice");
    let (mut src, evs) = CommunityState::create(&a, "Order", "", Visibility::Public).unwrap();
    for i in 0..5 {
        src.author(&a, EventKind::Message { channel: "general".into(), text: format!("{i}"), reply_to: None }).unwrap();
    }
    let mut dst = CommunityState::from_genesis(&evs[0]).unwrap();
    let mut batch = missing_for(&src, &HashSet::from([evs[0].id]));
    batch.reverse();
    // Add one forged event to the batch.
    let mut bad = batch[0].clone();
    bad.body.timestamp_ms += 1;
    bad.id = bad.body.hash(); // a node rewrote the body and recomputed the id, but can't re-sign
    batch.push(bad);
    let report = import(&mut dst, batch);
    assert_eq!(report.applied, 6);
    assert_eq!(report.rejected.len(), 1);
    assert!(in_sync(&src, &dst));
}

#[test]
fn withholding_node_is_detected() {
    let (_a, a) = person("alice");
    let (mut honest, evs) = CommunityState::create(&a, "Watch", "", Visibility::Public).unwrap();
    let mut sneaky = CommunityState::from_genesis(&evs[0]).unwrap();
    import(&mut sneaky, vec![evs[1].clone()]);
    honest.author(&a, EventKind::Message { channel: "general".into(), text: "hidden by sneaky node".into(), reply_to: None }).unwrap();
    let (only_honest, only_sneaky) = detect_withholding(&honest, &sneaky);
    assert_eq!(only_honest.len(), 1);
    assert!(only_sneaky.is_empty());
}

#[test]
fn store_round_trips_account_and_community() {
    let store = Store::in_memory().unwrap();
    assert!(store.load_account().unwrap().is_none());
    let (id, dev) = person("leo");
    store.save_account(&id, &dev, "Leo").unwrap();
    let (id2, dev2, name) = store.load_account().unwrap().unwrap();
    assert_eq!(id2.public(), id.public());
    assert_eq!(dev2.cert, dev.cert);
    assert_eq!(name, "Leo");

    let (mut s, evs) = CommunityState::create(&dev, "Stored", "on disk", Visibility::Private).unwrap();
    store.save_events(&s.id, &evs).unwrap();
    let m = s.author(&dev, EventKind::Message { channel: "general".into(), text: "persisted".into(), reply_to: None }).unwrap();
    store.save_event(&s.id, &m).unwrap();

    let loaded = store.load_community(&s.id).unwrap();
    assert_eq!(loaded.len(), 3);
    assert_eq!(loaded.messages("general")[0].text, "persisted");
    assert_eq!(store.list_communities().unwrap(), vec![(s.id, "Stored".to_string())]);
}

#[test]
fn events_round_trip_through_json_and_bytes() {
    let (_a, a) = person("alice");
    let (_s, evs) = CommunityState::create(&a, "Wire", "", Visibility::Public).unwrap();
    for ev in &evs {
        assert_eq!(&Event::from_json(&ev.to_json()).unwrap(), ev);
        assert_eq!(&Event::from_bytes(&ev.to_bytes()).unwrap(), ev);
        assert!(Event::from_bytes(&ev.to_bytes()).unwrap().verify_self().is_ok());
    }
}

#[test]
fn store_remembers_remote_peers() {
    let store = Store::in_memory().unwrap();
    let (_, dev) = person("owner");
    let (c, evs) = CommunityState::create(&dev, "Remotes", "", Visibility::Public).unwrap();
    store.save_events(&c.id, &evs).unwrap();
    store.save_remote(&c.id, "peer-a").unwrap();
    store.save_remote(&c.id, "peer-a").unwrap();
    store.save_remote(&c.id, "peer-b").unwrap();
    let r = store.load_remotes().unwrap();
    assert_eq!(r.len(), 2);
    assert!(r.iter().all(|(id, _)| *id == c.id));
    let copy = dev.clone();
    assert_eq!(copy.cert, dev.cert);
}

/// A ban and a message written at the same moment on two different devices: every replica
/// must reach the same verdict, whatever order the two events arrive in.
#[test]
fn concurrent_ban_and_message_resolve_the_same_everywhere() {
    let (_, owner) = person("owner");
    let (_, troll) = person("troll");
    let (mut base, evs) = CommunityState::create(&owner, "Race", "", Visibility::Public).unwrap();
    let join = base.author(&troll, EventKind::Join).unwrap();

    // Both write on top of the same history, without seeing each other's event.
    let mut a = base.clone();
    let mut b = base.clone();
    let ban = a.author(&owner, EventKind::Ban { member: troll.identity(), reason: "spam".into() }).unwrap();
    let spam = b.author(&troll, EventKind::Message { channel: "general".into(), text: "buy now".into(), reply_to: None }).unwrap();

    // Replica 1 hears ban first, replica 2 hears the message first.
    let mut r1 = CommunityState::from_genesis(&evs[0]).unwrap();
    let mut r2 = CommunityState::from_genesis(&evs[0]).unwrap();
    for r in [&mut r1, &mut r2] {
        r.apply(&evs[1]).unwrap();
        r.apply(&join).unwrap();
    }
    r1.apply(&ban).unwrap();
    r1.apply(&spam).unwrap();
    r2.apply(&spam).unwrap();
    r2.apply(&ban).unwrap();

    assert_eq!(r1.members, r2.members);
    assert_eq!(r1.banned, r2.banned);
    assert!(r1.banned.contains(&troll.identity()));
    let m1: Vec<_> = r1.messages("general").iter().map(|m| m.id).collect();
    let m2: Vec<_> = r2.messages("general").iter().map(|m| m.id).collect();
    assert_eq!(m1, m2, "replicas show different messages");
    assert_eq!(r1.is_effective(&spam.id), r2.is_effective(&spam.id));

    // After the ban is known, the troll can't post at all — not even admitted.
    let late = Event::new(&troll, r1.id, r1.heads(), 99, EventKind::Message { channel: "general".into(), text: "again".into(), reply_to: None });
    assert!(r1.apply(&late).is_err());
}

#[test]
fn security_badges_verify_and_cannot_be_forged_or_moved() {
    let issuer = Keypair::generate();
    let (researcher, _) = person("researcher");
    let (someone_else, _) = person("someone else");
    let badge = Badge::issue(&issuer, researcher.public(), BadgeTier::Hunter, "Crash in invite decoding", "MOOT-2026-001").unwrap();
    let code = badge.encode();
    let back = Badge::decode(&code).unwrap();
    assert!(back.verify_with(&[issuer.public()]).is_ok());
    assert_eq!(back.body.holder, researcher.public());

    // Not from a trusted issuer.
    let rogue = Keypair::generate();
    let fake = Badge::issue(&rogue, researcher.public(), BadgeTier::Legend, "Totally real", "MOOT-0").unwrap();
    assert!(fake.verify_with(&[issuer.public()]).is_err());

    // Moving it to another person, or upgrading the tier, breaks the signature.
    let mut moved = back.clone();
    moved.body.holder = someone_else.public();
    assert!(moved.verify_with(&[issuer.public()]).is_err());
    let mut upgraded = back.clone();
    upgraded.body.tier = BadgeTier::Legend;
    assert!(upgraded.verify_with(&[issuer.public()]).is_err());

    assert!(Badge::decode("mootbadge1zz").is_err());
    assert!(Badge::decode("hello").is_err());
    // No issuer is built in until the project creates its key, so nothing verifies by default.
    assert!(back.verify().is_err() || !SECURITY_ISSUERS.is_empty());
}
