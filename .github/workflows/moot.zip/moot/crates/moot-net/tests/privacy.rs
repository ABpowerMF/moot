//! IP-privacy guarantees. Run with `cargo test -p moot-net --features test-relay`.
//!
//! These spin up a real relay on localhost and real peers in relay-only mode, then check
//! that: no IP socket is ever opened, nothing we hand out contains an IP, hostile invite
//! codes can't make us dial an IP, and every connection actually went through the relay.
#![cfg(feature = "test-relay")]

use moot_core::{CommunityState, Device, EventKind, Identity, Visibility};
use moot_net::{strip_ips, EndpointAddr, Invite, NetMode, Peer, TransportAddr};

fn person(name: &str) -> Device {
    let (id, _) = Identity::create();
    Device::new(&id, name)
}

fn msg(text: &str) -> EventKind {
    EventKind::Message { channel: "general".into(), text: text.into(), reply_to: None }
}

async fn private_peer(relays: &iroh::RelayMap) -> Peer {
    let p = Peer::spawn(NetMode::TestRelay(relays.clone())).await.unwrap();
    tokio::time::timeout(std::time::Duration::from_secs(10), p.online()).await.expect("peer reached the relay");
    p
}

#[tokio::test(flavor = "multi_thread")]
async fn private_peers_chat_without_ever_seeing_an_ip() {
    let (relays, _url, _server) = iroh::test_utils::run_relay_server().await.unwrap();
    let owner = person("owner");
    let friend = person("friend");

    let host = private_peer(&relays).await;
    let guest = private_peer(&relays).await;

    // 1. Relay-only mode has no IP socket at all.
    assert_eq!(host.ip_sockets(), 0, "host opened an IP socket");
    assert_eq!(guest.ip_sockets(), 0, "guest opened an IP socket");

    // 2. Nothing we hand out contains an IP — only the key and the relay.
    let addr = host.addr();
    assert!(addr.addrs.iter().all(|a| a.is_relay()), "address leaks an IP: {addr:?}");
    assert!(addr.relay_urls().next().is_some());

    let (mut c, evs) = CommunityState::create(&owner, "Private club", "", Visibility::Public).unwrap();
    c.author(&owner, msg("hello from behind a relay")).unwrap();
    host.library.insert(c);
    let id = evs[0].id;
    let code = host.invite(&id).unwrap().encode();
    let invite = Invite::decode(&code).unwrap();
    assert_eq!(invite.host.ip_addrs().count(), 0, "invite code leaks an IP");

    // 3. Join, chat both ways.
    guest.join(&invite, &friend).await.unwrap();
    let reply = guest.library.with(&id, |s| s.author(&friend, msg("hi!"))).unwrap().unwrap();
    guest.sync_with(host.addr(), id).await.unwrap();
    assert!(host.library.with(&id, |s| s.contains(&reply.id)).unwrap());

    // 4. Every connection, on both sides, only ever used the relay.
    let (h, g) = (host.path_counts(), guest.path_counts());
    assert!(h.via_relay >= 2 && g.via_relay >= 2, "host {h:?} guest {g:?}");
    assert_eq!(h.direct, 0, "host saw a direct path");
    assert_eq!(g.direct, 0, "guest used a direct path");
    assert_eq!(host.ip_sockets() + guest.ip_sockets(), 0);

    host.shutdown().await.unwrap();
    guest.shutdown().await.unwrap();
}

#[tokio::test(flavor = "multi_thread")]
async fn hostile_invite_with_an_attacker_ip_is_ignored() {
    let (relays, _url, _server) = iroh::test_utils::run_relay_server().await.unwrap();
    let owner = person("owner");
    let friend = person("friend");
    let host = private_peer(&relays).await;
    let guest = private_peer(&relays).await;

    let (c, evs) = CommunityState::create(&owner, "Club", "", Visibility::Public).unwrap();
    host.library.insert(c);
    let mut invite = host.invite(&evs[0].id).unwrap();
    // An attacker edits the code to add their own IP, hoping we'll dial it and reveal ours.
    let attacker: std::net::SocketAddr = "203.0.113.7:4433".parse().unwrap();
    invite.host.addrs.insert(TransportAddr::Ip(attacker));
    let tampered = Invite::decode(&invite.encode()).unwrap();
    assert_eq!(tampered.host.ip_addrs().count(), 1);

    // We still join fine — through the relay — and never open a socket to that IP.
    guest.join(&tampered, &friend).await.unwrap();
    assert_eq!(guest.ip_sockets(), 0);
    assert_eq!(guest.path_counts().direct, 0);

    host.shutdown().await.unwrap();
    guest.shutdown().await.unwrap();
}

#[test]
fn strip_ips_keeps_key_and_relay_only() {
    let key = iroh::SecretKey::from_bytes(&[7u8; 32]).public();
    let relay: iroh::RelayUrl = "https://relay.example.org".parse().unwrap();
    let addr = EndpointAddr::new(key)
        .with_relay_url(relay.clone())
        .with_ip_addr("192.168.1.20:5000".parse().unwrap())
        .with_ip_addr("[2001:db8::1]:5000".parse().unwrap());
    let clean = strip_ips(addr);
    assert_eq!(clean.id, key);
    assert_eq!(clean.ip_addrs().count(), 0);
    assert_eq!(clean.relay_urls().next(), Some(&relay));
}

/// Control: the detector must notice direct paths, or the tests above prove nothing.
#[tokio::test(flavor = "multi_thread")]
async fn control_direct_mode_is_detected() {
    let owner = person("owner");
    let a = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    let b = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    let (c, evs) = CommunityState::create(&owner, "LAN", "", Visibility::Public).unwrap();
    a.library.insert(c);
    b.library.insert(CommunityState::from_genesis(&evs[0]).unwrap());
    b.sync_with(a.addr(), evs[0].id).await.unwrap();
    assert!(a.ip_sockets() > 0);
    assert_eq!(b.path_counts().direct, 1, "detector missed a direct connection");
    assert!(!NetMode::LocalOnly.hides_ip() && NetMode::Private.hides_ip());
    a.shutdown().await.unwrap();
    b.shutdown().await.unwrap();
}
