use moot_core::*;
use moot_net::{Invite, NetMode, Peer};

fn person(name: &str) -> Device {
    let (id, _) = Identity::create();
    Device::new(&id, name)
}

fn msg(text: &str) -> EventKind {
    EventKind::Message { channel: "general".into(), text: text.into(), reply_to: None }
}

#[tokio::test(flavor = "multi_thread")]
async fn two_peers_sync_a_community_over_quic() {
    let alice = person("alice-node");
    let bob = person("bob-laptop");

    let (mut community, evs) = CommunityState::create(&alice, "Pixel Foundry", "", Visibility::Public).unwrap();
    for i in 0..10 {
        community.author(&alice, msg(&format!("hello {i}"))).unwrap();
    }
    let id = community.id;

    let node = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    node.library.insert(community);

    let laptop = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    let mut mine = CommunityState::from_genesis(&evs[0]).unwrap();
    mine.apply(&evs[1]).unwrap(); // the #general channel, received earlier
    mine.author(&bob, EventKind::Join).unwrap();
    mine.author(&bob, msg("written offline on the laptop")).unwrap();
    laptop.library.insert(mine);

    // The laptop dials the node by its key + address and both sides catch up.
    let report = laptop.sync_with(node.addr(), id).await.unwrap();
    assert_eq!(report.applied, 10, "laptop should receive the 10 messages it missed");
    assert!(report.rejected.is_empty());

    // Give the node a moment to finish importing the push.
    tokio::time::sleep(std::time::Duration::from_millis(300)).await;
    let node_msgs = node.library.with(&id, |s| s.messages("general").len()).unwrap();
    let laptop_msgs = laptop.library.with(&id, |s| s.messages("general").len()).unwrap();
    assert_eq!(node_msgs, 11);
    assert_eq!(laptop_msgs, 11);

    laptop.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
}

#[tokio::test(flavor = "multi_thread")]
async fn forged_events_pushed_over_the_network_are_rejected() {
    let alice = person("alice");
    let (community, evs) = CommunityState::create(&alice, "Guarded", "", Visibility::Public).unwrap();
    let id = community.id;
    let node = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    node.library.insert(community);

    // Mallory writes a real join and message, then rewrites the message after signing it.
    let mallory = person("mallory");
    let mut theirs = CommunityState::from_genesis(&evs[0]).unwrap();
    sync_import(&mut theirs, &evs[1..]);
    let join = theirs.author(&mallory, EventKind::Join).unwrap();
    let mut forged = theirs.author(&mallory, msg("original")).unwrap();
    forged.body.kind = msg("rewritten by mallory");
    forged.id = forged.body.hash();

    let attacker = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    attacker.push_unchecked(node.addr(), id, vec![join, forged]).await.unwrap();
    tokio::time::sleep(std::time::Duration::from_millis(300)).await;

    let report = node.received().pop().expect("node logged the push");
    assert_eq!(report.applied, 1, "the honest join is accepted");
    assert_eq!(report.rejected.len(), 1, "the forged message is rejected");
    assert_eq!(report.rejected[0].1, Error::BadSignature);
    assert_eq!(node.library.with(&id, |s| s.messages("general").len()).unwrap(), 0);

    attacker.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
}

fn sync_import(s: &mut CommunityState, evs: &[Event]) {
    moot_core::sync::import(s, evs.to_vec());
}

#[tokio::test(flavor = "multi_thread")]
async fn join_by_invite_code_then_chat_both_ways() {
    let owner = person("owner-desktop");
    let friend = person("friend-laptop");

    let (mut community, evs) = CommunityState::create(&owner, "Lisbon Game Makers", "", Visibility::Public).unwrap();
    let hello = community.author(&owner, msg("welcome!")).unwrap();
    assert_eq!(evs.len(), 2);

    let host = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    host.library.insert(community);
    let id = evs[0].id;

    // The owner shares a code as text; the friend pastes it.
    let code = host.invite(&id).unwrap().encode();
    assert!(code.starts_with("moot1"));
    let invite = Invite::decode(&code).unwrap();
    assert_eq!(invite.community(), id);

    let guest = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    let joined = guest.join(&invite, &friend).await.unwrap();
    assert!(joined.join_event.is_some());
    assert!(guest.library.with(&id, |s| s.contains(&hello.id)).unwrap());

    // The host now counts the friend as a member.
    let fid = friend.cert.identity;
    assert!(host.library.with(&id, |s| s.role_of(&fid).is_some()).unwrap());

    // The friend posts; the next sync carries it to the host.
    let reply = guest.library.with(&id, |s| s.author(&friend, msg("thanks, glad to be here"))).unwrap().unwrap();
    guest.sync_with(host.addr(), id).await.unwrap();
    assert!(host.library.with(&id, |s| s.contains(&reply.id)).unwrap());

    // And the owner's later message reaches the friend.
    let later = host.library.with(&id, |s| s.author(&owner, msg("jam starts friday"))).unwrap().unwrap();
    guest.sync_with(host.addr(), id).await.unwrap();
    assert!(guest.library.with(&id, |s| s.contains(&later.id)).unwrap());

    host.shutdown().await.unwrap();
    guest.shutdown().await.unwrap();
}

#[tokio::test(flavor = "multi_thread")]
async fn invite_only_refuses_strangers_and_damaged_codes_are_rejected() {
    let owner = person("owner");
    let stranger = person("stranger");
    let (community, evs) = CommunityState::create(&owner, "Private club", "", Visibility::InviteOnly).unwrap();
    let host = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    host.library.insert(community);
    let code = host.invite(&evs[0].id).unwrap().encode();

    assert!(Invite::decode("hello").is_err());
    let mut broken = code.clone();
    broken.truncate(code.len() - 6);
    assert!(Invite::decode(&broken).is_err());

    let guest = Peer::spawn(NetMode::LocalOnly).await.unwrap();
    let err = guest.join(&Invite::decode(&code).unwrap(), &stranger).await.unwrap_err();
    assert!(err.to_string().contains("invite"), "{err}");

    host.shutdown().await.unwrap();
    guest.shutdown().await.unwrap();
}
