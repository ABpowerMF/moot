//! # moot-net — peer-to-peer community sync (prototype)
//!
//! A [`Peer`] is one Moot app or node on the network. Peers are dialled by **public key**,
//! not IP address, so nobody needs port forwarding.
//!
//! ## IP privacy
//!
//! [`NetMode::Private`] is the default. The peer opens **no IP sockets at all**: every
//! packet goes through a relay, which forwards end-to-end encrypted QUIC between public
//! keys. The people you talk to only ever see the relay. The relay sees your IP but not
//! what you send or (for community traffic) who you are in Moot terms.
//!
//! [`NetMode::Direct`] allows hole-punched direct connections — faster, but anyone you
//! connect to learns your IP. It is opt-in.
//!
//! In every mode, invite codes and anything published to address lookup carry only relay
//! addresses, never IPs, and IP addresses found in invite codes from others are ignored.
//!
//! The sync protocol (`moot/sync/1`) runs over one bidirectional QUIC stream:
//!
//! 1. Dialler → host: `Hello { community, have }` (event ids the dialler holds)
//! 2. Host → dialler: `Offer { events, have }` (what the dialler is missing + what the host holds)
//! 3. Dialler → host: `Push { events }` (what the host is missing)
//!
//! Both sides run every received event through `moot_core::sync::import`, which re-checks
//! ids, signatures, parents and permissions. A peer can refuse to serve events, but it can't
//! make anyone accept a forged one.

use anyhow::{anyhow, bail, Context, Result};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use iroh::address_lookup::AddrFilter;
use iroh::endpoint::{presets, Builder, Connection, PortmapperConfig};
use iroh::protocol::{AcceptError, ProtocolHandler, Router};
use iroh::{Endpoint, RelayMode};
pub use iroh::{EndpointAddr, RelayMap, RelayUrl, TransportAddr};
use moot_core::sync::{import, missing_for, ImportReport};
use moot_core::{CommunityState, Device, Event, EventId, EventKind};
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::sync::{Arc, Mutex};

pub const SYNC_ALPN: &[u8] = b"moot/sync/1";
/// Largest single protocol frame we accept (16 MiB).
const MAX_FRAME: usize = 16 * 1024 * 1024;

#[derive(Debug, Serialize, Deserialize)]
enum Frame {
    Hello { community: EventId, have: Vec<EventId> },
    Offer { events: Vec<Event>, have: Vec<EventId> },
    Push { events: Vec<Event> },
    Unknown,
}

/// Communities this peer holds, shared with the protocol handler.
#[derive(Clone, Default)]
pub struct Library {
    inner: Arc<Mutex<HashMap<EventId, CommunityState>>>,
}

impl Library {
    pub fn insert(&self, state: CommunityState) {
        self.inner.lock().unwrap().insert(state.id, state);
    }

    pub fn with<R>(&self, id: &EventId, f: impl FnOnce(&mut CommunityState) -> R) -> Option<R> {
        self.inner.lock().unwrap().get_mut(id).map(f)
    }

    pub fn ids(&self) -> Vec<EventId> {
        self.inner.lock().unwrap().keys().copied().collect()
    }

    pub fn contains(&self, id: &EventId) -> bool {
        self.inner.lock().unwrap().contains_key(id)
    }
}

/// An invite code: the community's signed genesis event plus how to reach a peer that hosts it.
///
/// Encoded as `moot1` + base64url(postcard). The genesis is verified on decode, so a code
/// can't point you at a community other than the one its owner key created.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Invite {
    pub genesis: Event,
    pub host: EndpointAddr,
}

impl Invite {
    pub fn community(&self) -> EventId {
        self.genesis.id
    }

    pub fn encode(&self) -> String {
        format!("moot1{}", URL_SAFE_NO_PAD.encode(postcard::to_allocvec(self).expect("invite serialises")))
    }

    pub fn decode(code: &str) -> Result<Self> {
        if code.len() > 96 * 1024 {
            bail!("the invite code is too long");
        }
        let compact: String = code.split_whitespace().collect();
        let body = compact.strip_prefix("moot1").ok_or_else(|| anyhow!("that isn't a Moot invite code"))?;
        let bytes = URL_SAFE_NO_PAD.decode(body).map_err(|_| anyhow!("the invite code is damaged"))?;
        if bytes.len() > 64 * 1024 {
            bail!("the invite code is too long");
        }
        let invite: Invite = postcard::from_bytes(&bytes).map_err(|_| anyhow!("the invite code is damaged"))?;
        invite.genesis.verify_self()?;
        if !matches!(invite.genesis.body.kind, EventKind::Genesis { .. }) {
            bail!("the invite code doesn't start a community");
        }
        Ok(invite)
    }
}

/// Drop every IP address from an endpoint address, keeping the key and relay URLs.
pub fn strip_ips(addr: EndpointAddr) -> EndpointAddr {
    EndpointAddr::from_parts(addr.id, addr.addrs.into_iter().filter(|a| !a.is_ip()))
}

/// What happened when joining through an invite.
#[derive(Debug)]
pub struct Joined {
    pub community: EventId,
    pub report: ImportReport,
    /// The Join event we signed, if we weren't a member already.
    pub join_event: Option<Event>,
}

async fn write_frame(send: &mut iroh::endpoint::SendStream, f: &Frame) -> Result<()> {
    let bytes = postcard::to_allocvec(f)?;
    send.write_all(&(bytes.len() as u32).to_be_bytes()).await?;
    send.write_all(&bytes).await?;
    Ok(())
}

async fn read_frame(recv: &mut iroh::endpoint::RecvStream) -> Result<Frame> {
    let mut len = [0u8; 4];
    recv.read_exact(&mut len).await.context("reading frame length")?;
    let len = u32::from_be_bytes(len) as usize;
    if len > MAX_FRAME {
        return Err(anyhow!("frame too large: {len} bytes"));
    }
    let mut buf = vec![0u8; len];
    recv.read_exact(&mut buf).await.context("reading frame")?;
    Ok(postcard::from_bytes(&buf)?)
}

#[derive(Clone)]
struct SyncHandler {
    library: Library,
    log: Arc<Mutex<Vec<ImportReport>>>,
    paths: Arc<Mutex<PathCounts>>,
}

impl std::fmt::Debug for SyncHandler {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("SyncHandler")
    }
}

impl SyncHandler {
    async fn serve(&self, conn: Connection) -> Result<()> {
        let result = self.serve_inner(&conn).await;
        record_paths(&conn, &self.paths);
        result
    }

    async fn serve_inner(&self, conn: &Connection) -> Result<()> {
        let conn = conn.clone();
        let (mut send, mut recv) = conn.accept_bi().await?;
        let Frame::Hello { community, have } = read_frame(&mut recv).await? else {
            return Err(anyhow!("expected Hello"));
        };
        let theirs: HashSet<EventId> = have.into_iter().collect();
        let offer = self.library.with(&community, |s| {
            let events = missing_for(s, &theirs);
            let have: Vec<EventId> = s.events_in_order().map(|e| e.id).collect();
            Frame::Offer { events, have }
        });
        let Some(offer) = offer else {
            write_frame(&mut send, &Frame::Unknown).await?;
            send.finish()?;
            conn.closed().await;
            return Ok(());
        };
        write_frame(&mut send, &offer).await?;
        if let Frame::Push { events } = read_frame(&mut recv).await? {
            if let Some(report) = self.library.with(&community, |s| import(s, events)) {
                self.log.lock().unwrap().push(report);
            }
        }
        send.finish()?;
        conn.closed().await;
        Ok(())
    }
}

impl ProtocolHandler for SyncHandler {
    async fn accept(&self, connection: Connection) -> std::result::Result<(), AcceptError> {
        self.serve(connection).await.map_err(|e| AcceptError::from_boxed(e.into()))
    }
}

/// How a peer reaches the network.
#[derive(Clone, Debug)]
pub enum NetMode {
    /// **Default.** Relay only: no IP sockets, no hole punching, no router port mapping.
    /// Peers never learn your IP address. Uses the default public relays.
    Private,
    /// Relay only, through relays you choose (for example ones a community runs itself).
    PrivateVia(RelayMap),
    /// Opt-in: allow direct connections. Faster, but peers you connect to see your IP.
    Direct,
    /// Tests and LAN demos: no relays, no lookup, loopback only.
    LocalOnly,
    /// Tests: relay only through a local relay with a self-signed certificate.
    #[cfg(feature = "test-relay")]
    #[doc(hidden)]
    TestRelay(RelayMap),
}

impl NetMode {
    /// Whether this mode keeps your IP address from the peers you talk to.
    pub fn hides_ip(&self) -> bool {
        match self {
            NetMode::Private | NetMode::PrivateVia(_) => true,
            #[cfg(feature = "test-relay")]
            NetMode::TestRelay(_) => true,
            NetMode::Direct | NetMode::LocalOnly => false,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            NetMode::Private => "private",
            NetMode::PrivateVia(_) => "private-custom-relays",
            NetMode::Direct => "direct",
            NetMode::LocalOnly => "local-only",
            #[cfg(feature = "test-relay")]
            NetMode::TestRelay(_) => "private-test-relay",
        }
    }
}

/// Never tell the world our IPs: address lookup only ever publishes the relay.
fn no_ip_publishing(b: Builder) -> Builder {
    b.addr_filter(AddrFilter::relay_only())
}

/// Relay only: drop every IP transport so there is no socket that could reveal our address
/// to a peer, and skip UPnP/NAT-PMP so we never ask the router to open a port.
fn relay_only(b: Builder) -> Builder {
    no_ip_publishing(b).clear_ip_transports().portmapper_config(PortmapperConfig::Disabled)
}

fn builder_for(mode: &NetMode) -> Result<Builder> {
    Ok(match mode {
        NetMode::Private => relay_only(Endpoint::builder(presets::N0)),
        NetMode::PrivateVia(map) => relay_only(Endpoint::builder(presets::N0).relay_mode(RelayMode::Custom(map.clone()))),
        NetMode::Direct => no_ip_publishing(Endpoint::builder(presets::N0)),
        NetMode::LocalOnly => Endpoint::builder(presets::Minimal)
            .relay_mode(RelayMode::Disabled)
            .clear_address_lookup()
            .portmapper_config(PortmapperConfig::Disabled)
            .bind_addr("127.0.0.1:0")?,
        #[cfg(feature = "test-relay")]
        NetMode::TestRelay(map) => relay_only(
            Endpoint::builder(presets::Minimal)
                .relay_mode(RelayMode::Custom(map.clone()))
                .ca_tls_config(iroh::tls::CaTlsConfig::insecure_skip_verify()),
        ),
    })
}

/// How the peers that connected to us (or that we connected to) were reached.
#[derive(Clone, Copy, Debug, Default, Serialize)]
pub struct PathCounts {
    /// Connections that only ever used a relay — the other side never saw an IP.
    pub via_relay: u64,
    /// Connections that used a direct IP path at some point.
    pub direct: u64,
}

fn record_paths(conn: &Connection, counts: &Mutex<PathCounts>) {
    let direct = conn.paths().iter().any(|p| p.remote_addr().is_ip());
    let mut c = counts.lock().unwrap();
    if direct {
        c.direct += 1;
    } else {
        c.via_relay += 1;
    }
}

/// One Moot app or node on the network.
pub struct Peer {
    endpoint: Endpoint,
    router: Router,
    mode: NetMode,
    pub library: Library,
    received: Arc<Mutex<Vec<ImportReport>>>,
    paths: Arc<Mutex<PathCounts>>,
}

impl Peer {
    pub async fn spawn(mode: NetMode) -> Result<Self> {
        Self::spawn_with(mode, Library::default()).await
    }

    /// Start a peer that serves an existing library (the app passes the one its UI reads).
    /// It gets a fresh network key; use [`Peer::spawn_keyed`] to keep the same one across restarts.
    pub async fn spawn_with(mode: NetMode, library: Library) -> Result<Self> {
        Self::start(mode, library, None).await
    }

    /// Like [`Peer::spawn_with`] but with a persistent 32-byte network key, so invite codes
    /// and remembered peers keep working after a restart.
    pub async fn spawn_keyed(mode: NetMode, library: Library, network_key: [u8; 32]) -> Result<Self> {
        Self::start(mode, library, Some(iroh::SecretKey::from_bytes(&network_key))).await
    }

    async fn start(mode: NetMode, library: Library, key: Option<iroh::SecretKey>) -> Result<Self> {
        let mut builder = builder_for(&mode)?.alpns(vec![SYNC_ALPN.to_vec()]);
        if let Some(k) = key {
            builder = builder.secret_key(k);
        }
        let endpoint = builder.bind().await?;
        if mode.hides_ip() && !endpoint.bound_sockets().is_empty() {
            // Belt and braces: refuse to run "private" with an IP socket open.
            endpoint.close().await;
            bail!("private mode opened an IP socket; refusing to go online");
        }
        let received = Arc::new(Mutex::new(Vec::new()));
        let paths = Arc::new(Mutex::new(PathCounts::default()));
        let handler = SyncHandler { library: library.clone(), log: received.clone(), paths: paths.clone() };
        let router = Router::builder(endpoint.clone()).accept(SYNC_ALPN, handler).spawn();
        Ok(Peer { endpoint, router, mode, library, received, paths })
    }

    /// This peer's public key on the network.
    pub fn id(&self) -> String {
        self.endpoint.id().to_string()
    }

    /// The address we hand out: our key plus relay. IPs are only included in local-only
    /// mode (tests and LAN demos), where there is no relay to use.
    pub fn addr(&self) -> EndpointAddr {
        let full = self.endpoint.addr();
        match self.mode {
            NetMode::LocalOnly => full,
            _ => strip_ips(full),
        }
    }

    pub fn mode(&self) -> &NetMode {
        &self.mode
    }

    /// IP sockets this peer has open. Always empty in private mode.
    pub fn ip_sockets(&self) -> usize {
        self.endpoint.bound_sockets().len()
    }

    /// The relay this peer is reachable through, if it has one yet.
    pub fn relay_url(&self) -> Option<String> {
        self.endpoint.addr().relay_urls().next().map(|u| u.to_string())
    }

    /// How the connections so far were carried (relay only vs direct).
    pub fn path_counts(&self) -> PathCounts {
        *self.paths.lock().unwrap()
    }

    /// Clean up an address we were given before dialling it: outside local-only mode we
    /// never dial raw IPs from invite codes, so a hostile code can't make us reveal ours.
    fn sanitise(&self, addr: EndpointAddr) -> EndpointAddr {
        match self.mode {
            NetMode::LocalOnly => addr,
            _ => strip_ips(addr),
        }
    }

    /// Wait until the peer has a home relay, so invite codes include a reachable address.
    pub async fn online(&self) {
        self.endpoint.online().await
    }

    /// An invite code for a community this peer holds.
    pub fn invite(&self, community: &EventId) -> Result<Invite> {
        let genesis = self
            .library
            .with(community, |s| s.events_in_order().next().cloned())
            .flatten()
            .ok_or_else(|| anyhow!("unknown community"))?;
        Ok(Invite { genesis, host: self.addr() })
    }

    /// Join a community from an invite: fetch and verify its history from the host, then
    /// sign a Join event and push it back. Invite-only communities refuse the Join unless a
    /// moderator has invited this identity first.
    pub async fn join(&self, invite: &Invite, device: &Device) -> Result<Joined> {
        let id = invite.community();
        if !self.library.contains(&id) {
            self.library.insert(CommunityState::from_genesis(&invite.genesis)?);
        }
        let report = self.sync_with(invite.host.clone(), id).await?;
        let me = device.cert.identity;
        let member = self.library.with(&id, |s| s.role_of(&me).is_some()).unwrap_or(false);
        let mut join_event = None;
        if !member {
            let ev = self.library.with(&id, |s| s.author(device, EventKind::Join)).ok_or_else(|| anyhow!("unknown community"))??;
            join_event = Some(ev);
            self.sync_with(invite.host.clone(), id).await?;
        }
        Ok(Joined { community: id, report, join_event })
    }

    /// Reports of events other peers pushed to us.
    pub fn received(&self) -> Vec<ImportReport> {
        std::mem::take(&mut *self.received.lock().unwrap())
    }

    /// Two-way sync of one community with another peer.
    pub async fn sync_with(&self, remote: EndpointAddr, community: EventId) -> Result<ImportReport> {
        let conn = self.endpoint.connect(self.sanitise(remote), SYNC_ALPN).await?;
        let result = self.sync_over(&conn, community).await;
        record_paths(&conn, &self.paths);
        conn.close(0u32.into(), b"done");
        result
    }

    async fn sync_over(&self, conn: &Connection, community: EventId) -> Result<ImportReport> {
        let (mut send, mut recv) = conn.open_bi().await?;
        let have = self.library.with(&community, |s| s.events_in_order().map(|e| e.id).collect::<Vec<_>>()).unwrap_or_default();
        write_frame(&mut send, &Frame::Hello { community, have }).await?;
        let (events, their_have) = match read_frame(&mut recv).await? {
            Frame::Offer { events, have } => (events, have),
            Frame::Unknown => return Err(anyhow!("remote peer doesn't host this community")),
            _ => return Err(anyhow!("unexpected reply")),
        };
        let report = self.library.with(&community, |s| import(s, events)).ok_or_else(|| anyhow!("join the community first"))?;
        let theirs: HashSet<EventId> = their_have.into_iter().collect();
        let push = self.library.with(&community, |s| missing_for(s, &theirs)).unwrap_or_default();
        write_frame(&mut send, &Frame::Push { events: push }).await?;
        send.finish()?;
        // Let the host read the push before we hang up.
        let _ = recv.read_to_end(64).await;
        Ok(report)
    }

    /// Test helper: behave like a hostile peer and push arbitrary events without checking them.
    #[doc(hidden)]
    pub async fn push_unchecked(&self, remote: EndpointAddr, community: EventId, events: Vec<Event>) -> Result<()> {
        let conn = self.endpoint.connect(remote, SYNC_ALPN).await?;
        let (mut send, mut recv) = conn.open_bi().await?;
        write_frame(&mut send, &Frame::Hello { community, have: vec![] }).await?;
        let _ = read_frame(&mut recv).await?;
        write_frame(&mut send, &Frame::Push { events }).await?;
        send.finish()?;
        let _ = recv.read_to_end(64).await;
        conn.close(0u32.into(), b"done");
        Ok(())
    }

    pub async fn shutdown(&self) -> Result<()> {
        self.router.shutdown().await?;
        self.endpoint.close().await;
        Ok(())
    }
}

/// Entry points for fuzzing the wire format. Not part of the stable API.
#[doc(hidden)]
pub mod fuzzing {
    use super::*;

    /// Decode a frame exactly as the network code does. Must never panic.
    pub fn decode_frame(bytes: &[u8]) -> bool {
        postcard::from_bytes::<Frame>(bytes).is_ok()
    }

    /// Feed a decoded frame to a community the way the host would. Must never panic.
    pub fn handle_frame(state: &mut CommunityState, bytes: &[u8]) -> Option<ImportReport> {
        match postcard::from_bytes::<Frame>(bytes).ok()? {
            Frame::Push { events } | Frame::Offer { events, .. } => Some(import(state, events)),
            Frame::Hello { have, .. } => {
                let theirs: HashSet<EventId> = have.into_iter().collect();
                let _ = missing_for(state, &theirs);
                None
            }
            Frame::Unknown => None,
        }
    }

    /// Encode a push frame (for building seed inputs).
    pub fn encode_push(events: Vec<Event>) -> Vec<u8> {
        postcard::to_allocvec(&Frame::Push { events }).unwrap()
    }
}
